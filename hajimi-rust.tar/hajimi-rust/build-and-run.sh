#!/bin/bash

# Hajimi Rust 构建和运行脚本

echo "🦀 开始构建 Hajimi Rust Docker 镜像..."

# 构建 Docker 镜像
docker build -t hajimi-rust:latest .

if [ $? -eq 0 ]; then
    echo "✅ Docker 镜像构建成功！"
    
    echo "🚀 启动 Hajimi Rust 服务..."
    
    # 停止并删除现有容器（如果存在）
    docker stop hajimi-rust 2>/dev/null || true
    docker rm hajimi-rust 2>/dev/null || true
    
    # 运行新容器
    docker run -d \
        --name hajimi-rust \
        -p 7860:7860 \
        --env-file .env \
        hajimi-rust:latest
    
    if [ $? -eq 0 ]; then
        echo "✅ Hajimi Rust 服务启动成功！"
        echo ""
        echo "📍 访问地址:"
        echo "   Web 界面: http://localhost:7860"
        echo "   API 端点: http://localhost:7860/v1/chat/completions"
        echo "   健康检查: http://localhost:7860/health"
        echo ""
        echo "📊 查看日志:"
        echo "   docker logs -f hajimi-rust"
        echo ""
        echo "🛑 停止服务:"
        echo "   docker stop hajimi-rust"
        
        # 等待服务启动
        echo "⏳ 等待服务启动..."
        sleep 5
        
        # 健康检查
        echo "🔍 执行健康检查..."
        curl -f http://localhost:7860/health 2>/dev/null
        if [ $? -eq 0 ]; then
            echo ""
            echo "✅ 服务健康检查通过！"
        else
            echo ""
            echo "⚠️  健康检查失败，请检查日志: docker logs hajimi-rust"
        fi
        
    else
        echo "❌ 服务启动失败！"
        exit 1
    fi
else
    echo "❌ Docker 镜像构建失败！"
    exit 1
fi