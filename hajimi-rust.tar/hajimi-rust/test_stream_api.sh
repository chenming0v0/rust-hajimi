#!/bin/bash

echo "🚀 测试Hajimi Rust流式API转发"
echo "================================="

# 测试配置
HOST="http://localhost:7860"
PASSWORD="123"

# 测试1: 非流式请求
echo "📝 测试1: 非流式请求"
curl -X POST "$HOST/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $PASSWORD" \
  -d '{
    "model": "gemini-2.5-pro",
    "messages": [
      {"role": "user", "content": "你好，请简单回复"}
    ],
    "stream": false
  }' | jq .

echo -e "\n"

# 测试2: 流式请求(假流式模式)
echo "🌊 测试2: 流式请求(假流式模式)"
curl -X POST "$HOST/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $PASSWORD" \
  -d '{
    "model": "gemini-2.5-pro", 
    "messages": [
      {"role": "user", "content": "请用3句话介绍人工智能"}
    ],
    "stream": true
  }'

echo -e "\n"

# 测试3: 检查服务状态
echo "🏥 测试3: 检查服务状态"
curl -s "$HOST/health" | jq .

echo "✅ 测试完成"