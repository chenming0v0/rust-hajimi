#!/bin/bash

# 测试配置更新功能
echo "🧪 测试Hajimi配置更新功能"

# 获取.env文件中的密码
WEB_PASSWORD=$(grep "WEB_PASSWORD=" .env | cut -d'=' -f2)

if [ -z "$WEB_PASSWORD" ]; then
    echo "❌ 未找到WEB_PASSWORD，请检查.env文件"
    exit 1
fi

echo "🔑 使用密码: $WEB_PASSWORD"

# 1. 测试更新最大并发请求数
echo "📊 测试1: 更新最大并发请求数为 500"
curl -X POST http://localhost:7860/api/update_config \
  -H "Content-Type: application/json" \
  -d "{
    \"key\": \"max_concurrent_requests\",
    \"value\": 500,
    \"web_password\": \"$WEB_PASSWORD\"
  }"
echo -e "\n"

# 2. 测试更新随机字符串长度
echo "📊 测试2: 更新随机字符串长度为 16"
curl -X POST http://localhost:7860/api/update_config \
  -H "Content-Type: application/json" \
  -d "{
    \"key\": \"random_string_length\",
    \"value\": 16,
    \"web_password\": \"$WEB_PASSWORD\"
  }"
echo -e "\n"

# 3. 测试更新fake_streaming_interval
echo "📊 测试3: 更新流式传输间隔为 200ms"
curl -X POST http://localhost:7860/api/update_config \
  -H "Content-Type: application/json" \
  -d "{
    \"key\": \"fake_streaming_interval\",
    \"value\": 200,
    \"web_password\": \"$WEB_PASSWORD\"
  }"
echo -e "\n"

# 4. 获取仪表板数据验证配置更新
echo "📊 测试4: 获取仪表板数据验证配置更新"
curl -X GET "http://localhost:7860/api/dashboard_data?web_password=$WEB_PASSWORD"
echo -e "\n"

echo "✅ 配置更新测试完成"