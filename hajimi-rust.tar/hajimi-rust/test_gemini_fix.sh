#!/bin/bash

echo "🔧 测试 Gemini HTTP2 连接修复..."
echo "================================"

# 构建项目
echo "📦 构建项目..."
cargo build --release

if [ $? -eq 0 ]; then
    echo "✅ 构建成功"
else
    echo "❌ 构建失败"
    exit 1
fi

# 启动服务（后台运行）
echo "🚀 启动服务..."
cargo run --release &
SERVER_PID=$!

# 等待服务启动
sleep 5

# 测试API调用
echo "🧪 测试 Gemini API 调用..."
curl -X POST http://localhost:7860/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer @Qqq122488*~/?" \
  -d '{
    "model": "gemini-2.5-pro",
    "messages": [
      {
        "role": "user",
        "content": "Hello, this is a test message."
      }
    ]
  }' \
  --max-time 30 \
  --connect-timeout 10

echo ""
echo "🛑 停止服务..."
kill $SERVER_PID

echo "✅ 测试完成"