# Hajimi Rust 🦀

高性能 AI API 代理服务，基于 Rust 构建，提供安全、快速、可靠的 AI 模型访问。

## ✨ 特性

- 🚀 **极致性能**: 基于 Rust 和 Axum 框架，内存安全，零成本抽象
- 🔐 **安全可靠**: API 密钥管理、请求限流、缓存优化
- 🌐 **多模型支持**: 支持 Gemini、OpenAI、Vertex AI 等主流 AI 服务
- 🐳 **容器化部署**: Docker 支持，一键部署，轻松扩展
- ⚡ **高并发**: 基于 Tokio 异步运行时，支持大量并发请求
- 📊 **监控友好**: 内置健康检查和日志记录

## 🚀 快速开始

### Docker 部署（推荐）

1. **克隆项目**
```bash
git clone <repository-url>
cd hajimi-rust
```

2. **配置环境变量**
```bash
cp .env.example .env
# 编辑 .env 文件，添加您的 API 密钥
```

3. **启动服务**
```bash
docker-compose up -d
```

4. **访问服务**
- Web 界面: http://localhost:7860
- API 端点: http://localhost:7860/v1/chat/completions
- 健康检查: http://localhost:7860/health

### 本地开发

1. **安装 Rust**
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

2. **构建项目**
```bash
cargo build --release
```

3. **运行服务**
```bash
cargo run
```

## 📖 API 文档

### 聊天完成 API

```bash
curl -X POST http://localhost:7860/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "model": "gemini-1.5-pro",
    "messages": [
      {
        "role": "user",
        "content": "Hello, how are you?"
      }
    ],
    "temperature": 0.7,
    "max_tokens": 1000
  }'
```

### 模型列表 API

```bash
curl http://localhost:7860/v1/models
```

### 健康检查 API

```bash
curl http://localhost:7860/health
```

## ⚙️ 配置选项

| 环境变量 | 默认值 | 描述 |
|---------|--------|------|
| `PORT` | 7860 | 服务端口 |
| `API_KEYS` | - | API 密钥列表（逗号分隔） |
| `CACHE_EXPIRY_SECONDS` | 3600 | 缓存过期时间（秒） |
| `MAX_REQUESTS_PER_MINUTE` | 60 | 每分钟最大请求数 |
| `MAX_REQUESTS_PER_DAY` | 1000 | 每天最大请求数 |
| `ALLOWED_ORIGINS` | * | CORS 允许的源 |
| `RUST_LOG` | info | 日志级别 |

## 🏗️ 架构设计

```
hajimi-rust/
├── src/
│   ├── main.rs              # 主程序入口
│   ├── config.rs            # 配置管理
│   ├── services/            # AI 服务集成
│   │   ├── gemini.rs        # Gemini API 客户端
│   │   └── openai.rs        # OpenAI API 客户端
│   └── utils/               # 工具模块
│       ├── api_key.rs       # API 密钥管理
│       ├── cache.rs         # 缓存管理
│       └── rate_limit.rs    # 限流控制
├── templates/               # HTML 模板
├── Dockerfile              # Docker 构建文件
├── docker-compose.yml      # Docker Compose 配置
└── README.md              # 项目文档
```

## 🔧 开发指南

### 添加新的 AI 服务

1. 在 `src/services/` 目录下创建新的服务模块
2. 实现 `chat_completion` 和 `list_models` 方法
3. 在 `main.rs` 中注册新服务
4. 更新路由逻辑以支持新模型

### 自定义中间件

```rust
use axum::middleware;

let app = Router::new()
    .route("/", get(handler))
    .layer(middleware::from_fn(custom_middleware));
```

## 📊 性能优化

- **编译优化**: 使用 `--release` 模式构建
- **内存管理**: 利用 Rust 的零成本抽象
- **异步处理**: 基于 Tokio 的高效异步 I/O
- **连接池**: HTTP 客户端连接复用
- **缓存策略**: 智能缓存减少 API 调用

## 🛡️ 安全特性

- **内存安全**: Rust 语言级别的内存安全保证
- **API 密钥保护**: 安全的密钥管理和轮换
- **请求限流**: 防止 API 滥用
- **CORS 控制**: 跨域请求安全控制
- **容器安全**: 非 root 用户运行

## 📈 监控和日志

### 日志配置
```bash
export RUST_LOG=hajimi_rust=debug,tower_http=debug
```

### 健康检查
```bash
curl http://localhost:7860/health
```

### Docker 日志
```bash
docker-compose logs -f hajimi-rust
```

## 🤝 贡献指南

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 打开 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

- [Axum](https://github.com/tokio-rs/axum) - 现代化的 Rust Web 框架
- [Tokio](https://tokio.rs/) - 异步运行时
- [Serde](https://serde.rs/) - 序列化框架
- [Reqwest](https://github.com/seanmonstar/reqwest) - HTTP 客户端

---

**Powered by Rust 🦀 | 高性能 • 内存安全 • 并发友好**