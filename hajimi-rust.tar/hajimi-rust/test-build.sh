#!/bin/bash

echo "🦀 测试 Hajimi Rust 项目编译..."

cd "$(dirname "$0")"

echo "📦 检查 Cargo.toml..."
if [ ! -f "Cargo.toml" ]; then
    echo "❌ Cargo.toml 文件不存在"
    exit 1
fi

echo "🔍 检查语法..."
cargo check

if [ $? -eq 0 ]; then
    echo "✅ 语法检查通过！"
    
    echo "🔨 尝试编译..."
    cargo build
    
    if [ $? -eq 0 ]; then
        echo "✅ 编译成功！"
        echo ""
        echo "🚀 项目已准备就绪，可以运行："
        echo "   cargo run"
        echo "   或者使用 Docker："
        echo "   ./build-and-run.sh"
    else
        echo "❌ 编译失败"
        exit 1
    fi
else
    echo "❌ 语法检查失败"
    exit 1
fi