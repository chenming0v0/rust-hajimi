//! 流式响应处理模块
//! 
//! 提供真正的流式响应处理能力

use crate::{
    error::{Error, Result},
    models::*,
};
use axum::{
    http::{HeaderMap, HeaderValue},
    response::Response,
};
use futures_util::{Stream, StreamExt};
use serde_json;
use std::{
    pin::Pin,
    time::{SystemTime, UNIX_EPOCH},
};
use tokio::time::{interval, Duration};
use tracing::{debug, info};
use uuid::Uuid;

/// 流式响应处理器
pub struct StreamingHandler {
    request_id: String,
    model: String,
    created_at: u64,
}

impl StreamingHandler {
    /// 创建新的流式处理器
    pub fn new(model: String) -> Self {
        let request_id = format!("chatcmpl-{}", Uuid::new_v4());
        let created_at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();

        Self {
            request_id,
            model,
            created_at,
        }
    }

    /// 处理假流式响应
    pub async fn handle_fake_streaming(
        &self,
        content: String,
        interval_seconds: f64,
    ) -> Result<Response> {
        info!("🎭 处理假流式响应，内容长度: {} 字符", content.len());

        // 创建流式响应头
        let mut headers = HeaderMap::new();
        headers.insert(
            "content-type",
            HeaderValue::from_static("text/plain; charset=utf-8"),
        );
        headers.insert(
            "cache-control",
            HeaderValue::from_static("no-cache"),
        );
        headers.insert(
            "connection",
            HeaderValue::from_static("keep-alive"),
        );
        headers.insert(
            "access-control-allow-origin",
            HeaderValue::from_static("*"),
        );

        // 将内容分块
        let chunks = self.split_content_into_chunks(&content, 20);
        
        // 创建流
        let stream = self.create_fake_stream(chunks, interval_seconds);
        let stream_body = axum::body::Body::from_stream(stream);

        let mut response = Response::new(stream_body);
        *response.headers_mut() = headers;
        
        Ok(response)
    }

    /// 处理真实流式响应
    pub async fn handle_real_streaming(
        stream: impl Stream<Item = Result<String>> + Send + 'static,
    ) -> Result<Response> {
        info!("🚀 处理真实流式响应");

        // 创建流式响应头
        let mut headers = HeaderMap::new();
        headers.insert(
            "content-type",
            HeaderValue::from_static("text/plain; charset=utf-8"),
        );
        headers.insert(
            "cache-control",
            HeaderValue::from_static("no-cache"),
        );
        headers.insert(
            "connection",
            HeaderValue::from_static("keep-alive"),
        );
        headers.insert(
            "access-control-allow-origin",
            HeaderValue::from_static("*"),
        );

        // 转换为SSE格式的流
        let sse_stream = stream.map(move |chunk_result| {
            match chunk_result {
                Ok(chunk) => {
                    let stream_chunk = StreamResponse {
                        id: Uuid::new_v4().to_string(),
                        object: "chat.completion.chunk".to_string(),
                        created: SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs(),
                        model: "gemini-1.5-flash".to_string(),
                        choices: vec![StreamChoice {
                            index: 0,
                            delta: StreamDelta {
                                role: None,
                                content: Some(chunk),
                            },
                            finish_reason: None,
                        }],
                    };

                    match serde_json::to_string(&stream_chunk) {
                        Ok(json) => Ok(format!("data: {}\n\n", json)),
                        Err(e) => {
                            debug!("JSON序列化失败: {}", e);
                            Err(Error::Json(e))
                        }
                    }
                }
                Err(e) => Err(e),
            }
        });

        let stream_body = axum::body::Body::from_stream(sse_stream.map(|item| {
            match item {
                Ok(data) => Ok::<axum::body::Bytes, Box<dyn std::error::Error + Send + Sync>>(axum::body::Bytes::from(data)),
                Err(e) => {
                    let error_msg = e.to_string();
                    debug!("流处理错误: {}", error_msg);
                    Ok(axum::body::Bytes::from(format!("data: {{\"error\": \"{}\"}}\n\n", error_msg)))
                }
            }
        }));

        let mut response = Response::new(stream_body);
        *response.headers_mut() = headers;
        
        Ok(response)
    }

    /// 创建非流式响应
    pub fn create_non_streaming_response(&self, content: String) -> ChatResponse {
        ChatResponse {
            id: self.request_id.clone(),
            object: "chat.completion".to_string(),
            created: self.created_at,
            model: self.model.clone(),
            choices: vec![Choice {
                index: 0,
                message: Message {
                    role: "assistant".to_string(),
                    content: MessageContent::Text(content),
                },
                finish_reason: "stop".to_string(),
            }],
            usage: Usage {
                prompt_tokens: 100, // 简化处理
                completion_tokens: 50,
                total_tokens: 150,
            },
        }
    }

    /// 将内容分割成小块
    fn split_content_into_chunks(&self, content: &str, chunk_size: usize) -> Vec<String> {
        if content.len() <= chunk_size {
            return vec![content.to_string()];
        }

        let mut chunks = Vec::new();
        let chars: Vec<char> = content.chars().collect();
        let mut start = 0;

        while start < chars.len() {
            let end = std::cmp::min(start + chunk_size, chars.len());
            let chunk: String = chars[start..end].iter().collect();
            chunks.push(chunk);
            start = end;
        }

        chunks
    }

    /// 创建假流式Stream
    fn create_fake_stream(
        &self,
        chunks: Vec<String>,
        interval_seconds: f64,
    ) -> Pin<Box<dyn Stream<Item = std::result::Result<axum::body::Bytes, axum::Error>> + Send>> {
        let request_id = self.request_id.clone();
        let model = self.model.clone();
        let created_at = self.created_at;
        let interval_duration = Duration::from_millis((interval_seconds * 1000.0) as u64);

        let stream = async_stream::stream! {
            let mut interval_timer = interval(interval_duration);
            
            // 发送初始数据块（角色信息）
            let initial_chunk = StreamResponse {
                id: request_id.clone(),
                object: "chat.completion.chunk".to_string(),
                created: created_at,
                model: model.clone(),
                choices: vec![StreamChoice {
                    index: 0,
                    delta: StreamDelta {
                        role: Some("assistant".to_string()),
                        content: None,
                    },
                    finish_reason: None,
                }],
            };
            
            if let Ok(json) = serde_json::to_string(&initial_chunk) {
                yield Ok(axum::body::Bytes::from(format!("data: {}\n\n", json)));
            }

            // 发送内容块
            for (i, chunk) in chunks.iter().enumerate() {
                interval_timer.tick().await;

                let stream_chunk = StreamResponse {
                    id: request_id.clone(),
                    object: "chat.completion.chunk".to_string(),
                    created: created_at,
                    model: model.clone(),
                    choices: vec![StreamChoice {
                        index: 0,
                        delta: StreamDelta {
                            role: None,
                            content: Some(chunk.clone()),
                        },
                        finish_reason: if i == chunks.len() - 1 { 
                            Some("stop".to_string()) 
                        } else { 
                            None 
                        },
                    }],
                };

                if let Ok(json) = serde_json::to_string(&stream_chunk) {
                    yield Ok(axum::body::Bytes::from(format!("data: {}\n\n", json)));
                }
            }

            // 发送结束标记
            yield Ok(axum::body::Bytes::from("data: [DONE]\n\n"));
        };

        Box::pin(stream)
    }
}

/// 流式数据处理工具
pub struct StreamProcessor;

impl StreamProcessor {
    /// 解析SSE数据流
    pub fn parse_sse_line(line: &str) -> Option<String> {
        if line.starts_with("data: ") {
            let data = &line[6..];
            if data.trim() == "[DONE]" {
                None
            } else {
                Some(data.to_string())
            }
        } else {
            None
        }
    }

    /// 从JSON中提取文本内容
    pub fn extract_content_from_json(json_data: &str) -> Option<String> {
        match serde_json::from_str::<serde_json::Value>(json_data) {
            Ok(json) => {
                json.get("candidates")?
                    .as_array()?
                    .first()?
                    .get("content")?
                    .get("parts")?
                    .as_array()?
                    .first()?
                    .get("text")?
                    .as_str()
                    .map(|s| s.to_string())
            }
            Err(_) => None,
        }
    }

    /// 创建错误的SSE数据
    pub fn create_error_sse(error_msg: &str) -> String {
        let error_response = serde_json::json!({
            "error": {
                "message": error_msg,
                "type": "stream_error"
            }
        });
        
        format!("data: {}\n\ndata: [DONE]\n\n", error_response)
    }
}

/// 检查模型是否支持流式响应
pub fn is_streaming_supported(model: &str) -> bool {
    // 所有Gemini模型都支持流式响应
    model.starts_with("gemini")
}

/// 从请求中提取客户端IP
pub fn extract_client_ip(headers: &HeaderMap) -> String {
    headers
        .get("x-forwarded-for")
        .and_then(|h| h.to_str().ok())
        .or_else(|| headers.get("x-real-ip").and_then(|h| h.to_str().ok()))
        .unwrap_or("unknown")
        .split(',')
        .next()
        .unwrap_or("unknown")
        .trim()
        .to_string()
}
/// 处理真实流式响应（独立函数版本）- 接受StreamChunk保持完整信息
pub async fn handle_real_streaming_static(
    stream: impl Stream<Item = Result<crate::services::gemini::StreamChunk>> + Send + 'static,
) -> Result<Response> {
    info!("🚀 处理真实流式响应");

    // 创建流式响应头
    let mut headers = HeaderMap::new();
    headers.insert(
        "content-type",
        "text/event-stream".parse().unwrap(),
    );
    headers.insert(
        "cache-control",
        "no-cache".parse().unwrap(),
    );
    headers.insert(
        "connection",
        "keep-alive".parse().unwrap(),
    );

    // 将StreamChunk转换为OpenAI格式的SSE流
    let sse_stream = stream.map(|result| {
        match result {
            Ok(chunk) => {
                let stream_chunk = StreamResponse {
                    id: Uuid::new_v4().to_string(),
                    object: "chat.completion.chunk".to_string(),
                    created: SystemTime::now()
                        .duration_since(UNIX_EPOCH)
                        .unwrap()
                        .as_secs(),
                    model: "gemini-1.5-flash".to_string(),
                    choices: vec![StreamChoice {
                        index: 0,
                        delta: StreamDelta {
                            role: if chunk.content.is_empty() { None } else { Some("assistant".to_string()) },
                            content: if chunk.content.is_empty() { None } else { Some(chunk.content) },
                        },
                        finish_reason: chunk.finish_reason.clone(),
                    }],
                };

                match serde_json::to_string(&stream_chunk) {
                    Ok(json) => Ok(format!("data: {}\n\n", json)),
                    Err(e) => {
                        debug!("JSON序列化失败: {}", e);
                        Err(Error::Json(e))
                    }
                }
            }
            Err(e) => Err(e),
        }
    });

    let stream_body = axum::body::Body::from_stream(sse_stream.map(|item| {
        match item {
            Ok(data) => Ok::<axum::body::Bytes, Box<dyn std::error::Error + Send + Sync>>(axum::body::Bytes::from(data)),
            Err(e) => {
                let error_msg = e.to_string();
                debug!("流处理错误: {}", error_msg);
                Ok(axum::body::Bytes::from(format!("data: {{\"error\": \"{}\"}}\n\n", error_msg)))
            }
        }
    }));

    let mut response = Response::new(stream_body);
    *response.headers_mut() = headers;
    
    Ok(response)
}
