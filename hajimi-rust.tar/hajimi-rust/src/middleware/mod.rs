//! 中间件模块
//! 
//! 提供请求日志、限流、连接池等中间件功能

use axum::{
    http::Request,
    middleware::Next,
    response::Response,
};
use tracing::info;

/// 请求日志中间件
pub fn request_logging() {
    // 返回一个中间件层，让调用者直接使用
}

/// 获取TraceLayer中间件
pub fn get_trace_layer() -> tower_http::trace::TraceLayer<tower_http::classify::SharedClassifier<tower_http::classify::ServerErrorsAsFailures>> {
    // 返回TraceLayer让调用者直接使用
    tower_http::trace::TraceLayer::new_for_http()
}

/// 简单的请求日志中间件
pub async fn simple_logger(request: Request<axum::body::Body>, next: Next) -> Response {
    let method = request.method().clone();
    let uri = request.uri().clone();
    
    info!("📨 {} {}", method, uri);
    
    let response = next.run(request).await;
    
    info!("📤 {} {} - {}", method, uri, response.status());
    
    response
}

/// 错误处理中间件
pub async fn error_handler(request: Request<axum::body::Body>, next: Next) -> Response {
    let response = next.run(request).await;
    
    // 这里可以添加错误处理逻辑
    response
}

/// CORS中间件配置
pub fn cors_config() -> tower_http::cors::CorsLayer {
    use tower_http::cors::{Any, CorsLayer};
    
    CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any)
}