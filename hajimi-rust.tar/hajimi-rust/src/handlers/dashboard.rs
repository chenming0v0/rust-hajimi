//! 仪表板API处理器

use crate::{app::AppState, error::Result};
use axum::{extract::State, response::Html, response::Json};
use serde_json::{json, Value};
use tracing::{info, warn};

/// 仪表板主页
pub async fn dashboard() -> Html<&'static str> {
    Html(include_str!("../../templates/index.html"))
}

/// 获取仪表板数据
pub async fn get_dashboard_data(State(app_state): State<AppState>) -> Result<Json<Value>> {
    info!("📊 请求仪表板数据");

    let key_count = app_state.services.api_keys.key_count().await;
    let active_key_count = app_state.services.api_keys.active_key_count().await;
    let key_stats = app_state.services.api_keys.get_stats().await;
    let cache_stats = app_state.services.cache.get_stats();
    let all_keys_info = app_state.services.api_keys.get_all_keys_info().await;

    // 获取最新配置（强制从storage读取，确保显示最新配置）
    let current_config = match crate::config::Config::load_from_storage().await {
        Ok(config) => {
            info!("✅ 从storage成功加载最新配置，max_retry_attempts: {}", config.performance.max_retry_attempts);
            config
        }
        Err(e) => {
            tracing::warn!("⚠️ 从storage加载配置失败: {}，使用app_state配置", e);
            (*app_state.config).clone()
        }
    };

    // 动态获取可用模型数量（基于旧代码逻辑）
    let model_count = if active_key_count > 0 {
        // 有API密钥时，返回默认支持的模型数量
        // 这和旧版本保持一致：有密钥时显示6个，无密钥时显示0个
        6  // 对应旧代码中的默认模型列表
    } else {
        0  // 没有API密钥时返回0
    };

    let dashboard_data = json!({
        "key_count": key_count,
        "active_key_count": active_key_count,
        "model_count": model_count,
        "retry_count": 0, // TODO: 实现重试统计
        "last_24h_calls": 0, // TODO: 实现24小时调用统计
        "hourly_calls": 0, // TODO: 实现小时调用统计
        "minute_calls": 0, // TODO: 实现分钟调用统计
        "current_time": chrono::Utc::now().format("%Y-%m-%d %H:%M:%S UTC").to_string(),

        // 基本配置（使用最新配置）
        "max_requests_per_minute": current_config.security.max_requests_per_minute,
        "max_requests_per_day_per_ip": current_config.security.max_requests_per_day_per_ip,
        "fake_streaming": current_config.streaming.fake_streaming,
        "fake_streaming_interval": current_config.streaming.fake_streaming_interval,
        "search_enabled": current_config.search.enabled,
        "search_prompt": current_config.search.prompt,

        // 高级配置（使用最新配置）
        "max_retry_attempts": current_config.performance.max_retry_attempts,
        "max_empty_responses": current_config.performance.max_empty_responses,
        "max_concurrent_requests": current_config.performance.max_concurrent_requests,
        "cache_expiry_seconds": current_config.performance.cache_expiry_seconds,
        "request_timeout_seconds": current_config.performance.request_timeout_seconds,
        "random_string": current_config.performance.random_string,
        "random_string_length": current_config.performance.random_string_length,

        // 性能统计
        "performance": {
            "connection_pool": {
                "max_concurrent": current_config.performance.max_concurrent_requests,
                "available": current_config.performance.max_concurrent_requests,
                "in_use": 0,
                "utilization_percent": 0.0
            },
            "cache": {
                "entries": cache_stats.valid_items,
                "total_items": cache_stats.total_items,
                "expired_items": cache_stats.expired_items,
                "expiry_seconds": current_config.performance.cache_expiry_seconds
            },
            "api_keys": {
                "total": key_stats.total,
                "active": key_stats.active,
                "invalid": key_stats.invalid,
                "rate_limited": key_stats.rate_limited
            }
        },

        // API密钥统计 - 脱敏版本
        "api_key_stats": all_keys_info.iter().enumerate().map(|(i, info)| {
            json!({
                "key_preview": info.key_preview,
                "index": i,
                "status": info.status,
                "error_count": info.error_count,
                "usage_count": info.usage_count,
                "last_validated": info.last_validated.map(|t| {
                    format!("{:?}", t)
                })
            })
        }).collect::<Vec<_>>(),

        // 日志 - 简化版本
        "logs": [],

        // 版本信息
        "local_version": env!("CARGO_PKG_VERSION"),
        "remote_version": env!("CARGO_PKG_VERSION"),
        "has_update": false
    });

    Ok(Json(dashboard_data))
}

/// 获取简化的统计信息
pub async fn get_stats(State(app_state): State<AppState>) -> Result<Json<Value>> {
    let key_stats = app_state.services.api_keys.get_stats().await;
    let cache_stats = app_state.services.cache.get_stats();

    let stats = json!({
        "performance": {
            "connection_pool": {
                "max_concurrent": app_state.config.performance.max_concurrent_requests,
                "available": app_state.config.performance.max_concurrent_requests,
                "in_use": 0,
                "utilization_percent": 0.0
            },
            "api_keys": {
                "total_count": key_stats.total,
                "active_count": key_stats.active,
                "has_keys": key_stats.active > 0
            },
            "cache": {
                "entries": cache_stats.valid_items,
                "expiry_seconds": app_state.config.performance.cache_expiry_seconds
            }
        },
        "timestamp": chrono::Utc::now().timestamp()
    });

    Ok(Json(stats))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::Config;
    use crate::services::ServiceManager;
    use std::sync::Arc;

    #[tokio::test]
    async fn test_dashboard_renders() {
        let result = dashboard().await;
        // Just check that it returns HTML content
        assert!(result.0.contains("html") || result.0.contains("HTML"));
    }
}