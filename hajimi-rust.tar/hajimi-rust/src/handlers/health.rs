//! 健康检查API处理器

use crate::{
    app::{get_health_info, AppState},
    models::HealthResponse,
};
use axum::{extract::State, response::Json};
use tracing::debug;

/// 健康检查端点
pub async fn health_check(State(app_state): State<AppState>) -> Json<HealthResponse> {
    debug!("🏥 健康检查请求");

    let health_info = get_health_info(&app_state.services).await;
    let cache_stats = app_state.services.cache.get_stats();

    Json(HealthResponse {
        status: health_info.status,
        timestamp: health_info.timestamp,
        performance: crate::models::PerformanceMetrics {
            connection_pool: crate::models::ConnectionPoolStats {
                max_concurrent: app_state.config.performance.max_concurrent_requests,
                available: app_state.config.performance.max_concurrent_requests,
                in_use: 0,
            },
            api_keys: crate::models::ApiKeyStats {
                gemini_count: app_state.services.api_keys.key_count().await,
                has_keys: app_state.services.api_keys.has_keys().await,
            },
            cache_entries: cache_stats.valid_items,
        },
    })
}