//! Chat Completions API处理器
//! 
//! 核心的聊天完成API，支持流式和非流式响应

use crate::{
    app::AppState,
    error::{Error, Result},
    models::*,
    services::cache::CacheKeyGenerator,
    services::gemini::{preprocess_search_messages, preprocess_disguise_messages},
    streaming::{extract_client_ip, StreamingHandler},
};
use axum::{
    extract::{Query, State},
    http::{HeaderMap, StatusCode},
    response::{IntoResponse, Json, Response},
};
use serde::Deserialize;
use tracing::{debug, error, info, warn};

/// 认证查询参数
#[derive(Deserialize)]
pub struct AuthQuery {
    pub password: Option<String>,
}

/// Chat Completions API端点
pub async fn chat_completions(
    State(app_state): State<AppState>,
    headers: HeaderMap,
    query: Option<Query<AuthQuery>>,
    Json(request): Json<ChatRequest>,
) -> Result<Response> {
    info!("📨 收到聊天请求 - 模型: {}, 流式: {}", request.model, request.stream);

    // 身份验证
    authenticate(&headers, query.as_ref().map(|q| q), &app_state).await?;

    // 限流检查
    let client_ip = extract_client_ip(&headers);
    check_rate_limit(&client_ip, &app_state).await?;

    // 验证请求
    validate_request(&request)?;

    // 获取可用的API密钥
    let api_key = app_state.services.get_available_api_key().await
        .ok_or_else(|| Error::ServiceUnavailable("没有可用的API密钥".to_string()))?;

    info!("🔑 使用API密钥: {}...", &api_key[..8]);

    // 处理搜索模式
    let (model, messages) = preprocess_request(&request, &app_state).await;

    // 生成缓存键
    let cache_key = generate_cache_key(&model, &messages);

    // 检查缓存
    if !request.stream {
        if let Some(cached_response) = app_state.services.cache.get(&cache_key).await {
            info!("🎯 缓存命中: {}", cache_key);
            let cached_chat_response: ChatResponse = serde_json::from_str(&cached_response)
                .map_err(|e| Error::Internal(format!("缓存反序列化失败: {}", e)))?;
            return Ok(Json(cached_chat_response).into_response());
        }
    }

    // 创建流式处理器
    let streaming_handler = StreamingHandler::new(request.model.clone());

    // 根据流式设置处理请求
    if request.stream {
        handle_streaming_request(
            streaming_handler,
            &model,
            &messages,
            &api_key,
            &app_state,
            &cache_key,
        ).await
    } else {
        handle_non_streaming_request(
            streaming_handler,
            &model,
            &messages,
            &api_key,
            &app_state,
            &cache_key,
        ).await
    }
}

/// 身份验证
async fn authenticate(
    headers: &HeaderMap,
    query: Option<&Query<AuthQuery>>,
    app_state: &AppState,
) -> Result<()> {
    let provided_password = extract_password(headers, query);
    
    if provided_password != app_state.config.password {
        warn!("❌ 认证失败 - IP: {}", extract_client_ip(headers));
        return Err(Error::Auth("认证失败".to_string()));
    }
    
    Ok(())
}

/// 提取密码
fn extract_password(headers: &HeaderMap, query: Option<&Query<AuthQuery>>) -> String {
    // 从查询参数获取
    if let Some(query) = query {
        if let Some(password) = &query.password {
            return password.clone();
        }
    }
    
    // 从Authorization头获取
    if let Some(auth_header) = headers.get("authorization") {
        if let Ok(auth_str) = auth_header.to_str() {
            if let Some(token) = auth_str.strip_prefix("Bearer ") {
                return token.to_string();
            }
        }
    }
    
    String::new()
}

/// 限流检查
async fn check_rate_limit(client_ip: &str, _app_state: &AppState) -> Result<()> {
    // TODO: 实现真正的限流逻辑
    // 这里只是一个占位符
    debug!("🚦 限流检查通过 - IP: {}", client_ip);
    Ok(())
}

/// 验证请求
fn validate_request(request: &ChatRequest) -> Result<()> {
    if request.messages.is_empty() {
        return Err(Error::Api("消息列表不能为空".to_string()));
    }

    if !request.model.starts_with("gemini") {
        return Err(Error::Api("只支持Gemini模型".to_string()));
    }

    Ok(())
}

/// 预处理请求
async fn preprocess_request(
    request: &ChatRequest,
    app_state: &AppState,
) -> (String, Vec<Message>) {
    let mut model = request.model.clone();
    let mut messages = request.messages.clone();

    // 处理搜索模式
    if request.model.ends_with("-search") {
        model = request.model.trim_end_matches("-search").to_string();
        
        if app_state.config.search.enabled {
            info!("🔍 启用搜索模式: {}", request.model);
            messages = preprocess_search_messages(
                &messages,
                &app_state.config.search.prompt,
                true,
            );
        }
    }

    // 处理伪装消息（注入随机字符串）
    if app_state.config.performance.random_string {
        info!("✨ 启用伪装消息模式");
        messages = preprocess_disguise_messages(
            &messages,
            true,
            app_state.config.performance.random_string_length,
        );
    }

    (model, messages)
}

/// 生成缓存键
fn generate_cache_key(model: &str, messages: &[Message]) -> String {
    let messages_hash = CacheKeyGenerator::hash_messages(messages);
    CacheKeyGenerator::chat_key(model, messages_hash)
}

/// 处理流式请求
async fn handle_streaming_request(
    streaming_handler: StreamingHandler,
    model: &str,
    messages: &[Message],
    api_key: &str,
    app_state: &AppState,
    cache_key: &str,
) -> Result<Response> {
    let _enable_search = model != &app_state.config.search.prompt;

    if app_state.config.streaming.fake_streaming {
        // 假流式：先获取完整响应，再模拟流式返回
        info!("🎭 使用假流式模式");
        
        // 检查是否启用搜索
        let search_enabled = model.ends_with("-search") && app_state.config.search.enabled;
        
        match app_state.services.gemini
            .chat(&messages, api_key, model, None, None, search_enabled)
            .await
        {
            Ok(content) => {
                info!("✅ 获取到响应内容，长度: {}", content.len());
                
                // 标记密钥使用成功
                app_state.services.api_keys.mark_key_success(api_key).await;
                
                // 缓存响应
                let cache_response = streaming_handler.create_non_streaming_response(content.clone());
                let response_json = serde_json::to_string(&cache_response)?;
                app_state.services.cache.set(cache_key.to_string(), response_json).await;
                
                // 返回假流式响应
                streaming_handler.handle_fake_streaming(
                    content,
                    app_state.config.streaming.fake_streaming_interval,
                ).await
            }
            Err(e) => {
                error!("❌ 假流式请求失败: {}", e);
                app_state.services.api_keys.mark_key_invalid(api_key).await;
                Err(e)
            }
        }
    } else {
        // 真流式：直接返回流式响应
        info!("🚀 使用真流式模式");
        
        // 检查是否启用搜索
        let search_enabled = model.ends_with("-search") && app_state.config.search.enabled;
        
        match app_state.services.gemini
            .chat_stream(&messages, api_key, model, None, None, search_enabled)
            .await
        {
            Ok(stream) => {
                info!("✅ 建立流式连接");
                
                // 标记密钥使用成功
                app_state.services.api_keys.mark_key_success(api_key).await;
                
                // 直接传递完整的StreamChunk，保留所有重要信息
                crate::streaming::handle_real_streaming_static(stream).await
            }
            Err(e) => {
                error!("❌ 真流式请求失败: {}", e);
                app_state.services.api_keys.mark_key_invalid(api_key).await;
                Err(e)
            }
        }
    }
}

/// 处理非流式请求
async fn handle_non_streaming_request(
    streaming_handler: StreamingHandler,
    model: &str,
    messages: &[Message],
    api_key: &str,
    app_state: &AppState,
    cache_key: &str,
) -> Result<Response> {
    let _enable_search = model != &app_state.config.search.prompt;

    info!("📝 处理非流式请求");
    
    // 检查是否启用搜索
    let search_enabled = model.ends_with("-search") && app_state.config.search.enabled;
    
    match app_state.services.gemini
      .chat(&messages, api_key, model, None, None, search_enabled)
      .await
    {
        Ok(content) => {
            info!("✅ 非流式请求成功，内容长度: {}", content.len());
            
            // 标记密钥使用成功
            app_state.services.api_keys.mark_key_success(api_key).await;
            
            // 创建响应
            let response = streaming_handler.create_non_streaming_response(content);
            
            // 缓存响应
            let response_json = serde_json::to_string(&response)?;
            app_state.services.cache.set(cache_key.to_string(), response_json).await;
            
            Ok(Json(response).into_response())
        }
        Err(e) => {
            error!("❌ 非流式请求失败: {}", e);
            app_state.services.api_keys.mark_key_invalid(api_key).await;
            Err(e)
        }
    }
}

/// 处理API错误并标记密钥状态
fn handle_api_error(error: &Error, api_key: &str) -> StatusCode {
    match error {
        Error::Network(_) => {
            warn!("🌐 网络错误 - 密钥: {}...", &api_key[..8]);
            StatusCode::BAD_GATEWAY
        }
        Error::Api(msg) if msg.contains("quota") || msg.contains("rate") => {
            warn!("⏰ API限流 - 密钥: {}...", &api_key[..8]);
            StatusCode::TOO_MANY_REQUESTS
        }
        Error::Api(msg) if msg.contains("invalid") || msg.contains("unauthorized") => {
            warn!("🔑 密钥无效 - 密钥: {}...", &api_key[..8]);
            StatusCode::UNAUTHORIZED
        }
        _ => {
            warn!("❓ 未知API错误 - 密钥: {}...", &api_key[..8]);
            StatusCode::INTERNAL_SERVER_ERROR
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::Config;

    #[test]
    fn test_extract_password() {
        let mut headers = HeaderMap::new();
        headers.insert("authorization", "Bearer test123".parse().unwrap());
        
        let password = extract_password(&headers, None);
        assert_eq!(password, "test123");
    }

    #[test]
    fn test_validate_request() {
        let request = ChatRequest {
            model: "gemini-1.5-pro".to_string(),
            messages: vec![Message {
                role: "user".to_string(),
                content: MessageContent::Text("Hello".to_string()),
            }],
            stream: false,
            temperature: None,
            max_tokens: None,
        };
        
        assert!(validate_request(&request).is_ok());
    }

    #[test]
    fn test_validate_request_empty_messages() {
        let request = ChatRequest {
            model: "gemini-1.5-pro".to_string(),
            messages: vec![],
            stream: false,
            temperature: None,
            max_tokens: None,
        };
        
        assert!(validate_request(&request).is_err());
    }

    #[test]
    fn test_validate_request_invalid_model() {
        let request = ChatRequest {
            model: "gpt-4".to_string(),
            messages: vec![Message {
                role: "user".to_string(),
                content: MessageContent::Text("Hello".to_string()),
            }],
            stream: false,
            temperature: None,
            max_tokens: None,
        };
        
        assert!(validate_request(&request).is_err());
    }
}