//! 管理API处理器

use crate::{
    app::AppState,
    error::{Error, Result},
    handlers::chat::AuthQuery,
};
use axum::{
    extract::{Query, State},
    Json,
};
use serde::Deserialize;
use serde_json::{json, Value};
use std::sync::atomic::{AtomicUsize, AtomicBool, Ordering};
use tracing::{info, warn};

// 全局测试状态
static TEST_PROGRESS: AtomicUsize = AtomicUsize::new(0);
static TEST_TOTAL: AtomicUsize = AtomicUsize::new(0);
static TEST_VALID: AtomicUsize = AtomicUsize::new(0);
static TEST_INVALID: AtomicUsize = AtomicUsize::new(0);
static TEST_TIMEOUT: AtomicUsize = AtomicUsize::new(0);
static TEST_COMPLETED: AtomicBool = AtomicBool::new(false);
static TEST_RUNNING: AtomicBool = AtomicBool::new(false);

// 测试日志存储
use std::sync::Mutex;
use std::collections::VecDeque;

static TEST_LOGS: Mutex<VecDeque<String>> = Mutex::new(VecDeque::new());

/// 添加测试日志
fn add_test_log(message: String) {
    if let Ok(mut logs) = TEST_LOGS.lock() {
        logs.push_back(message);
        // 限制日志数量，避免内存溢出
        if logs.len() > 1000 {
            logs.pop_front();
        }
    }
}

/// 清理测试日志
fn clear_test_logs() {
    if let Ok(mut logs) = TEST_LOGS.lock() {
        logs.clear();
    }
}

/// 获取测试日志
fn get_test_logs() -> Vec<String> {
    if let Ok(logs) = TEST_LOGS.lock() {
        logs.iter().cloned().collect()
    } else {
        vec![]
    }
}

/// 配置更新请求
#[derive(Deserialize)]
pub struct UpdateConfigRequest {
    pub key: String,
    pub value: Value,
    pub password: String,
}

/// 批量配置更新请求
#[derive(Deserialize)]
pub struct BatchUpdateConfigRequest {
    pub password: String,
    pub fake_streaming: Option<bool>,
    pub search_enabled: Option<bool>,
    pub max_requests_per_minute: Option<u32>,
    pub max_requests_per_day_per_ip: Option<u32>,
    pub max_retry_attempts: Option<usize>,
    pub max_empty_responses: Option<usize>,
    pub fake_streaming_interval: Option<f64>,
    pub max_concurrent_requests: Option<usize>,
    pub search_prompt: Option<String>,
    pub random_string: Option<bool>,
    pub random_string_length: Option<usize>,
}

/// API密钥设置请求
#[derive(Deserialize)]
pub struct SetApiKeysRequest {
    pub api_keys: String,
    pub password: String,
}

/// 测试API密钥请求
#[derive(Deserialize)]
pub struct TestApiKeysRequest {
    pub password: String,
}

/// 清除无效密钥请求
#[derive(Deserialize)]
pub struct ClearInvalidKeysRequest {
    pub password: String,
}

/// 带查重功能的API密钥设置请求
#[derive(Deserialize)]
pub struct SetApiKeysWithDuplicateCheckRequest {
    pub api_keys: String,
    pub password: String,
}

/// 批量验证密钥请求
#[derive(Deserialize)]
pub struct BatchValidateKeysRequest {
    pub password: String,
    pub max_concurrent: Option<usize>,
}

/// 密钥健康度报告请求
#[derive(Deserialize)]
pub struct HealthReportRequest {
    pub password: String,
}

/// 更新配置
pub async fn update_config(
    State(app_state): State<AppState>,
    Json(request): Json<BatchUpdateConfigRequest>,
) -> Result<Json<Value>> {
    info!("📝 收到批量配置更新请求");

    // 验证密码
    if request.password != app_state.config.web_password {
        warn!("❌ 管理密码验证失败");
        return Err(Error::Auth("密码验证失败".to_string()));
    }

    // 加载当前配置
    let mut current_config = if let Ok(config) = crate::config::Config::load_from_storage().await {
        config
    } else {
        (*app_state.config).clone()
    };

    // 批量更新配置项
    let mut updated_count = 0;

    if let Some(fake_streaming) = request.fake_streaming {
        current_config.streaming.fake_streaming = fake_streaming;
        updated_count += 1;
        info!("⚙️ 更新假流式响应: {}", fake_streaming);
    }

    if let Some(search_enabled) = request.search_enabled {
        current_config.search.enabled = search_enabled;
        updated_count += 1;
        info!("⚙️ 更新联网搜索: {}", search_enabled);
    }

    if let Some(max_requests_per_minute) = request.max_requests_per_minute {
        current_config.security.max_requests_per_minute = max_requests_per_minute;
        updated_count += 1;
        info!("⚙️ 更新每分钟请求限制: {}", max_requests_per_minute);
    }

    if let Some(max_requests_per_day_per_ip) = request.max_requests_per_day_per_ip {
        current_config.security.max_requests_per_day_per_ip = max_requests_per_day_per_ip;
        updated_count += 1;
        info!("⚙️ 更新每日请求限制: {}", max_requests_per_day_per_ip);
    }

    if let Some(max_retry_attempts) = request.max_retry_attempts {
        current_config.performance.max_retry_attempts = max_retry_attempts;
        updated_count += 1;
        info!("⚙️ 更新最大重试次数: {}", max_retry_attempts);
    }

    if let Some(max_empty_responses) = request.max_empty_responses {
        current_config.performance.max_empty_responses = max_empty_responses;
        updated_count += 1;
        info!("⚙️ 更新空响应重试次数限制: {}", max_empty_responses);
    }

    if let Some(fake_streaming_interval) = request.fake_streaming_interval {
        current_config.streaming.fake_streaming_interval = fake_streaming_interval;
        updated_count += 1;
        info!("⚙️ 更新假流式间隔: {}", fake_streaming_interval);
    }

    if let Some(max_concurrent_requests) = request.max_concurrent_requests {
        current_config.performance.max_concurrent_requests = max_concurrent_requests;
        updated_count += 1;
        info!("⚙️ 更新最大并发请求数: {}", max_concurrent_requests);
    }

    if let Some(search_prompt) = request.search_prompt {
        current_config.search.prompt = search_prompt;
        updated_count += 1;
        info!("⚙️ 更新联网搜索提示");
    }

    if let Some(random_string) = request.random_string {
        current_config.performance.random_string = random_string;
        updated_count += 1;
        info!("⚙️ 更新随机字符串伪装: {}", random_string);
    }

    if let Some(random_string_length) = request.random_string_length {
        current_config.performance.random_string_length = random_string_length;
        updated_count += 1;
        info!("⚙️ 更新随机字符串长度: {}", random_string_length);
    }

    // 保存配置
    if updated_count > 0 {
        info!("🔍 保存前配置检查，max_retry_attempts: {}", current_config.performance.max_retry_attempts);
        
        current_config.save_to_storage().await
            .map_err(|e| Error::Config(format!("保存配置失败: {}", e)))?;
        
        // 验证保存是否成功
        match crate::config::Config::load_from_storage().await {
            Ok(saved_config) => {
                info!("✅ 已更新并保存 {} 个配置项，验证保存后max_retry_attempts: {}",
                    updated_count, saved_config.performance.max_retry_attempts);
            }
            Err(e) => {
                warn!("⚠️ 保存后验证失败: {}", e);
            }
        }
    }

    Ok(Json(json!({
        "success": true,
        "message": format!("配置更新成功，已更新 {} 个配置项", updated_count)
    })))
}

/// 设置API密钥
pub async fn set_api_keys(
    State(app_state): State<AppState>,
    Json(request): Json<SetApiKeysRequest>,
) -> Result<Json<Value>> {
    // 验证密码
    if request.password != app_state.config.web_password {
        return Err(crate::error::Error::Auth("密码验证失败".to_string()));
    }

    let keys: Vec<String> = request
        .api_keys
        .split(',')
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();

    let key_count = keys.len();
    
    // 正确的添加模式
    app_state.services.api_keys.add_keys(keys).await;

    Ok(Json(json!({
        "success": true,
        "message": format!("已添加 {} 个API密钥", key_count)
    })))
}

/// 获取密钥信息
pub async fn get_key_info(
    State(app_state): State<AppState>,
    query: Option<Query<AuthQuery>>,
) -> Result<Json<Value>> {
    // 简单验证（可选）
    if let Some(Query(auth)) = query {
        if let Some(password) = auth.password {
            if password != app_state.config.web_password {
                return Err(Error::Auth("密码验证失败".to_string()));
            }
        }
    }

    let key_stats = app_state.services.api_keys.get_stats().await;
    let all_keys_info = app_state.services.api_keys.get_all_keys_info().await;

    Ok(Json(json!({
        "total_keys": key_stats.total,
        "active_keys": key_stats.active,
        "invalid_keys": key_stats.invalid,
        "rate_limited_keys": key_stats.rate_limited,
        "keys_info": all_keys_info
    })))
}

/// 测试API密钥
pub async fn test_api_keys(
    State(app_state): State<AppState>,
    Json(request): Json<TestApiKeysRequest>,
) -> Result<Json<Value>> {
    info!("🧪 开始测试API密钥");

    // 验证密码
    if request.password != app_state.config.web_password {
        return Err(Error::Auth("密码验证失败".to_string()));
    }

    // 检查是否已有测试在运行
    if TEST_RUNNING.load(Ordering::SeqCst) {
        return Err(Error::Validation("已有密钥测试在进行中".to_string()));
    }

    // 重置测试状态
    TEST_RUNNING.store(true, Ordering::SeqCst);
    TEST_PROGRESS.store(0, Ordering::SeqCst);
    TEST_VALID.store(0, Ordering::SeqCst);
    TEST_INVALID.store(0, Ordering::SeqCst);
    TEST_TIMEOUT.store(0, Ordering::SeqCst);
    TEST_COMPLETED.store(false, Ordering::SeqCst);
    clear_test_logs();

    let key_count = app_state.services.api_keys.key_count().await;
    TEST_TOTAL.store(key_count, Ordering::SeqCst);

    if key_count == 0 {
        TEST_COMPLETED.store(true, Ordering::SeqCst);
        TEST_RUNNING.store(false, Ordering::SeqCst);
        add_test_log("📝 没有API密钥需要测试".to_string());
        return Ok(Json(json!({
            "success": true,
            "message": "没有API密钥需要测试"
        })));
    }

    add_test_log(format!("🚀 开始测试 {} 个API密钥", key_count));

    // 在后台异步执行增强的密钥测试
    let services = app_state.services.clone();
    let max_retry = app_state.config.performance.max_retry_attempts;
    tokio::spawn(async move {
        // 获取所有密钥
        let keys_to_test = services.api_keys.get_all_key_strings().await;

        let mut valid_count = 0;
        let mut invalid_count = 0;
        let mut timeout_count = 0;

        for (index, key) in keys_to_test.iter().enumerate() {
            let progress = index + 1;
            let key_preview = format!("{}...{}", &key[..8], &key[key.len()-4..]);
            
            add_test_log(format!("🧪 测试密钥 {}/{}: {}", progress, key_count, key_preview));
            
            // 多次重试逻辑
            let mut is_valid = false;
            let mut last_error = String::new();
            
            for retry in 0..=max_retry {
                if retry > 0 {
                    add_test_log(format!("🔄 密钥 {} 重试第 {} 次", key_preview, retry));
                    tokio::time::sleep(std::time::Duration::from_millis(500)).await;
                }
                
                let test_result = tokio::time::timeout(
                    std::time::Duration::from_secs(15),
                    test_single_api_key(key.clone())
                ).await;

                match test_result {
                    Ok(result) => {
                        match result {
                            Ok(true) => {
                                is_valid = true;
                                add_test_log(format!("✅ 密钥 {} 验证成功", key_preview));
                                break;
                            }
                            Ok(false) => {
                                last_error = "API密钥无效".to_string();
                                add_test_log(format!("❌ 密钥 {} 无效", key_preview));
                                break; // 无效密钥不需要重试
                            }
                            Err(e) => {
                                last_error = format!("请求错误: {}", e);
                                add_test_log(format!("⚠️ 密钥 {} 测试失败: {}", key_preview, e));
                            }
                        }
                    }
                    Err(_) => {
                        last_error = "请求超时".to_string();
                        add_test_log(format!("⏰ 密钥 {} 测试超时", key_preview));
                        if retry == max_retry {
                            timeout_count += 1;
                        }
                    }
                }
            }

            // 更新密钥状态
            if is_valid {
                services.api_keys.mark_key_success(key).await;
                valid_count += 1;
            } else if last_error.contains("超时") {
                timeout_count += 1;
                add_test_log(format!("⏰ 密钥 {} 最终超时，已达最大重试次数 {}", key_preview, max_retry));
            } else {
                services.api_keys.mark_key_invalid(key).await;
                invalid_count += 1;
                add_test_log(format!("❌ 密钥 {} 最终无效: {}", key_preview, last_error));
            }

            // 更新进度
            TEST_PROGRESS.store(progress, Ordering::SeqCst);
            TEST_VALID.store(valid_count, Ordering::SeqCst);
            TEST_INVALID.store(invalid_count, Ordering::SeqCst);
            TEST_TIMEOUT.store(timeout_count, Ordering::SeqCst);

            // 避免过于频繁的请求
            tokio::time::sleep(std::time::Duration::from_millis(200)).await;
        }

        // 测试完成
        add_test_log(format!("🎉 测试完成！有效: {}, 无效: {}, 超时: {}",
                           valid_count, invalid_count, timeout_count));
        
        TEST_COMPLETED.store(true, Ordering::SeqCst);
        TEST_RUNNING.store(false, Ordering::SeqCst);
    });

    Ok(Json(json!({
        "success": true,
        "message": format!("API密钥测试已开始，将测试 {} 个密钥，最大重试次数: {}", key_count, max_retry)
    })))
}

/// 测试单个API密钥
async fn test_single_api_key(api_key: String) -> std::result::Result<bool, String> {
    use reqwest;
    
    let url = format!("https://generativelanguage.googleapis.com/v1beta/models?key={}", api_key);
    
    let client = reqwest::Client::new();
    let response = client
        .get(&url)
        .timeout(std::time::Duration::from_secs(10))
        .send()
        .await
        .map_err(|e| format!("网络请求失败: {}", e))?;

    let status = response.status();
    
    if status.is_success() {
        Ok(true)
    } else if status == reqwest::StatusCode::UNAUTHORIZED {
        Ok(false) // 明确的无效密钥
    } else if status == reqwest::StatusCode::FORBIDDEN {
        Ok(false) // 密钥被禁用
    } else {
        let error_body = response.text().await.unwrap_or_default();
        Err(format!("HTTP {}: {}", status.as_u16(),
                   if error_body.is_empty() { "未知错误" } else { &error_body[..100.min(error_body.len())] }))
    }
}

/// 获取测试进度
pub async fn get_test_progress() -> Json<Value> {
    let completed = TEST_PROGRESS.load(Ordering::SeqCst);
    let total = TEST_TOTAL.load(Ordering::SeqCst);
    let valid = TEST_VALID.load(Ordering::SeqCst);
    let invalid = TEST_INVALID.load(Ordering::SeqCst);
    let timeout = TEST_TIMEOUT.load(Ordering::SeqCst);
    let is_completed = TEST_COMPLETED.load(Ordering::SeqCst);
    let is_running = TEST_RUNNING.load(Ordering::SeqCst);
    let logs = get_test_logs();

    let progress_percentage = if total > 0 {
        (completed as f64 / total as f64 * 100.0).round()
    } else {
        0.0
    };

    Json(json!({
        "completed": completed,
        "total": total,
        "valid": valid,
        "invalid": invalid,
        "timeout": timeout,
        "is_completed": is_completed,
        "is_running": is_running,
        "progress_percentage": progress_percentage,
        "progress_text": if total > 0 {
            format!("{}/{}", completed, total)
        } else {
            "0/0".to_string()
        },
        "status_summary": if is_completed {
            format!("测试完成 - 有效: {}, 无效: {}, 超时: {}", valid, invalid, timeout)
        } else if is_running {
            format!("测试中... ({}/{})", completed, total)
        } else {
            "准备就绪".to_string()
        },
        "logs": logs.iter().rev().take(50).rev().collect::<Vec<_>>(), // 最新50条日志
        "timestamp": chrono::Utc::now().timestamp()
    }))
}

/// 清除无效密钥
pub async fn clear_invalid_keys(
    State(app_state): State<AppState>,
    Json(request): Json<ClearInvalidKeysRequest>,
) -> Result<Json<Value>> {
    info!("🧹 清除无效密钥请求");

    // 验证密码
    if request.password != app_state.config.web_password {
        return Err(Error::Auth("密码验证失败".to_string()));
    }

    let removed_count = app_state.services.api_keys.remove_invalid_keys().await;

    Ok(Json(json!({
        "success": true,
        "message": format!("已清除 {} 个无效密钥", removed_count)
    })))
}

/// 获取无效密钥列表
pub async fn get_invalid_keys(State(app_state): State<AppState>) -> Json<Value> {
    let invalid_keys = app_state.services.api_keys.get_invalid_keys().await;

    Json(json!({
        "success": true,
        "count": invalid_keys.len(),
        "keys": invalid_keys,
        "message": format!("发现 {} 个无效密钥", invalid_keys.len())
    }))
}

/// 获取系统状态
pub async fn get_stats(State(app_state): State<AppState>) -> Result<Json<Value>> {
    let key_stats = app_state.services.api_keys.get_stats().await;
    let cache_stats = app_state.services.cache.get_stats();

    Ok(Json(json!({
        "performance": {
            "connection_pool": {
                "max_concurrent": app_state.config.performance.max_concurrent_requests,
                "available": app_state.config.performance.max_concurrent_requests,
                "in_use": 0,
                "utilization_percent": 0.0
            },
            "api_keys": {
                "total_count": key_stats.total,
                "active_count": key_stats.active,
                "invalid_count": key_stats.invalid,
                "rate_limited_count": key_stats.rate_limited,
                "has_keys": key_stats.active > 0
            },
            "cache": {
                "entries": cache_stats.valid_items,
                "total_items": cache_stats.total_items,
                "expired_items": cache_stats.expired_items,
                "expiry_seconds": app_state.config.performance.cache_expiry_seconds
            }
        },
        "timestamp": chrono::Utc::now().timestamp()
    })))
}

/// 带查重功能的设置API密钥
pub async fn set_api_keys_with_duplicate_check(
    State(app_state): State<AppState>,
    Json(request): Json<SetApiKeysWithDuplicateCheckRequest>,
) -> Result<Json<Value>> {
    info!("🔍 收到带查重功能的API密钥设置请求");

    // 验证密码
    if request.password != app_state.config.web_password {
        return Err(Error::Auth("密码验证失败".to_string()));
    }

    let keys: Vec<String> = request
        .api_keys
        .split(',')
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();

    if keys.is_empty() {
        return Err(Error::Validation("未提供有效的API密钥".to_string()));
    }

    // 使用增强的查重功能
    let duplicate_result = app_state.services.api_keys
        .add_keys_with_duplicate_check(keys).await;

    info!("🔍 查重结果: 添加 {} 个, 跳过 {} 个重复, 发现 {} 个相似密钥",
          duplicate_result.added_count, duplicate_result.skipped_count, duplicate_result.similar.len());

    Ok(Json(json!({
        "success": true,
        "message": format!("密钥处理完成: 添加 {} 个, 跳过 {} 个重复",
                          duplicate_result.added_count, duplicate_result.skipped_count),
        "duplicate_check": {
            "added_count": duplicate_result.added_count,
            "skipped_count": duplicate_result.skipped_count,
            "duplicates": duplicate_result.duplicates,
            "similar_pairs": duplicate_result.similar,
        }
    })))
}

/// 批量验证密钥（增强版）
pub async fn batch_validate_keys(
    State(app_state): State<AppState>,
    Json(request): Json<BatchValidateKeysRequest>,
) -> Result<Json<Value>> {
    info!("🧪 开始批量验证API密钥（增强版）");

    // 验证密码
    if request.password != app_state.config.web_password {
        return Err(Error::Auth("密码验证失败".to_string()));
    }

    // 执行批量验证
    let validation_result = app_state.services.api_keys
        .batch_validate_keys(app_state.services.gemini.clone(), request.max_concurrent).await;

    info!("✅ 批量验证完成: 有效 {}, 无效 {}, 超时 {}, 耗时 {}ms",
          validation_result.valid, validation_result.invalid,
          validation_result.timeout, validation_result.duration_ms);

    Ok(Json(json!({
        "success": true,
        "message": format!("批量验证完成: 有效 {}, 无效 {}, 超时 {}",
                          validation_result.valid, validation_result.invalid, validation_result.timeout),
        "validation_result": {
            "total": validation_result.total,
            "valid": validation_result.valid,
            "invalid": validation_result.invalid,
            "timeout": validation_result.timeout,
            "duration_ms": validation_result.duration_ms,
            "failed_keys": validation_result.failed_keys,
        }
    })))
}

/// 生成密钥健康度报告
pub async fn generate_health_report(
    State(app_state): State<AppState>,
    Json(request): Json<HealthReportRequest>,
) -> Result<Json<Value>> {
    info!("📊 生成密钥健康度报告");

    // 验证密码
    if request.password != app_state.config.web_password {
        return Err(Error::Auth("密码验证失败".to_string()));
    }

    // 生成健康度报告
    let health_report = app_state.services.api_keys.generate_health_report().await;

    info!("📊 健康度报告: 总计 {} 个密钥, 健康 {} 个, 警告 {} 个, 关键 {} 个",
          health_report.total_keys, health_report.healthy_keys,
          health_report.warning_keys, health_report.critical_keys);

    Ok(Json(json!({
        "success": true,
        "message": format!("健康度报告已生成: 总计 {} 个密钥", health_report.total_keys),
        "health_report": {
            "total_keys": health_report.total_keys,
            "healthy_keys": health_report.healthy_keys,
            "warning_keys": health_report.warning_keys,
            "critical_keys": health_report.critical_keys,
            "key_details": health_report.key_details,
            "recommendations": health_report.recommendations,
        }
    })))
}

/// 获取测试日志API
pub async fn get_test_logs_api() -> Json<Value> {
    let logs = get_test_logs();
    let is_running = TEST_RUNNING.load(Ordering::SeqCst);
    let completed = TEST_PROGRESS.load(Ordering::SeqCst);
    let total = TEST_TOTAL.load(Ordering::SeqCst);

    Json(json!({
        "logs": logs,
        "log_count": logs.len(),
        "is_running": is_running,
        "progress": if total > 0 { format!("{}/{}", completed, total) } else { "0/0".to_string() },
        "timestamp": chrono::Utc::now().timestamp()
    }))
}

/// 清空测试日志
pub async fn clear_test_logs_api(
    State(app_state): State<AppState>,
    Json(request): Json<ClearInvalidKeysRequest>, // 复用密码验证结构
) -> Result<Json<Value>> {
    // 验证密码
    if request.password != app_state.config.web_password {
        return Err(Error::Auth("密码验证失败".to_string()));
    }

    clear_test_logs();
    Ok(Json(json!({
        "success": true,
        "message": "测试日志已清空"
    })))
}

/// 获取密钥详细统计信息（增强版）
pub async fn get_enhanced_key_stats(
    State(app_state): State<AppState>,
    query: Option<Query<AuthQuery>>,
) -> Result<Json<Value>> {
    // 验证密码（可选）
    if let Some(Query(auth)) = query {
        if let Some(password) = auth.password {
            if password != app_state.config.web_password {
                return Err(Error::Auth("密码验证失败".to_string()));
            }
        }
    }

    let key_stats = app_state.services.api_keys.get_stats().await;
    let all_keys_info = app_state.services.api_keys.get_all_keys_info().await;
    let health_report = app_state.services.api_keys.generate_health_report().await;

    // 计算额外统计信息
    let total_usage: usize = all_keys_info.iter().map(|info| info.usage_count).sum();
    let total_errors: usize = all_keys_info.iter().map(|info| info.error_count).sum();
    let overall_error_rate = if total_usage > 0 {
        total_errors as f64 / total_usage as f64
    } else {
        0.0
    };

    Ok(Json(json!({
        "basic_stats": {
            "total_keys": key_stats.total,
            "active_keys": key_stats.active,
            "invalid_keys": key_stats.invalid,
            "rate_limited_keys": key_stats.rate_limited,
        },
        "usage_stats": {
            "total_usage": total_usage,
            "total_errors": total_errors,
            "overall_error_rate": overall_error_rate,
            "average_usage_per_key": if key_stats.total > 0 { total_usage / key_stats.total } else { 0 },
        },
        "health_summary": {
            "healthy_keys": health_report.healthy_keys,
            "warning_keys": health_report.warning_keys,
            "critical_keys": health_report.critical_keys,
            "health_percentage": if key_stats.total > 0 {
                health_report.healthy_keys as f64 / key_stats.total as f64 * 100.0
            } else { 0.0 },
        },
        "keys_detail": all_keys_info,
        "recommendations": health_report.recommendations,
        "timestamp": chrono::Utc::now().timestamp()
    })))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_atomic_operations() {
        TEST_PROGRESS.store(5, Ordering::SeqCst);
        assert_eq!(TEST_PROGRESS.load(Ordering::SeqCst), 5);
        
        TEST_COMPLETED.store(true, Ordering::SeqCst);
        assert_eq!(TEST_COMPLETED.load(Ordering::SeqCst), true);
    }
}