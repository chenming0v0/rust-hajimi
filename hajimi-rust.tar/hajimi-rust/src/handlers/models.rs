//! 模型列表API处理器

use crate::{
    app::AppState,
    error::Result,
    models::*,
    services::cache::CacheKeyGenerator,
};
use axum::{
    extract::State,
    response::Json,
};
use tracing::{info, warn};

/// 获取可用模型列表
pub async fn list_models(State(app_state): State<AppState>) -> Result<Json<ModelsResponse>> {
    info!("📋 请求模型列表");

    // 检查是否有可用的API密钥
    if !app_state.services.has_api_keys().await {
        warn!("❌ 没有可用的API密钥，返回空模型列表");
        return Ok(Json(ModelsResponse {
            object: "list".to_string(),
            data: vec![],
        }));
    }

    // 尝试从缓存获取
    let api_key = match app_state.services.get_available_api_key().await {
        Some(key) => key,
        None => {
            return Ok(Json(ModelsResponse {
                object: "list".to_string(),
                data: vec![],
            }));
        }
    };

    let cache_key = CacheKeyGenerator::models_key(
        CacheKeyGenerator::hash_string(&api_key)
    );

    if let Some(cached_models) = app_state.services.cache.get(&cache_key).await {
        if let Ok(models_response) = serde_json::from_str::<ModelsResponse>(&cached_models) {
            info!("🎯 模型列表缓存命中");
            return Ok(Json(models_response));
        }
    }

    // 从API获取模型列表
    match app_state.services.gemini.list_models(&api_key).await {
        Ok(model_names) => {
            info!("✅ 获取到 {} 个模型", model_names.len());

            let models: Vec<Model> = model_names
                .into_iter()
                .map(|name| Model {
                    id: name,
                    object: "model".to_string(),
                    created: chrono::Utc::now().timestamp() as u64,
                    owned_by: "google".to_string(),
                })
                .collect();

            let response = ModelsResponse {
                object: "list".to_string(),
                data: models,
            };

            // 缓存结果（24小时）
            let response_json = serde_json::to_string(&response)?;
            app_state.services.cache.set_with_ttl(
                cache_key,
                response_json,
                std::time::Duration::from_secs(86400),
            ).await;

            Ok(Json(response))
        }
        Err(e) => {
            warn!("❌ 获取模型列表失败: {}", e);
            
            // 返回默认模型列表
            let default_models = vec![
                "gemini-1.5-pro".to_string(),
                "gemini-1.5-flash".to_string(),
                "gemini-1.0-pro".to_string(),
            ];

            let models: Vec<Model> = default_models
                .into_iter()
                .map(|name| Model {
                    id: name,
                    object: "model".to_string(),
                    created: chrono::Utc::now().timestamp() as u64,
                    owned_by: "google".to_string(),
                })
                .collect();

            Ok(Json(ModelsResponse {
                object: "list".to_string(),
                data: models,
            }))
        }
    }
}

/// 获取支持的模型名称列表
pub fn get_supported_models() -> Vec<String> {
    vec![
        "gemini-1.5-pro".to_string(),
        "gemini-1.5-pro-latest".to_string(),
        "gemini-1.5-flash".to_string(),
        "gemini-1.5-flash-latest".to_string(),
        "gemini-1.0-pro".to_string(),
        "gemini-pro".to_string(),
        "gemini-pro-vision".to_string(),
        "gemini-2.0-flash-exp".to_string(),
    ]
}

/// 检查模型是否受支持
pub fn is_model_supported(model: &str) -> bool {
    model.starts_with("gemini") && !model.contains("embedding")
}

/// 获取模型的显示名称
pub fn get_model_display_name(model: &str) -> String {
    match model {
        "gemini-1.5-pro" => "Gemini 1.5 Pro".to_string(),
        "gemini-1.5-flash" => "Gemini 1.5 Flash".to_string(),
        "gemini-1.0-pro" => "Gemini 1.0 Pro".to_string(),
        "gemini-pro" => "Gemini Pro".to_string(),
        "gemini-pro-vision" => "Gemini Pro Vision".to_string(),
        _ => model.to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_model_supported() {
        assert!(is_model_supported("gemini-1.5-pro"));
        assert!(is_model_supported("gemini-pro"));
        assert!(!is_model_supported("gpt-4"));
        assert!(!is_model_supported("gemini-embedding"));
    }

    #[test]
    fn test_get_model_display_name() {
        assert_eq!(get_model_display_name("gemini-1.5-pro"), "Gemini 1.5 Pro");
        assert_eq!(get_model_display_name("unknown-model"), "unknown-model");
    }
}