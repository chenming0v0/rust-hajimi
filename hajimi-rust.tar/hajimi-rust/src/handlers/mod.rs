//! HTTP请求处理器模块
//! 
//! 包含所有API端点的处理逻辑

pub mod chat;
pub mod dashboard;
pub mod models;
pub mod health;
pub mod admin;

pub use chat::chat_completions;
pub use dashboard::{dashboard, get_dashboard_data};
pub use models::list_models;
pub use health::health_check;
pub use admin::{
    get_stats,
    update_config,
    set_api_keys,
    get_key_info,
    test_api_keys,
    get_test_progress,
    clear_invalid_keys,
    get_invalid_keys,
    // 新增的增强功能
    set_api_keys_with_duplicate_check,
    batch_validate_keys,
    generate_health_report,
    get_enhanced_key_stats,
    get_test_logs_api,
    clear_test_logs_api,
};