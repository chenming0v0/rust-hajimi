//! 工具模块
//! 
//! 提供各种实用工具函数和结构

pub mod rate_limiter;
pub mod connection_manager;
pub mod auth;

pub use rate_limiter::RateLimiter;
pub use connection_manager::ConnectionManager;
pub use auth::AuthValidator;

use std::time::{SystemTime, UNIX_EPOCH};

/// 生成唯一ID
pub fn generate_id() -> String {
    format!("hajimi-{}", uuid::Uuid::new_v4())
}

/// 获取当前时间戳
pub fn current_timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs()
}

/// 计算字符串哈希值
pub fn hash_string(input: &str) -> u64 {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};

    let mut hasher = DefaultHasher::new();
    input.hash(&mut hasher);
    hasher.finish()
}

/// 掩码处理敏感信息
pub fn mask_sensitive(input: &str, show_start: usize, show_end: usize) -> String {
    if input.len() <= show_start + show_end {
        return "***".to_string();
    }

    format!(
        "{}...{}",
        &input[..show_start],
        &input[input.len() - show_end..]
    )
}

/// 格式化文件大小
pub fn format_bytes(bytes: u64) -> String {
    const UNITS: &[&str] = &["B", "KB", "MB", "GB", "TB"];
    const THRESHOLD: u64 = 1024;

    if bytes < THRESHOLD {
        return format!("{} B", bytes);
    }

    let mut size = bytes as f64;
    let mut unit_index = 0;

    while size >= THRESHOLD as f64 && unit_index < UNITS.len() - 1 {
        size /= THRESHOLD as f64;
        unit_index += 1;
    }

    format!("{:.1} {}", size, UNITS[unit_index])
}

/// 格式化持续时间
pub fn format_duration(seconds: u64) -> String {
    if seconds < 60 {
        format!("{}秒", seconds)
    } else if seconds < 3600 {
        format!("{}分{}秒", seconds / 60, seconds % 60)
    } else if seconds < 86400 {
        let hours = seconds / 3600;
        let minutes = (seconds % 3600) / 60;
        format!("{}时{}分", hours, minutes)
    } else {
        let days = seconds / 86400;
        let hours = (seconds % 86400) / 3600;
        format!("{}天{}时", days, hours)
    }
}

/// 验证电子邮件格式
pub fn is_valid_email(email: &str) -> bool {
    email.contains('@') && email.contains('.') && email.len() > 5
}

/// 验证URL格式
pub fn is_valid_url(url: &str) -> bool {
    url.starts_with("http://") || url.starts_with("https://")
}

/// 安全字符串比较（防时序攻击）
pub fn constant_time_compare(a: &str, b: &str) -> bool {
    if a.len() != b.len() {
        return false;
    }

    let mut result = 0u8;
    for (char_a, char_b) in a.bytes().zip(b.bytes()) {
        result |= char_a ^ char_b;
    }

    result == 0
}

/// 截断字符串到指定长度
pub fn truncate_string(input: &str, max_len: usize) -> String {
    if input.len() <= max_len {
        input.to_string()
    } else {
        format!("{}...", &input[..max_len.saturating_sub(3)])
    }
}

/// 清理和验证模型名称
pub fn sanitize_model_name(model: &str) -> String {
    model
        .chars()
        .filter(|c| c.is_alphanumeric() || *c == '-' || *c == '.' || *c == '_')
        .collect()
}

/// 提取客户端真实IP
pub fn extract_real_ip(headers: &axum::http::HeaderMap) -> String {
    // 尝试从各种头部获取真实IP
    let ip_headers = [
        "cf-connecting-ip",    // Cloudflare
        "x-forwarded-for",     // 标准代理头
        "x-real-ip",           // Nginx
        "x-client-ip",         // Apache
        "x-forwarded",
        "forwarded-for",
        "forwarded",
    ];

    for header_name in &ip_headers {
        if let Some(header_value) = headers.get(*header_name) {
            if let Ok(header_str) = header_value.to_str() {
                // 处理逗号分隔的IP列表，取第一个
                let ip = header_str.split(',').next().unwrap_or("").trim();
                if !ip.is_empty() && ip != "unknown" {
                    return ip.to_string();
                }
            }
        }
    }

    "unknown".to_string()
}

/// 简单的API密钥验证
pub fn validate_api_key_format(key: &str) -> bool {
    // Google API密钥通常是39个字符的字母数字字符串
    key.len() >= 30 && key.chars().all(|c| c.is_alphanumeric() || c == '-' || c == '_')
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mask_sensitive() {
        assert_eq!(mask_sensitive("AIzaSyABCDEFGHIJKLMNOPQRSTUVWXYZ123456", 8, 4), "AIzaSyAB...3456");
        assert_eq!(mask_sensitive("short", 8, 4), "***");
    }

    #[test]
    fn test_format_bytes() {
        assert_eq!(format_bytes(500), "500 B");
        assert_eq!(format_bytes(1536), "1.5 KB");
        assert_eq!(format_bytes(1048576), "1.0 MB");
    }

    #[test]
    fn test_format_duration() {
        assert_eq!(format_duration(30), "30秒");
        assert_eq!(format_duration(90), "1分30秒");
        assert_eq!(format_duration(3700), "1时1分");
    }

    #[test]
    fn test_is_valid_email() {
        assert!(is_valid_email("user@example.com"));
        assert!(!is_valid_email("invalid-email"));
        assert!(!is_valid_email("user@"));
    }

    #[test]
    fn test_constant_time_compare() {
        assert!(constant_time_compare("hello", "hello"));
        assert!(!constant_time_compare("hello", "world"));
        assert!(!constant_time_compare("hello", "hello!"));
    }

    #[test]
    fn test_truncate_string() {
        assert_eq!(truncate_string("Hello World", 5), "He...");
        assert_eq!(truncate_string("Hi", 10), "Hi");
    }

    #[test]
    fn test_sanitize_model_name() {
        assert_eq!(sanitize_model_name("gemini-1.5-pro"), "gemini-1.5-pro");
        assert_eq!(sanitize_model_name("gemini@#$%1.5"), "gemini1.5");
    }

    #[test]
    fn test_validate_api_key_format() {
        assert!(validate_api_key_format("AIzaSyABCDEFGHIJKLMNOPQRSTUVWXYZ123456"));
        assert!(!validate_api_key_format("too-short"));
        assert!(!validate_api_key_format(""));
    }
}