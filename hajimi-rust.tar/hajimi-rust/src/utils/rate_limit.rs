use std::collections::HashMap;
use std::sync::atomic::{AtomicU64, AtomicU32, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use tokio::sync::RwLock;

/// 高并发优化的令牌桶限流器
#[derive(Debug)]
struct TokenBucket {
    /// 令牌数量（原子操作，无锁）
    tokens: AtomicU32,
    /// 最大令牌数
    max_tokens: u32,
    /// 令牌补充速率（每秒）
    refill_rate: u32,
    /// 上次补充时间（纳秒时间戳）
    last_refill: AtomicU64,
}

impl TokenBucket {
    fn new(max_tokens: u32, refill_rate: u32) -> Self {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos() as u64;
            
        Self {
            tokens: AtomicU32::new(max_tokens),
            max_tokens,
            refill_rate,
            last_refill: AtomicU64::new(now),
        }
    }

    /// 尝试获取令牌（无锁操作）
    fn try_acquire(&self, tokens_needed: u32) -> bool {
        // 先补充令牌
        self.refill_tokens();
        
        // 使用 CAS 操作尝试获取令牌
        loop {
            let current_tokens = self.tokens.load(Ordering::Acquire);
            
            if current_tokens < tokens_needed {
                return false; // 令牌不足
            }
            
            let new_tokens = current_tokens - tokens_needed;
            
            // 原子性地更新令牌数量
            match self.tokens.compare_exchange_weak(
                current_tokens,
                new_tokens,
                Ordering::Release,
                Ordering::Relaxed,
            ) {
                Ok(_) => return true,  // 成功获取令牌
                Err(_) => continue,    // CAS 失败，重试
            }
        }
    }

    /// 补充令牌（无锁操作）
    fn refill_tokens(&self) {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos() as u64;
            
        let last_refill = self.last_refill.load(Ordering::Acquire);
        let time_elapsed = now.saturating_sub(last_refill);
        
        // 计算应该补充的令牌数
        let tokens_to_add = (time_elapsed as f64 / 1_000_000_000.0 * self.refill_rate as f64) as u32;
        
        if tokens_to_add > 0 {
            // 使用 CAS 更新时间戳
            if self.last_refill.compare_exchange_weak(
                last_refill,
                now,
                Ordering::Release,
                Ordering::Relaxed,
            ).is_ok() {
                // 原子性地增加令牌数量
                loop {
                    let current_tokens = self.tokens.load(Ordering::Acquire);
                    let new_tokens = (current_tokens + tokens_to_add).min(self.max_tokens);
                    
                    if self.tokens.compare_exchange_weak(
                        current_tokens,
                        new_tokens,
                        Ordering::Release,
                        Ordering::Relaxed,
                    ).is_ok() {
                        break;
                    }
                }
            }
        }
    }

    fn get_available_tokens(&self) -> u32 {
        self.refill_tokens();
        self.tokens.load(Ordering::Acquire)
    }
}

/// 高并发限流管理器
#[derive(Debug)]
pub struct RateLimiter {
    /// 每分钟限流器映射
    minute_buckets: Arc<RwLock<HashMap<String, Arc<TokenBucket>>>>,
    /// 每日限流器映射
    daily_buckets: Arc<RwLock<HashMap<String, Arc<TokenBucket>>>>,
    /// 全局限流器（防止系统过载）
    global_bucket: Arc<TokenBucket>,
    /// 配置参数
    max_requests_per_minute: u32,
    max_requests_per_day: u32,
    /// 清理任务间隔
    cleanup_interval: Duration,
    /// 上次清理时间
    last_cleanup: AtomicU64,
}

impl RateLimiter {
    pub fn new(max_requests_per_minute: u32, max_requests_per_day: u32) -> Self {
        // 全局限流器：防止系统过载，设置为单个用户限制的10倍
        let global_limit = max_requests_per_minute * 10;
        
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos() as u64;

        Self {
            minute_buckets: Arc::new(RwLock::new(HashMap::new())),
            daily_buckets: Arc::new(RwLock::new(HashMap::new())),
            global_bucket: Arc::new(TokenBucket::new(global_limit, global_limit)),
            max_requests_per_minute,
            max_requests_per_day,
            cleanup_interval: Duration::from_secs(300), // 5分钟清理一次
            last_cleanup: AtomicU64::new(now),
        }
    }

    /// 高性能限流检查
    pub async fn check_rate_limit(&self, key: &str) -> bool {
        // 1. 全局限流检查（最快，无锁）
        if !self.global_bucket.try_acquire(1) {
            tracing::warn!("全局限流触发，系统负载过高");
            return false;
        }

        // 2. 用户级别限流检查
        let minute_result = self.check_minute_limit(key).await;
        let daily_result = self.check_daily_limit(key).await;

        // 3. 定期清理过期的限流器
        self.cleanup_expired_buckets().await;

        minute_result && daily_result
    }

    async fn check_minute_limit(&self, key: &str) -> bool {
        // 先尝试读锁获取现有的限流器
        {
            let buckets = self.minute_buckets.read().await;
            if let Some(bucket) = buckets.get(key) {
                return bucket.try_acquire(1);
            }
        }

        // 如果不存在，创建新的限流器
        let mut buckets = self.minute_buckets.write().await;
        
        // 双重检查，防止并发创建
        if let Some(bucket) = buckets.get(key) {
            return bucket.try_acquire(1);
        }

        // 创建新的令牌桶
        let bucket = Arc::new(TokenBucket::new(
            self.max_requests_per_minute,
            self.max_requests_per_minute,
        ));
        
        buckets.insert(key.to_string(), bucket.clone());
        bucket.try_acquire(1)
    }

    async fn check_daily_limit(&self, key: &str) -> bool {
        // 每日限流器的补充速率：每天的请求数 / 86400秒
        let daily_refill_rate = (self.max_requests_per_day as f64 / 86400.0).ceil() as u32;
        
        // 先尝试读锁获取现有的限流器
        {
            let buckets = self.daily_buckets.read().await;
            if let Some(bucket) = buckets.get(key) {
                return bucket.try_acquire(1);
            }
        }

        // 如果不存在，创建新的限流器
        let mut buckets = self.daily_buckets.write().await;
        
        // 双重检查
        if let Some(bucket) = buckets.get(key) {
            return bucket.try_acquire(1);
        }

        // 创建新的令牌桶
        let bucket = Arc::new(TokenBucket::new(
            self.max_requests_per_day,
            daily_refill_rate.max(1), // 至少每秒补充1个令牌
        ));
        
        buckets.insert(key.to_string(), bucket.clone());
        bucket.try_acquire(1)
    }

    /// 定期清理过期的限流器，防止内存泄漏
    async fn cleanup_expired_buckets(&self) {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos() as u64;
            
        let last_cleanup = self.last_cleanup.load(Ordering::Acquire);
        
        if now - last_cleanup < self.cleanup_interval.as_nanos() as u64 {
            return; // 还没到清理时间
        }

        // 使用 CAS 确保只有一个线程执行清理
        if self.last_cleanup.compare_exchange_weak(
            last_cleanup,
            now,
            Ordering::Release,
            Ordering::Relaxed,
        ).is_err() {
            return; // 其他线程正在清理
        }

        // 清理分钟级限流器（保留最近5分钟的）
        {
            let mut buckets = self.minute_buckets.write().await;
            buckets.retain(|_, bucket| {
                bucket.get_available_tokens() < bucket.max_tokens || 
                bucket.last_refill.load(Ordering::Acquire) > now - 300_000_000_000 // 5分钟
            });
        }

        // 清理日级限流器（保留最近2天的）
        {
            let mut buckets = self.daily_buckets.write().await;
            buckets.retain(|_, bucket| {
                bucket.get_available_tokens() < bucket.max_tokens || 
                bucket.last_refill.load(Ordering::Acquire) > now - 172_800_000_000_000 // 2天
            });
        }

        tracing::debug!("限流器清理完成");
    }

    /// 获取限流统计信息
    pub async fn get_rate_limit_stats(&self, key: &str) -> (u32, u32, u32) {
        let minute_tokens = {
            let buckets = self.minute_buckets.read().await;
            buckets.get(key)
                .map(|b| b.get_available_tokens())
                .unwrap_or(self.max_requests_per_minute)
        };

        let daily_tokens = {
            let buckets = self.daily_buckets.read().await;
            buckets.get(key)
                .map(|b| b.get_available_tokens())
                .unwrap_or(self.max_requests_per_day)
        };

        let global_tokens = self.global_bucket.get_available_tokens();

        (minute_tokens, daily_tokens, global_tokens)
    }

    /// 重置特定用户的限流
    pub async fn reset_limits(&self, key: &str) {
        {
            let mut buckets = self.minute_buckets.write().await;
            buckets.remove(key);
        }
        {
            let mut buckets = self.daily_buckets.write().await;
            buckets.remove(key);
        }
        tracing::info!("已重置用户 {} 的限流状态", key);
    }

    /// 获取系统级别的限流统计
    pub async fn get_system_stats(&self) -> HashMap<String, u64> {
        let minute_count = self.minute_buckets.read().await.len() as u64;
        let daily_count = self.daily_buckets.read().await.len() as u64;
        let global_tokens = self.global_bucket.get_available_tokens() as u64;

        let mut stats = HashMap::new();
        stats.insert("active_minute_limiters".to_string(), minute_count);
        stats.insert("active_daily_limiters".to_string(), daily_count);
        stats.insert("global_available_tokens".to_string(), global_tokens);
        stats.insert("max_requests_per_minute".to_string(), self.max_requests_per_minute as u64);
        stats.insert("max_requests_per_day".to_string(), self.max_requests_per_day as u64);

        stats
    }
}

/// 高并发场景下的性能优化
impl RateLimiter {
    /// 批量检查多个请求的限流状态
    pub async fn batch_check_rate_limit(&self, keys: &[String]) -> Vec<bool> {
        let mut results = Vec::with_capacity(keys.len());
        
        for key in keys {
            results.push(self.check_rate_limit(key).await);
        }
        
        results
    }

    /// 预热限流器（在系统启动时调用）
    pub async fn warmup(&self, expected_keys: &[String]) {
        tracing::info!("开始预热限流器，预期用户数: {}", expected_keys.len());
        
        for key in expected_keys {
            // 创建限流器但不消耗令牌
            self.check_minute_limit(key).await;
            self.check_daily_limit(key).await;
        }
        
        tracing::info!("限流器预热完成");
    }
}