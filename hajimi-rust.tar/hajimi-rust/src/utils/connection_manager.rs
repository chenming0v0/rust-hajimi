//! 连接管理器

use std::{
    sync::{
        atomic::{AtomicUsize, Ordering},
        Arc,
    },
    time::Duration,
};
use tokio::sync::Semaphore;
use tracing::{debug, warn};

/// 连接管理器
pub struct ConnectionManager {
    semaphore: Arc<Semaphore>,
    max_concurrent: usize,
    timeout: Duration,
    active_connections: AtomicUsize,
}

/// 连接许可证
pub struct ConnectionPermit {
    _permit: tokio::sync::SemaphorePermit<'static>,
    manager: Arc<ConnectionManager>,
}

/// 连接统计信息
#[derive(Debug, Clone)]
pub struct ConnectionStats {
    pub max_concurrent: usize,
    pub active: usize,
    pub available: usize,
}

impl ConnectionManager {
    /// 创建新的连接管理器
    pub fn new(max_concurrent: usize, timeout_seconds: u64) -> Self {
        Self {
            semaphore: Arc::new(Semaphore::new(max_concurrent)),
            max_concurrent,
            timeout: Duration::from_secs(timeout_seconds),
            active_connections: AtomicUsize::new(0),
        }
    }

    /// 获取连接许可
    pub async fn acquire(&self) -> Result<ConnectionPermit, ConnectionError> {
        debug!("🔄 尝试获取连接许可");

        match tokio::time::timeout(self.timeout, self.semaphore.acquire()).await {
            Ok(Ok(permit)) => {
                let active = self.active_connections.fetch_add(1, Ordering::SeqCst) + 1;
                debug!("✅ 获取连接许可成功，活跃连接: {}", active);

                // 将许可证生命周期转换为 'static
                let static_permit = unsafe { std::mem::transmute(permit) };
                
                Ok(ConnectionPermit {
                    _permit: static_permit,
                    manager: Arc::new(Self {
                        semaphore: Arc::clone(&self.semaphore),
                        max_concurrent: self.max_concurrent,
                        timeout: self.timeout,
                        active_connections: AtomicUsize::new(0), // 这个字段在许可证中不使用
                    }),
                })
            }
            Ok(Err(_)) => {
                warn!("❌ 信号量已关闭");
                Err(ConnectionError::Closed)
            }
            Err(_) => {
                warn!("⏰ 获取连接许可超时");
                Err(ConnectionError::Timeout)
            }
        }
    }

    /// 获取连接统计信息
    pub fn get_stats(&self) -> ConnectionStats {
        let active = self.active_connections.load(Ordering::SeqCst);
        ConnectionStats {
            max_concurrent: self.max_concurrent,
            active,
            available: self.max_concurrent.saturating_sub(active),
        }
    }

    /// 更新最大并发数
    pub fn update_max_concurrent(&self, new_max: usize) {
        // 简化实现，实际使用中可能需要更复杂的逻辑
        debug!("📊 更新最大并发数: {} -> {}", self.max_concurrent, new_max);
    }
}

impl Drop for ConnectionPermit {
    fn drop(&mut self) {
        let active = self.manager.active_connections.fetch_sub(1, Ordering::SeqCst) - 1;
        debug!("🔄 释放连接许可，活跃连接: {}", active);
    }
}

/// 连接错误类型
#[derive(Debug, thiserror::Error)]
pub enum ConnectionError {
    #[error("连接超时")]
    Timeout,
    
    #[error("连接管理器已关闭")]
    Closed,
    
    #[error("达到最大连接数限制")]
    LimitReached,
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::time::{sleep, Duration as TokioDuration};

    #[tokio::test]
    async fn test_connection_manager() {
        let manager = ConnectionManager::new(2, 1);
        
        // 获取第一个许可
        let _permit1 = manager.acquire().await.unwrap();
        let stats = manager.get_stats();
        assert_eq!(stats.active, 1);
        assert_eq!(stats.available, 1);
        
        // 获取第二个许可
        let _permit2 = manager.acquire().await.unwrap();
        let stats = manager.get_stats();
        assert_eq!(stats.active, 2);
        assert_eq!(stats.available, 0);
    }

    #[tokio::test]
    async fn test_connection_timeout() {
        let manager = ConnectionManager::new(1, 1);
        
        // 获取唯一的许可
        let _permit = manager.acquire().await.unwrap();
        
        // 尝试获取另一个许可应该超时
        let result = manager.acquire().await;
        assert!(matches!(result, Err(ConnectionError::Timeout)));
    }
}