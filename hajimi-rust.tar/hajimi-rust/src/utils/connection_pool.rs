use reqwest::Client;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Semaphore;
use tracing::{info, warn, error};

/// 高性能连接池管理器
#[derive(Debug, Clone)]
pub struct ConnectionPool {
    /// HTTP 客户端（内置连接池）
    client: Client,
    /// 并发请求信号量
    semaphore: Arc<Semaphore>,
    /// 最大并发数
    max_concurrent: usize,
    /// 连接超时时间
    timeout: Duration,
}

impl ConnectionPool {
    pub fn new(max_concurrent: usize, timeout_seconds: u64) -> Self {
        let timeout = Duration::from_secs(timeout_seconds);
        
        // 配置 HTTP 客户端，优化连接池
        let client = Client::builder()
            .pool_max_idle_per_host(20)           // 每个主机最大空闲连接数
            .pool_idle_timeout(Duration::from_secs(90))  // 空闲连接超时
            .timeout(timeout)                      // 请求超时
            .connect_timeout(Duration::from_secs(10))    // 连接超时
            .tcp_keepalive(Duration::from_secs(60))      // TCP keepalive
            // 移除强制HTTP/2，让客户端自动协商协议版本
            // .http2_prior_knowledge()               // 优先使用 HTTP/2
            .http2_adaptive_window(true)           // 自适应窗口大小
            .http1_title_case_headers()            // HTTP/1.1 兼容性
            .build()
            .expect("Failed to create HTTP client");

        info!("连接池初始化完成: 最大并发 {}, 超时 {}s", max_concurrent, timeout_seconds);

        Self {
            client,
            semaphore: Arc::new(Semaphore::new(max_concurrent)),
            max_concurrent,
            timeout,
        }
    }

    /// 获取 HTTP 客户端
    pub fn client(&self) -> &Client {
        &self.client
    }

    /// 获取请求许可（限制并发数）
    pub async fn acquire_permit(&self) -> Result<tokio::sync::SemaphorePermit<'_>, &'static str> {
        match self.semaphore.try_acquire() {
            Ok(permit) => Ok(permit),
            Err(_) => {
                warn!("连接池已满，等待可用连接...");
                
                // 使用超时等待
                match tokio::time::timeout(self.timeout, self.semaphore.acquire()).await {
                    Ok(Ok(permit)) => Ok(permit),
                    Ok(Err(_)) => Err("Semaphore closed"),
                    Err(_) => {
                        error!("等待连接池许可超时");
                        Err("Connection pool timeout")
                    }
                }
            }
        }
    }

    /// 获取当前可用连接数
    pub fn available_permits(&self) -> usize {
        self.semaphore.available_permits()
    }

    /// 获取连接池统计信息
    pub fn get_stats(&self) -> ConnectionPoolStats {
        ConnectionPoolStats {
            max_concurrent: self.max_concurrent,
            available: self.semaphore.available_permits(),
            in_use: self.max_concurrent - self.semaphore.available_permits(),
            timeout_seconds: self.timeout.as_secs(),
        }
    }
}

#[derive(Debug, Clone)]
pub struct ConnectionPoolStats {
    pub max_concurrent: usize,
    pub available: usize,
    pub in_use: usize,
    pub timeout_seconds: u64,
}