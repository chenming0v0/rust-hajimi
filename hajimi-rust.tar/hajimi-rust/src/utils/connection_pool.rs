use reqwest::Client;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::Semaphore;
use std::sync::RwLock;
use tracing::{info, warn, error};

/// 高性能连接池管理器
#[derive(Debug, Clone)]
pub struct ConnectionPool {
    /// HTTP 客户端（内置连接池）
    client: Client,
    /// 动态配置信息
    config: Arc<RwLock<PoolConfig>>,
}

#[derive(Debug)]
struct PoolConfig {
    /// 并发请求信号量
    semaphore: Arc<Semaphore>,
    /// 最大并发数
    max_concurrent: usize,
    /// 连接超时时间
    timeout: Duration,
}

impl ConnectionPool {
    pub fn new(max_concurrent: usize, timeout_seconds: u64) -> Self {
        let timeout = Duration::from_secs(timeout_seconds);
        
        // 配置 HTTP 客户端，优化连接池
        let client = Client::builder()
            .pool_max_idle_per_host(20)           // 每个主机最大空闲连接数
            .pool_idle_timeout(Duration::from_secs(90))  // 空闲连接超时
            .timeout(timeout)                      // 请求超时
            .connect_timeout(Duration::from_secs(10))    // 连接超时
            .tcp_keepalive(Duration::from_secs(60))      // TCP keepalive
            // 移除强制HTTP/2，让客户端自动协商协议版本
            // .http2_prior_knowledge()               // 优先使用 HTTP/2
            .http2_adaptive_window(true)           // 自适应窗口大小
            .http1_title_case_headers()            // HTTP/1.1 兼容性
            .build()
            .expect("Failed to create HTTP client");

        info!("连接池初始化完成: 最大并发 {}, 超时 {}s", max_concurrent, timeout_seconds);

        let config = PoolConfig {
            semaphore: Arc::new(Semaphore::new(max_concurrent)),
            max_concurrent,
            timeout,
        };

        Self {
            client,
            config: Arc::new(RwLock::new(config)),
        }
    }

    /// 获取 HTTP 客户端
    pub fn client(&self) -> &Client {
        &self.client
    }

    /// 检查是否有可用的连接许可
    pub async fn check_permit(&self) -> Result<(), &'static str> {
        let (semaphore, timeout) = {
            let config = self.config.read().unwrap();
            (config.semaphore.clone(), config.timeout)
        };

        match semaphore.clone().try_acquire_owned() {
            Ok(_permit) => {
                // permit会自动释放，只是用来检查是否有可用的许可
                Ok(())
            },
            Err(_) => {
                warn!("连接池已满，等待可用连接...");
                
                // 使用超时等待
                match tokio::time::timeout(timeout, semaphore.acquire_owned()).await {
                    Ok(Ok(_permit)) => {
                        // permit会自动释放
                        Ok(())
                    },
                    Ok(Err(_)) => Err("Semaphore closed"),
                    Err(_) => {
                        error!("等待连接池许可超时");
                        Err("Connection pool timeout")
                    }
                }
            }
        }
    }

    /// 获取请求许可（返回owned permit，避免生命周期问题）
    pub async fn acquire_permit(&self) -> Result<tokio::sync::OwnedSemaphorePermit, &'static str> {
        let (semaphore, timeout) = {
            let config = self.config.read().unwrap();
            (config.semaphore.clone(), config.timeout)
        };

        match semaphore.clone().try_acquire_owned() {
            Ok(permit) => Ok(permit),
            Err(_) => {
                warn!("连接池已满，等待可用连接...");
                
                // 使用超时等待
                match tokio::time::timeout(timeout, semaphore.acquire_owned()).await {
                    Ok(Ok(permit)) => Ok(permit),
                    Ok(Err(_)) => Err("Semaphore closed"),
                    Err(_) => {
                        error!("等待连接池许可超时");
                        Err("Connection pool timeout")
                    }
                }
            }
        }
    }

    /// 获取当前可用连接数
    pub fn available_permits(&self) -> usize {
        self.config.read().unwrap().semaphore.available_permits()
    }

    /// 获取连接池统计信息
    pub fn get_stats(&self) -> ConnectionPoolStats {
        let config = self.config.read().unwrap();
        
        ConnectionPoolStats {
            max_concurrent: config.max_concurrent,
            available: config.semaphore.available_permits(),
            in_use: config.max_concurrent - config.semaphore.available_permits(),
            timeout_seconds: config.timeout.as_secs(),
        }
    }

    /// 动态更新连接池最大并发数
    pub fn update_max_concurrent(&self, new_max: usize) {
        let mut config = self.config.write().unwrap();
        
        if new_max != config.max_concurrent {
            info!("🔄 更新连接池最大并发数: {} -> {}", config.max_concurrent, new_max);
            
            // 创建新的信号量
            let new_semaphore = Arc::new(Semaphore::new(new_max));
            
            // 更新配置
            config.semaphore = new_semaphore;
            config.max_concurrent = new_max;
            
            info!("✅ 连接池配置更新完成，新的最大并发数: {}", new_max);
        }
    }
}

#[derive(Debug, Clone)]
pub struct ConnectionPoolStats {
    pub max_concurrent: usize,
    pub available: usize,
    pub in_use: usize,
    pub timeout_seconds: u64,
}