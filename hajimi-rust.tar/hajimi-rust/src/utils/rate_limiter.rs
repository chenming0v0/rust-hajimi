//! 限流器实现

use std::{
    collections::HashMap,
    sync::{Arc, RwLock},
    time::{Duration, Instant},
};
use tracing::debug;

/// 限流器
pub struct RateLimiter {
    windows: Arc<RwLock<HashMap<String, RateLimitWindow>>>,
    requests_per_minute: u32,
    requests_per_day: u32,
}

/// 限流窗口
#[derive(Debug)]
struct RateLimitWindow {
    minute_requests: Vec<Instant>,
    day_requests: Vec<Instant>,
    last_cleanup: Instant,
}

impl RateLimiter {
    /// 创建新的限流器
    pub fn new(requests_per_minute: u32, requests_per_day: u32) -> Self {
        Self {
            windows: Arc::new(RwLock::new(HashMap::new())),
            requests_per_minute,
            requests_per_day,
        }
    }

    /// 检查是否允许请求
    pub async fn check_rate_limit(&self, client_id: &str) -> bool {
        let now = Instant::now();
        
        if let Ok(mut windows) = self.windows.write() {
            let window = windows.entry(client_id.to_string()).or_insert_with(|| {
                RateLimitWindow {
                    minute_requests: Vec::new(),
                    day_requests: Vec::new(),
                    last_cleanup: now,
                }
            });

            // 清理过期请求
            self.cleanup_window(window, now);

            // 检查分钟限制
            if window.minute_requests.len() >= self.requests_per_minute as usize {
                debug!("🚫 客户端 {} 触发分钟限流", client_id);
                return false;
            }

            // 检查日限制
            if window.day_requests.len() >= self.requests_per_day as usize {
                debug!("🚫 客户端 {} 触发日限流", client_id);
                return false;
            }

            // 记录请求
            window.minute_requests.push(now);
            window.day_requests.push(now);

            debug!("✅ 客户端 {} 通过限流检查", client_id);
            true
        } else {
            // 锁获取失败，允许通过
            true
        }
    }

    /// 清理过期的请求记录
    fn cleanup_window(&self, window: &mut RateLimitWindow, now: Instant) {
        let minute_ago = now - Duration::from_secs(60);
        let day_ago = now - Duration::from_secs(86400);

        // 清理分钟窗口
        window.minute_requests.retain(|&time| time > minute_ago);
        
        // 清理日窗口
        window.day_requests.retain(|&time| time > day_ago);

        window.last_cleanup = now;
    }

    /// 获取客户端当前状态
    pub async fn get_client_status(&self, client_id: &str) -> Option<ClientRateStatus> {
        if let Ok(windows) = self.windows.read() {
            if let Some(window) = windows.get(client_id) {
                return Some(ClientRateStatus {
                    minute_requests: window.minute_requests.len(),
                    day_requests: window.day_requests.len(),
                    minute_limit: self.requests_per_minute,
                    day_limit: self.requests_per_day,
                });
            }
        }
        None
    }
}

/// 客户端限流状态
#[derive(Debug)]
pub struct ClientRateStatus {
    pub minute_requests: usize,
    pub day_requests: usize,
    pub minute_limit: u32,
    pub day_limit: u32,
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::time::{sleep, Duration as TokioDuration};

    #[tokio::test]
    async fn test_rate_limiter() {
        let limiter = RateLimiter::new(2, 10);
        
        // 前两个请求应该通过
        assert!(limiter.check_rate_limit("client1").await);
        assert!(limiter.check_rate_limit("client1").await);
        
        // 第三个请求应该被限制
        assert!(!limiter.check_rate_limit("client1").await);
        
        // 不同客户端不应该互相影响
        assert!(limiter.check_rate_limit("client2").await);
    }
}