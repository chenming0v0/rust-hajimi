use axum::{
    extract::{Query, State},
    http::{HeaderMap, StatusCode},
    response::Json,
};
use serde::{Deserialize, Serialize};
use tracing::{info, warn};

use crate::AppState;

#[derive(Deserialize)]
pub struct AuthQuery {
    key: Option<String>,
}

#[derive(Serialize)]
pub struct AuthError {
    pub error: String,
    pub message: String,
}

/// 验证API调用密码
pub async fn verify_password(
    headers: &HeaderMap,
    query: Option<Query<AuthQuery>>,
    state: &AppState,
) -> Result<(), (StatusCode, Json<AuthError>)> {
    let client_provided_key = extract_api_key(headers, query);
    
    if let Some(key) = client_provided_key {
        let config = state.config.read().unwrap();
        if key == config.password {
            return Ok(());
        }
    }
    
    warn!("API 密码验证失败");
    Err((
        StatusCode::UNAUTHORIZED,
        Json(AuthError {
            error: "Unauthorized".to_string(),
            message: "Invalid token".to_string(),
        }),
    ))
}

/// 验证网页管理密码
pub fn verify_web_password(password: &str, config_password: &str) -> bool {
    password == config_password
}

/// 从请求中提取API密钥
fn extract_api_key(headers: &HeaderMap, query: Option<Query<AuthQuery>>) -> Option<String> {
    // 1. 检查查询参数中的key
    if let Some(Query(auth_query)) = query {
        if let Some(key) = auth_query.key {
            if !key.is_empty() {
                return Some(key);
            }
        }
    }
    
    // 2. 检查x-goog-api-key头
    if let Some(x_goog_key) = headers.get("x-goog-api-key") {
        if let Ok(key_str) = x_goog_key.to_str() {
            if !key_str.is_empty() {
                return Some(key_str.to_string());
            }
        }
    }
    
    // 3. 检查Authorization头（Bearer格式）
    if let Some(auth_header) = headers.get("authorization") {
        if let Ok(auth_str) = auth_header.to_str() {
            if auth_str.starts_with("Bearer ") {
                let token = auth_str.strip_prefix("Bearer ").unwrap_or("");
                if !token.is_empty() {
                    return Some(token.to_string());
                }
            }
        }
    }
    
    None
}

/// API密钥管理请求结构
#[derive(Deserialize)]
pub struct SetApiKeysRequest {
    pub gemini_api_keys: String,
    pub password: String,
}

#[derive(Serialize)]
pub struct SetApiKeysResponse {
    pub success: bool,
    pub message: String,
    pub key_count: usize,
}

/// 设置API密钥的处理函数
pub async fn set_api_keys(
    State(state): State<AppState>,
    Json(request): Json<SetApiKeysRequest>,
) -> Result<Json<SetApiKeysResponse>, (StatusCode, Json<AuthError>)> {
    // 验证网页管理密码
    let web_password = {
        let config = state.config.read().unwrap();
        config.web_password.clone()
    };
    if !verify_web_password(&request.password, &web_password) {
        warn!("网页管理密码验证失败");
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(AuthError {
                error: "Unauthorized".to_string(),
                message: "Invalid web password".to_string(),
            }),
        ));
    }
    
    // 解析API密钥
    let keys: Vec<String> = request.gemini_api_keys
        .split(',')
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();
    
    // 设置新的API密钥
    state.api_key_manager.set_gemini_keys(keys).await;
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    
    info!("API 密钥已更新: {} 个", key_count);
    
    Ok(Json(SetApiKeysResponse {
        success: true,
        message: format!("Successfully updated {} API keys", key_count),
        key_count,
    }))
}

/// 获取API密钥信息
#[derive(Serialize)]
pub struct ApiKeyInfo {
    pub key_count: usize,
    pub has_keys: bool,
}

pub async fn get_api_key_info(
    State(state): State<AppState>,
) -> Json<ApiKeyInfo> {
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    let has_keys = key_count > 0;
    
    Json(ApiKeyInfo {
        key_count,
        has_keys,
    })
}