//! 认证工具

use crate::error::{Error, Result};
use axum::http::HeaderMap;
use base64::{Engine as _, engine::general_purpose};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{debug, warn};

/// 认证验证器
pub struct AuthValidator {
    secret_key: String,
    token_expiry_seconds: u64,
}

/// JWT载荷
#[derive(serde::Serialize, serde::Deserialize)]
struct TokenPayload {
    sub: String,  // subject
    exp: u64,     // expiration
    iat: u64,     // issued at
}

impl AuthValidator {
    /// 创建新的认证验证器
    pub fn new(secret_key: String, token_expiry_seconds: u64) -> Self {
        Self {
            secret_key,
            token_expiry_seconds,
        }
    }

    /// 验证密码
    pub fn verify_password(&self, provided: &str, expected: &str) -> bool {
        crate::utils::constant_time_compare(provided, expected)
    }

    /// 从请求头提取认证信息
    pub fn extract_auth_from_headers(&self, headers: &HeaderMap) -> Option<String> {
        // 尝试从Authorization头获取
        if let Some(auth_header) = headers.get("authorization") {
            if let Ok(auth_str) = auth_header.to_str() {
                if let Some(token) = auth_str.strip_prefix("Bearer ") {
                    return Some(token.to_string());
                }
                // 也支持直接使用password作为token
                return Some(auth_str.to_string());
            }
        }

        // 尝试从X-API-Key头获取
        if let Some(api_key_header) = headers.get("x-api-key") {
            if let Ok(key_str) = api_key_header.to_str() {
                return Some(key_str.to_string());
            }
        }

        None
    }

    /// 生成访问token（简化实现）
    pub fn generate_token(&self, user_id: &str) -> Result<String> {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();

        let payload = TokenPayload {
            sub: user_id.to_string(),
            exp: now + self.token_expiry_seconds,
            iat: now,
        };

        // 简化的token生成（实际应用中应使用proper JWT库）
        let payload_json = serde_json::to_string(&payload)?;
        let token = general_purpose::STANDARD.encode(
            format!("{}.{}", payload_json, self.secret_key).as_bytes()
        );

        debug!("生成访问token: {}...", &token[..16]);
        Ok(token)
    }

    /// 验证token（简化实现）
    pub fn verify_token(&self, token: &str) -> Result<String> {
        let decoded = general_purpose::STANDARD.decode(token)
            .map_err(|_| Error::Auth("无效的token格式".to_string()))?;

        let decoded_str = String::from_utf8(decoded)
            .map_err(|_| Error::Auth("token解码失败".to_string()))?;

        let parts: Vec<&str> = decoded_str.splitn(2, '.').collect();
        if parts.len() != 2 {
            return Err(Error::Auth("token格式错误".to_string()));
        }

        let payload_json = parts[0];
        let signature = parts[1];

        // 验证签名
        if signature != self.secret_key {
            return Err(Error::Auth("token签名无效".to_string()));
        }

        let payload: TokenPayload = serde_json::from_str(payload_json)
            .map_err(|_| Error::Auth("token载荷解析失败".to_string()))?;

        // 检查过期时间
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();

        if now > payload.exp {
            return Err(Error::Auth("token已过期".to_string()));
        }

        debug!("token验证成功: {}", payload.sub);
        Ok(payload.sub)
    }

    /// 检查IP白名单（简化实现）
    pub fn check_ip_whitelist(&self, client_ip: &str, whitelist: &[String]) -> bool {
        if whitelist.is_empty() {
            return true; // 空白名单表示允许所有IP
        }

        let allowed = whitelist.iter().any(|ip| ip == client_ip || ip == "*");
        
        if !allowed {
            warn!("🚫 IP {} 不在白名单中", client_ip);
        } else {
            debug!("✅ IP {} 白名单验证通过", client_ip);
        }

        allowed
    }

    /// 生成API密钥
    pub fn generate_api_key(&self) -> String {
        use rand::Rng;
        const CHARSET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ\
                                abcdefghijklmnopqrstuvwxyz\
                                0123456789";
        const KEY_LEN: usize = 32;

        let mut rng = rand::thread_rng();
        let key: String = (0..KEY_LEN)
            .map(|_| {
                let idx = rng.gen_range(0..CHARSET.len());
                CHARSET[idx] as char
            })
            .collect();

        format!("hajimi_{}", key)
    }

    /// 哈希密码（简化实现）
    pub fn hash_password(&self, password: &str) -> String {
        // 简化的密码哈希，实际应用中应使用bcrypt或argon2
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        let mut hasher = DefaultHasher::new();
        password.hash(&mut hasher);
        self.secret_key.hash(&mut hasher);
        format!("hashed_{}", hasher.finish())
    }

    /// 验证哈希密码
    pub fn verify_hashed_password(&self, password: &str, hash: &str) -> bool {
        let computed_hash = self.hash_password(password);
        self.verify_password(&computed_hash, hash)
    }
}

/// 从多个来源提取密码
pub fn extract_password_from_multiple_sources(
    headers: &HeaderMap,
    query_password: Option<&str>,
) -> Option<String> {
    // 1. 查询参数优先
    if let Some(password) = query_password {
        if !password.is_empty() {
            return Some(password.to_string());
        }
    }

    // 2. Authorization头
    if let Some(auth_header) = headers.get("authorization") {
        if let Ok(auth_str) = auth_header.to_str() {
            if let Some(token) = auth_str.strip_prefix("Bearer ") {
                return Some(token.to_string());
            }
            // 也可能直接是密码
            return Some(auth_str.to_string());
        }
    }

    // 3. X-API-Key头
    if let Some(api_key_header) = headers.get("x-api-key") {
        if let Ok(key_str) = api_key_header.to_str() {
            return Some(key_str.to_string());
        }
    }

    // 4. X-Auth-Token头
    if let Some(token_header) = headers.get("x-auth-token") {
        if let Ok(token_str) = token_header.to_str() {
            return Some(token_str.to_string());
        }
    }

    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_auth_validator() {
        let auth = AuthValidator::new("secret123".to_string(), 3600);
        
        // 测试密码验证
        assert!(auth.verify_password("correct", "correct"));
        assert!(!auth.verify_password("wrong", "correct"));
    }

    #[test]
    fn test_token_generation_and_verification() {
        let auth = AuthValidator::new("secret123".to_string(), 3600);
        
        let token = auth.generate_token("user123").unwrap();
        let user_id = auth.verify_token(&token).unwrap();
        assert_eq!(user_id, "user123");
    }

    #[test]
    fn test_api_key_generation() {
        let auth = AuthValidator::new("secret123".to_string(), 3600);
        let api_key = auth.generate_api_key();
        
        assert!(api_key.starts_with("hajimi_"));
        assert!(api_key.len() > 10);
    }

    #[test]
    fn test_password_hashing() {
        let auth = AuthValidator::new("secret123".to_string(), 3600);
        
        let hash = auth.hash_password("mypassword");
        assert!(auth.verify_hashed_password("mypassword", &hash));
        assert!(!auth.verify_hashed_password("wrongpassword", &hash));
    }

    #[test]
    fn test_ip_whitelist() {
        let auth = AuthValidator::new("secret123".to_string(), 3600);
        
        let whitelist = vec!["192.168.1.1".to_string(), "10.0.0.1".to_string()];
        
        assert!(auth.check_ip_whitelist("192.168.1.1", &whitelist));
        assert!(!auth.check_ip_whitelist("192.168.1.2", &whitelist));
        
        // 空白名单应该允许所有IP
        assert!(auth.check_ip_whitelist("any.ip.address", &[]));
    }
}