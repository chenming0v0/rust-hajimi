use regex::Regex;
use reqwest::Client;
use tracing::{info, warn, error};
use tokio::sync::RwLock;
use rand::seq::SliceRandom;
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::sync::Arc;
use tokio::fs;

/// API密钥测试结果
#[derive(Debug, Clone, PartialEq)]
pub enum ApiKeyTestResult {
    /// 密钥有效
    Valid,
    /// 密钥无效
    Invalid,
    /// 网络错误
    NetworkError,
}

/// 持久化存储的配置结构
#[derive(Debug, Serialize, Deserialize)]
struct PersistedConfig {
    gemini_api_keys: Vec<String>,
    invalid_api_keys: Vec<String>,
    last_updated: String,
    last_validation: Option<String>,
}

/// 高性能多密钥管理器，支持轮询和负载均衡
#[derive(Debug)]
pub struct ApiKeyManager {
    gemini_keys: Arc<RwLock<Vec<String>>>,
    invalid_keys: Arc<RwLock<Vec<String>>>,
    client: Client,
    storage_path: String,
}

/// 用于异步操作的ApiKeyManager克隆
#[derive(Debug, Clone)]
struct AsyncApiKeyManager {
    gemini_keys: Arc<RwLock<Vec<String>>>,
    invalid_keys: Arc<RwLock<Vec<String>>>,
    client: Client,
    storage_path: String,
}

impl ApiKeyManager {
    pub fn new(gemini_keys: Vec<String>) -> Self {
        Self::new_with_storage(gemini_keys, "storage/api_keys.json".to_string())
    }

    pub fn new_with_storage(gemini_keys: Vec<String>, storage_path: String) -> Self {
        let valid_keys = Self::filter_valid_gemini_keys(&gemini_keys);
        
        info!("初始化 API 密钥管理器: Gemini {} 个密钥", valid_keys.len());
        
        let manager = Self {
            gemini_keys: Arc::new(RwLock::new(valid_keys)),
            invalid_keys: Arc::new(RwLock::new(Vec::new())),
            client: Client::new(),
            storage_path,
        };
        
        manager
    }

    fn filter_valid_gemini_keys(keys: &[String]) -> Vec<String> {
        let gemini_regex = Regex::new(r"AIzaSy[a-zA-Z0-9_-]{33}").unwrap();
        
        keys.iter()
            .filter(|key| {
                if key.is_empty() {
                    false
                } else if gemini_regex.is_match(key) {
                    true
                } else {
                    warn!("跳过无效的 Gemini API 密钥格式: {}...", &key[..8.min(key.len())]);
                    false
                }
            })
            .cloned()
            .collect()
    }

    /// 获取一个可用的Gemini API密钥（轮询方式）
    pub async fn get_available_gemini_key(&self) -> Option<String> {
        let mut keys = self.gemini_keys.write().await;
        
        if keys.is_empty() {
            return None;
        }
        
        // 随机打乱顺序实现负载均衡
        keys.shuffle(&mut rand::thread_rng());
        
        // 返回第一个密钥
        keys.first().cloned()
    }

    /// 获取所有Gemini密钥的数量
    pub async fn get_gemini_key_count(&self) -> usize {
        self.gemini_keys.read().await.len()
    }

    /// 添加新的Gemini密钥
    pub async fn add_gemini_key(&self, key: String) -> bool {
        let gemini_regex = Regex::new(r"AIzaSy[a-zA-Z0-9_-]{33}").unwrap();
        
        if !gemini_regex.is_match(&key) {
            warn!("尝试添加无效的 Gemini API 密钥格式");
            return false;
        }
        
        let mut keys = self.gemini_keys.write().await;
        if !keys.contains(&key) {
            keys.push(key.clone());
            info!("添加新的 Gemini API 密钥: {}...", &key[..8]);
            true
        } else {
            warn!("Gemini API 密钥已存在");
            false
        }
    }

    /// 移除指定的Gemini密钥
    pub async fn remove_gemini_key(&self, key: &str) -> bool {
        let mut keys = self.gemini_keys.write().await;
        let original_len = keys.len();
        keys.retain(|k| k != key);
        
        if keys.len() < original_len {
            info!("移除 Gemini API 密钥: {}...", &key[..8.min(key.len())]);
            true
        } else {
            false
        }
    }

    /// 清空所有密钥
    pub async fn clear_all_keys(&self) {
        let mut keys = self.gemini_keys.write().await;
        keys.clear();
        info!("已清空所有 API 密钥");
    }


    /// 测试指定的Gemini密钥是否有效
    pub async fn test_gemini_key(&self, api_key: &str) -> bool {
        match self.test_gemini_key_detailed(api_key).await {
            ApiKeyTestResult::Valid => true,
            _ => false,
        }
    }

    /// 详细测试Gemini密钥状态
    pub async fn test_gemini_key_detailed(&self, api_key: &str) -> ApiKeyTestResult {
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models?key={}",
            api_key
        );
        
        // 创建带超时的客户端
        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(10))
            .user_agent("hajimi-rust/1.0")
            .build()
            .unwrap_or_else(|_| self.client.clone());
        
        // 尝试3次重试
        for attempt in 1..=3 {
            match client.get(&url).send().await {
                Ok(response) => {
                    let status = response.status();
                    
                    if status.is_success() {
                        info!("✅ Gemini API 密钥验证成功: {}... (尝试 {}/3)", &api_key[..8], attempt);
                        return ApiKeyTestResult::Valid;
                    } else {
                        // 获取详细的错误信息
                        let error_body = response.text().await.unwrap_or_else(|_| "无法获取错误详情".to_string());
                        warn!("❌ Gemini API 密钥验证失败: {}..., 状态: {} (尝试 {}/3)", &api_key[..8], status, attempt);
                        warn!("错误详情: {}", error_body);
                        
                        // 如果是认证错误，密钥无效
                        if status == 401 || status == 403 {
                            return ApiKeyTestResult::Invalid;
                        }
                        
                        // 如果是400错误，检查具体原因
                        if status == 400 {
                            if error_body.contains("API key not valid") || error_body.contains("Invalid API key") {
                                return ApiKeyTestResult::Invalid;
                            }
                        }
                        
                        // 其他错误状态也视为无效
                        return ApiKeyTestResult::Invalid;
                    }
                }
                Err(e) => {
                    warn!("🔄 测试 Gemini API 密钥网络错误: {} (尝试 {}/3)", e, attempt);
                    
                    // 如果不是最后一次尝试，等待一下再重试
                    if attempt < 3 {
                        tokio::time::sleep(std::time::Duration::from_millis(1000)).await;
                    }
                }
            }
        }
        
        error!("❌ Gemini API 密钥 {}... 测试失败，已尝试3次", &api_key[..8]);
        ApiKeyTestResult::NetworkError
    }

    /// 验证所有密钥的有效性
    pub async fn validate_all_keys(&self) -> usize {
        let keys = self.gemini_keys.read().await.clone();
        let mut valid_count = 0;
        let total_keys = keys.len();
        
        info!("🔍 开始验证 {} 个API密钥", total_keys);
        
        for (index, key) in keys.iter().enumerate() {
            let progress = index + 1;
            info!("🔄 验证进度: {}/{} ({}%)", progress, total_keys,
                  (progress as f64 / total_keys as f64 * 100.0).round() as u32);
            
            if self.test_gemini_key(key).await {
                valid_count += 1;
                info!("✅ 有效密钥: {}/{}", valid_count, progress);
            } else {
                info!("❌ 无效密钥: {}/{}", progress - valid_count, progress);
            }
            
            // 更新全局进度状态
            crate::TEST_PROGRESS.store(progress, std::sync::atomic::Ordering::SeqCst);
            crate::TEST_VALID.store(valid_count, std::sync::atomic::Ordering::SeqCst);
            crate::TEST_INVALID.store(progress - valid_count, std::sync::atomic::Ordering::SeqCst);
        }
        
        info!("🎉 密钥验证完成: {}/{} 个密钥有效 ({}%)",
              valid_count, total_keys,
              if total_keys > 0 { (valid_count as f64 / total_keys as f64 * 100.0).round() as u32 } else { 0 });
        valid_count
    }

    /// 显示密钥信息
    pub async fn show_key_info(&self) {
        let keys = self.gemini_keys.read().await;
        
        if keys.is_empty() {
            info!("当前没有配置 Gemini API 密钥");
        } else {
            info!("当前 Gemini API 密钥数量: {}", keys.len());
            for (i, key) in keys.iter().enumerate() {
                let masked_key = format!("{}...{}", 
                    &key[..8.min(key.len())],
                    if key.len() > 8 { &key[key.len()-3..] } else { "" }
                );
                info!("Gemini Key {}: {}", i + 1, masked_key);
            }
        }
    }

    /// 检查是否有可用的密钥
    pub async fn has_keys(&self) -> bool {
        !self.gemini_keys.read().await.is_empty()
    }

    /// 获取所有Gemini密钥（用于管理功能）
    pub async fn get_all_gemini_keys(&self) -> Vec<String> {
        self.gemini_keys.read().await.clone()
    }

    /// 获取所有无效密钥
    pub async fn get_all_invalid_keys(&self) -> Vec<String> {
        self.invalid_keys.read().await.clone()
    }

    /// 获取无效密钥数量
    pub async fn get_invalid_key_count(&self) -> usize {
        self.invalid_keys.read().await.len()
    }

    /// 添加无效密钥
    pub async fn add_invalid_key(&self, key: String) {
        let mut invalid_keys = self.invalid_keys.write().await;
        if !invalid_keys.contains(&key) {
            invalid_keys.push(key.clone());
            info!("添加无效密钥: {}...", &key[..8.min(key.len())]);
        }
    }

    /// 移除无效密钥
    pub async fn remove_invalid_key(&self, key: &str) -> bool {
        let mut invalid_keys = self.invalid_keys.write().await;
        let original_len = invalid_keys.len();
        invalid_keys.retain(|k| k != key);
        
        if invalid_keys.len() < original_len {
            info!("从无效列表移除密钥: {}...", &key[..8.min(key.len())]);
            true
        } else {
            false
        }
    }

    /// 清空所有无效密钥
    pub async fn clear_invalid_keys(&self) {
        let mut invalid_keys = self.invalid_keys.write().await;
        let count = invalid_keys.len();
        invalid_keys.clear();
        info!("已清空 {} 个无效密钥", count);
    }

    /// 异步检测所有API密钥状态
    /// 有效密钥保留在GEMINI_API_KEYS中，无效密钥移至INVALID_API_KEYS
    /// 该过程在后台异步进行，不会阻塞服务运行
    pub async fn detect_api_keys_async(&self) -> tokio::task::JoinHandle<(usize, usize)> {
        let manager_clone = AsyncApiKeyManager {
            gemini_keys: self.gemini_keys.clone(),
            invalid_keys: self.invalid_keys.clone(),
            client: self.client.clone(),
            storage_path: self.storage_path.clone(),
        };

        tokio::spawn(async move {
            manager_clone.perform_key_detection().await
        })
    }

    /// 同步版本的API密钥检测（用于立即获取结果）
    pub async fn detect_api_keys_sync(&self) -> (usize, usize) {
        let all_keys = self.gemini_keys.read().await.clone();
        let mut valid_keys = Vec::new();
        let mut invalid_keys = Vec::new();
        
        info!("🔍 开始检测 {} 个API密钥", all_keys.len());
        
        for (index, key) in all_keys.iter().enumerate() {
            let progress = index + 1;
            info!("🔄 检测进度: {}/{} ({}%)", progress, all_keys.len(),
                  (progress as f64 / all_keys.len() as f64 * 100.0).round() as u32);
            
            match self.test_gemini_key_detailed(key).await {
                ApiKeyTestResult::Valid => {
                    valid_keys.push(key.clone());
                    info!("✅ 有效密钥: {}...", &key[..8.min(key.len())]);
                }
                ApiKeyTestResult::Invalid => {
                    invalid_keys.push(key.clone());
                    warn!("❌ 无效密钥: {}...", &key[..8.min(key.len())]);
                }
                ApiKeyTestResult::NetworkError => {
                    // 网络错误时保持原状，不移动密钥
                    valid_keys.push(key.clone());
                    warn!("🔄 网络错误，保持密钥: {}...", &key[..8.min(key.len())]);
                }
            }
            
            // 更新全局进度状态
            crate::TEST_PROGRESS.store(progress, std::sync::atomic::Ordering::SeqCst);
            crate::TEST_VALID.store(valid_keys.len(), std::sync::atomic::Ordering::SeqCst);
            crate::TEST_INVALID.store(invalid_keys.len(), std::sync::atomic::Ordering::SeqCst);
        }
        
        // 更新密钥列表
        {
            let mut gemini_keys_write = self.gemini_keys.write().await;
            *gemini_keys_write = valid_keys.clone();
        }
        
        {
            let mut invalid_keys_write = self.invalid_keys.write().await;
            *invalid_keys_write = invalid_keys.clone();
        }
        
        // 保存到持久化存储
        if let Err(e) = self.save_to_storage().await {
            error!("保存密钥检测结果到持久化存储失败: {}", e);
        }
        
        let valid_count = valid_keys.len();
        let invalid_count = invalid_keys.len();
        
        info!("🎉 API密钥检测完成:");
        info!("  ✅ 有效密钥: {} 个", valid_count);
        info!("  ❌ 无效密钥: {} 个", invalid_count);
        info!("  📊 有效率: {}%",
              if all_keys.len() > 0 { (valid_count as f64 / all_keys.len() as f64 * 100.0).round() as u32 } else { 0 });
        
        (valid_count, invalid_count)
    }

    /// 测试并返回有效的密钥列表
    pub async fn get_valid_keys(&self) -> Vec<String> {
        let keys = self.gemini_keys.read().await.clone();
        let mut valid_keys = Vec::new();
        
        for key in &keys {
            if self.test_gemini_key(key).await {
                valid_keys.push(key.clone());
            }
        }
        
        info!("找到 {} 个有效密钥，共 {} 个密钥", valid_keys.len(), keys.len());
        valid_keys
    }

    /// 移除无效的密钥
    pub async fn remove_invalid_keys(&self) -> usize {
        let keys = self.gemini_keys.read().await.clone();
        let mut valid_keys = Vec::new();
        let mut removed_count = 0;
        
        for key in &keys {
            if self.test_gemini_key(key).await {
                valid_keys.push(key.clone());
            } else {
                removed_count += 1;
                warn!("移除无效密钥: {}...", &key[..8.min(key.len())]);
            }
        }
        
        // 更新密钥列表
        let mut keys_write = self.gemini_keys.write().await;
        *keys_write = valid_keys;
        
        // 保存到持久化存储
        if let Err(e) = self.save_to_storage().await {
            error!("保存密钥到持久化存储失败: {}", e);
        }
        
        info!("清除完成: 移除 {} 个无效密钥，保留 {} 个有效密钥", removed_count, keys_write.len());
        removed_count
    }

    /// 保存密钥到持久化存储
    pub async fn save_to_storage(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let keys = self.gemini_keys.read().await.clone();
        let invalid_keys = self.invalid_keys.read().await.clone();
        
        let config = PersistedConfig {
            gemini_api_keys: keys,
            invalid_api_keys: invalid_keys,
            last_updated: chrono::Utc::now().to_rfc3339(),
            last_validation: Some(chrono::Utc::now().to_rfc3339()),
        };
        
        // 确保存储目录存在
        if let Some(parent) = Path::new(&self.storage_path).parent() {
            fs::create_dir_all(parent).await?;
        }
        
        let json_data = serde_json::to_string_pretty(&config)?;
        fs::write(&self.storage_path, json_data).await?;
        
        info!("API密钥已保存到持久化存储: {}", self.storage_path);
        Ok(())
    }

    /// 从持久化存储加载密钥
    pub async fn load_from_storage(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if !Path::new(&self.storage_path).exists() {
            info!("持久化存储文件不存在，跳过加载: {}", self.storage_path);
            return Ok(());
        }
        
        let json_data = fs::read_to_string(&self.storage_path).await?;
        let config: PersistedConfig = serde_json::from_str(&json_data)?;
        
        let valid_keys = Self::filter_valid_gemini_keys(&config.gemini_api_keys);
        
        let mut keys_write = self.gemini_keys.write().await;
        *keys_write = valid_keys;
        
        // 加载无效密钥
        let mut invalid_keys_write = self.invalid_keys.write().await;
        *invalid_keys_write = config.invalid_api_keys;
        
        info!("从持久化存储加载了 {} 个有效API密钥和 {} 个无效密钥",
              keys_write.len(), invalid_keys_write.len());
        Ok(())
    }

    /// 重写set_gemini_keys方法以支持持久化
    pub async fn set_gemini_keys(&self, new_keys: Vec<String>) {
        let valid_keys = Self::filter_valid_gemini_keys(&new_keys);
        let mut keys = self.gemini_keys.write().await;
        *keys = valid_keys;
        info!("批量设置 Gemini API 密钥: {} 个", keys.len());
        
        // 保存到持久化存储
        drop(keys); // 释放写锁
        if let Err(e) = self.save_to_storage().await {
            error!("保存密钥到持久化存储失败: {}", e);
        }
    }
}

impl AsyncApiKeyManager {
    /// 从持久化存储加载密钥
    pub async fn load_from_storage(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        if !Path::new(&self.storage_path).exists() {
            info!("持久化存储文件不存在，跳过加载: {}", self.storage_path);
            return Ok(());
        }
        
        let json_data = fs::read_to_string(&self.storage_path).await?;
        let config: PersistedConfig = serde_json::from_str(&json_data)?;
        
        let valid_keys = ApiKeyManager::filter_valid_gemini_keys(&config.gemini_api_keys);
        
        let mut keys_write = self.gemini_keys.write().await;
        *keys_write = valid_keys;
        
        // 加载无效密钥
        let mut invalid_keys_write = self.invalid_keys.write().await;
        *invalid_keys_write = config.invalid_api_keys;
        
        info!("从持久化存储加载了 {} 个有效API密钥和 {} 个无效密钥",
              keys_write.len(), invalid_keys_write.len());
        Ok(())
    }

    /// 执行密钥检测的核心逻辑
    pub async fn perform_key_detection(&self) -> (usize, usize) {
        let all_keys = self.gemini_keys.read().await.clone();
        let mut valid_keys = Vec::new();
        let mut invalid_keys = Vec::new();
        
        info!("🔍 后台异步检测 {} 个API密钥", all_keys.len());
        
        for (index, key) in all_keys.iter().enumerate() {
            let progress = index + 1;
            info!("🔄 异步检测进度: {}/{} ({}%)", progress, all_keys.len(),
                  (progress as f64 / all_keys.len() as f64 * 100.0).round() as u32);
            
            match self.test_gemini_key_detailed(key).await {
                ApiKeyTestResult::Valid => {
                    valid_keys.push(key.clone());
                    info!("✅ 有效密钥: {}...", &key[..8.min(key.len())]);
                }
                ApiKeyTestResult::Invalid => {
                    invalid_keys.push(key.clone());
                    warn!("❌ 无效密钥: {}...", &key[..8.min(key.len())]);
                }
                ApiKeyTestResult::NetworkError => {
                    // 网络错误时保持原状，不移动密钥
                    valid_keys.push(key.clone());
                    warn!("🔄 网络错误，保持密钥: {}...", &key[..8.min(key.len())]);
                }
            }
            
            // 更新全局进度状态
            crate::TEST_PROGRESS.store(progress, std::sync::atomic::Ordering::SeqCst);
            crate::TEST_VALID.store(valid_keys.len(), std::sync::atomic::Ordering::SeqCst);
            crate::TEST_INVALID.store(invalid_keys.len(), std::sync::atomic::Ordering::SeqCst);
        }
        
        // 更新密钥列表
        {
            let mut gemini_keys_write = self.gemini_keys.write().await;
            *gemini_keys_write = valid_keys.clone();
        }
        
        {
            let mut invalid_keys_write = self.invalid_keys.write().await;
            *invalid_keys_write = invalid_keys.clone();
        }
        
        // 保存到持久化存储
        if let Err(e) = self.save_to_storage().await {
            error!("保存密钥检测结果到持久化存储失败: {}", e);
        }
        
        let valid_count = valid_keys.len();
        let invalid_count = invalid_keys.len();
        
        info!("🎉 异步API密钥检测完成:");
        info!("  ✅ 有效密钥: {} 个", valid_count);
        info!("  ❌ 无效密钥: {} 个", invalid_count);
        info!("  📊 有效率: {}%",
              if all_keys.len() > 0 { (valid_count as f64 / all_keys.len() as f64 * 100.0).round() as u32 } else { 0 });
        
        (valid_count, invalid_count)
    }

    /// 详细测试Gemini密钥状态
    pub async fn test_gemini_key_detailed(&self, api_key: &str) -> ApiKeyTestResult {
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models?key={}",
            api_key
        );
        
        // 创建带超时的客户端
        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(10))
            .user_agent("hajimi-rust/1.0")
            .build()
            .unwrap_or_else(|_| self.client.clone());
        
        // 尝试3次重试
        for attempt in 1..=3 {
            match client.get(&url).send().await {
                Ok(response) => {
                    let status = response.status();
                    
                    if status.is_success() {
                        info!("✅ Gemini API 密钥验证成功: {}... (尝试 {}/3)", &api_key[..8], attempt);
                        return ApiKeyTestResult::Valid;
                    } else {
                        // 获取详细的错误信息
                        let error_body = response.text().await.unwrap_or_else(|_| "无法获取错误详情".to_string());
                        warn!("❌ Gemini API 密钥验证失败: {}..., 状态: {} (尝试 {}/3)", &api_key[..8], status, attempt);
                        warn!("错误详情: {}", error_body);
                        
                        // 检查是否是地理位置限制
                        if error_body.contains("User location is not supported") {
                            warn!("🌍 检测到地理位置限制: {}...", &api_key[..8]);
                            return ApiKeyTestResult::Invalid;
                        }
                        
                        // 如果是认证错误，密钥无效
                        if status == 401 || status == 403 {
                            return ApiKeyTestResult::Invalid;
                        }
                        
                        // 如果是400错误，检查具体原因
                        if status == 400 {
                            if error_body.contains("API key not valid") || error_body.contains("Invalid API key") {
                                return ApiKeyTestResult::Invalid;
                            } else {
                                return ApiKeyTestResult::Invalid;
                            }
                        }
                    }
                }
                Err(e) => {
                    warn!("🔄 测试 Gemini API 密钥网络错误: {} (尝试 {}/3)", e, attempt);
                    
                    // 如果不是最后一次尝试，等待一下再重试
                    if attempt < 3 {
                        tokio::time::sleep(std::time::Duration::from_millis(1000)).await;
                    }
                }
            }
        }
        
        error!("❌ Gemini API 密钥 {}... 测试失败，已尝试3次", &api_key[..8]);
        ApiKeyTestResult::NetworkError
    }

    /// 保存密钥到持久化存储
    pub async fn save_to_storage(&self) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
        let keys = self.gemini_keys.read().await.clone();
        let invalid_keys = self.invalid_keys.read().await.clone();
        
        let config = PersistedConfig {
            gemini_api_keys: keys,
            invalid_api_keys: invalid_keys,
            last_updated: chrono::Utc::now().to_rfc3339(),
            last_validation: Some(chrono::Utc::now().to_rfc3339()),
        };
        
        // 确保存储目录存在
        if let Some(parent) = Path::new(&self.storage_path).parent() {
            fs::create_dir_all(parent).await?;
        }
        
        let json_data = serde_json::to_string_pretty(&config)?;
        fs::write(&self.storage_path, json_data).await?;
        
        info!("API密钥检测结果已保存到持久化存储: {}", self.storage_path);
        Ok(())
    }
}