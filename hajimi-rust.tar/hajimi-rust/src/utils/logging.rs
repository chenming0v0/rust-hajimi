use chrono::{DateTime, Local};
use serde::{Deserialize, Serialize};
use std::collections::VecDeque;
use std::sync::{Arc, Mutex};
use tokio::sync::RwLock;

/// 日志级别枚举
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum LogLevel {
    #[serde(rename = "INFO")]
    Info,
    #[serde(rename = "WARNING")]
    Warning,
    #[serde(rename = "ERROR")]
    Error,
    #[serde(rename = "DEBUG")]
    Debug,
}

impl std::fmt::Display for LogLevel {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LogLevel::Info => write!(f, "INFO"),
            LogLevel::Warning => write!(f, "WARNING"),
            LogLevel::Error => write!(f, "ERROR"),
            LogLevel::Debug => write!(f, "DEBUG"),
        }
    }
}

/// 日志条目结构
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogEntry {
    pub timestamp: String,
    pub level: LogLevel,
    pub key: String,
    pub request_type: String,
    pub model: String,
    pub status_code: String,
    pub message: String,
    pub error_message: String,
}

impl LogEntry {
    /// 创建新的日志条目
    pub fn new(
        level: LogLevel,
        message: String,
        key: Option<String>,
        request_type: Option<String>,
        model: Option<String>,
        status_code: Option<String>,
        error_message: Option<String>,
    ) -> Self {
        Self {
            timestamp: Local::now().format("%Y-%m-%d %H:%M:%S").to_string(),
            level,
            key: key.unwrap_or_else(|| "N/A".to_string()),
            request_type: request_type.unwrap_or_else(|| "N/A".to_string()),
            model: model.unwrap_or_else(|| "N/A".to_string()),
            status_code: status_code.unwrap_or_else(|| "N/A".to_string()),
            message,
            error_message: error_message.unwrap_or_else(|| String::new()),
        }
    }

    /// 创建信息级别日志
    pub fn info(message: String) -> Self {
        Self::new(LogLevel::Info, message, None, None, None, None, None)
    }

    /// 创建警告级别日志
    pub fn warning(message: String) -> Self {
        Self::new(LogLevel::Warning, message, None, None, None, None, None)
    }

    /// 创建错误级别日志
    pub fn error(message: String, error_message: Option<String>) -> Self {
        Self::new(LogLevel::Error, message, None, None, None, None, error_message)
    }

    /// 创建调试级别日志
    pub fn debug(message: String) -> Self {
        Self::new(LogLevel::Debug, message, None, None, None, None, None)
    }

    /// 创建API请求相关的日志
    pub fn api_request(
        level: LogLevel,
        message: String,
        key: String,
        request_type: String,
        model: String,
        status_code: u16,
        error_message: Option<String>,
    ) -> Self {
        Self::new(
            level,
            message,
            Some(key),
            Some(request_type),
            Some(model),
            Some(status_code.to_string()),
            error_message,
        )
    }
}

/// 日志管理器
#[derive(Debug)]
pub struct LogManager {
    logs: Arc<RwLock<VecDeque<LogEntry>>>,
    max_logs: usize,
}

impl LogManager {
    /// 创建新的日志管理器
    pub fn new(max_logs: usize) -> Self {
        Self {
            logs: Arc::new(RwLock::new(VecDeque::with_capacity(max_logs))),
            max_logs,
        }
    }

    /// 添加日志条目
    pub async fn add_log(&self, log_entry: LogEntry) {
        let mut logs = self.logs.write().await;
        
        // 如果超过最大容量，移除最旧的日志
        if logs.len() >= self.max_logs {
            logs.pop_front();
        }
        
        logs.push_back(log_entry.clone());
        
        // 同时输出到控制台
        self.print_to_console(&log_entry);
    }

    /// 获取最近的日志
    pub async fn get_recent_logs(&self, count: usize) -> Vec<LogEntry> {
        let logs = self.logs.read().await;
        let start_index = if logs.len() > count {
            logs.len() - count
        } else {
            0
        };
        
        logs.iter().skip(start_index).cloned().collect()
    }

    /// 获取所有日志
    pub async fn get_all_logs(&self) -> Vec<LogEntry> {
        let logs = self.logs.read().await;
        logs.iter().cloned().collect()
    }

    /// 按级别过滤日志
    pub async fn get_logs_by_level(&self, level: LogLevel) -> Vec<LogEntry> {
        let logs = self.logs.read().await;
        logs.iter()
            .filter(|log| log.level == level)
            .cloned()
            .collect()
    }

    /// 清空所有日志
    pub async fn clear_logs(&self) {
        let mut logs = self.logs.write().await;
        logs.clear();
    }

    /// 输出日志到控制台
    fn print_to_console(&self, log_entry: &LogEntry) {
        let level_color = match log_entry.level {
            LogLevel::Info => "\x1b[32m",    // 绿色
            LogLevel::Warning => "\x1b[33m", // 黄色
            LogLevel::Error => "\x1b[31m",   // 红色
            LogLevel::Debug => "\x1b[36m",   // 青色
        };
        let reset_color = "\x1b[0m";

        let formatted_message = if log_entry.key != "N/A" || log_entry.request_type != "N/A" {
            format!(
                "[{}] [{}{}{}] [{}]-{}-[{}]-{}: {}{}",
                log_entry.timestamp,
                level_color,
                log_entry.level,
                reset_color,
                log_entry.key,
                log_entry.request_type,
                log_entry.model,
                log_entry.status_code,
                log_entry.message,
                if !log_entry.error_message.is_empty() {
                    format!(" - {}", log_entry.error_message)
                } else {
                    String::new()
                }
            )
        } else {
            format!(
                "[{}] [{}{}{}]: {}{}",
                log_entry.timestamp,
                level_color,
                log_entry.level,
                reset_color,
                log_entry.message,
                if !log_entry.error_message.is_empty() {
                    format!(" - {}", log_entry.error_message)
                } else {
                    String::new()
                }
            )
        };

        println!("{}", formatted_message);
    }
}

/// 全局日志管理器实例
lazy_static::lazy_static! {
    pub static ref GLOBAL_LOG_MANAGER: LogManager = LogManager::new(500);
}

/// 便捷的日志记录宏
#[macro_export]
macro_rules! log_info {
    ($msg:expr) => {
        {
            let log_entry = $crate::utils::logging::LogEntry::info($msg.to_string());
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
    ($msg:expr, $($arg:tt)*) => {
        {
            let formatted_msg = format!($msg, $($arg)*);
            let log_entry = $crate::utils::logging::LogEntry::info(formatted_msg);
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
}

#[macro_export]
macro_rules! log_warning {
    ($msg:expr) => {
        {
            let log_entry = $crate::utils::logging::LogEntry::warning($msg.to_string());
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
    ($msg:expr, $($arg:tt)*) => {
        {
            let formatted_msg = format!($msg, $($arg)*);
            let log_entry = $crate::utils::logging::LogEntry::warning(formatted_msg);
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
}

#[macro_export]
macro_rules! log_error {
    ($msg:expr) => {
        {
            let log_entry = $crate::utils::logging::LogEntry::error($msg.to_string(), None);
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
    ($msg:expr, $error:expr) => {
        {
            let log_entry = $crate::utils::logging::LogEntry::error($msg.to_string(), Some($error.to_string()));
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
    ($msg:expr, $($arg:tt)*) => {
        {
            let formatted_msg = format!($msg, $($arg)*);
            let log_entry = $crate::utils::logging::LogEntry::error(formatted_msg, None);
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
}

#[macro_export]
macro_rules! log_debug {
    ($msg:expr) => {
        {
            let log_entry = $crate::utils::logging::LogEntry::debug($msg.to_string());
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
    ($msg:expr, $($arg:tt)*) => {
        {
            let formatted_msg = format!($msg, $($arg)*);
            let log_entry = $crate::utils::logging::LogEntry::debug(formatted_msg);
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
}

/// API请求日志记录宏
#[macro_export]
macro_rules! log_api_request {
    ($level:expr, $msg:expr, $key:expr, $request_type:expr, $model:expr, $status:expr) => {
        {
            let log_entry = $crate::utils::logging::LogEntry::api_request(
                $level,
                $msg.to_string(),
                $key.to_string(),
                $request_type.to_string(),
                $model.to_string(),
                $status,
                None,
            );
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
    ($level:expr, $msg:expr, $key:expr, $request_type:expr, $model:expr, $status:expr, $error:expr) => {
        {
            let log_entry = $crate::utils::logging::LogEntry::api_request(
                $level,
                $msg.to_string(),
                $key.to_string(),
                $request_type.to_string(),
                $model.to_string(),
                $status,
                Some($error.to_string()),
            );
            tokio::spawn(async move {
                $crate::utils::logging::GLOBAL_LOG_MANAGER.add_log(log_entry).await;
            });
        }
    };
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::time::{sleep, Duration};

    #[tokio::test]
    async fn test_log_manager() {
        let log_manager = LogManager::new(10);
        
        // 添加一些测试日志
        log_manager.add_log(LogEntry::info("测试信息日志".to_string())).await;
        log_manager.add_log(LogEntry::warning("测试警告日志".to_string())).await;
        log_manager.add_log(LogEntry::error("测试错误日志".to_string(), Some("错误详情".to_string()))).await;
        
        // 获取所有日志
        let logs = log_manager.get_all_logs().await;
        assert_eq!(logs.len(), 3);
        
        // 按级别过滤
        let info_logs = log_manager.get_logs_by_level(LogLevel::Info).await;
        assert_eq!(info_logs.len(), 1);
        
        let warning_logs = log_manager.get_logs_by_level(LogLevel::Warning).await;
        assert_eq!(warning_logs.len(), 1);
        
        let error_logs = log_manager.get_logs_by_level(LogLevel::Error).await;
        assert_eq!(error_logs.len(), 1);
    }

    #[tokio::test]
    async fn test_log_capacity() {
        let log_manager = LogManager::new(3);
        
        // 添加超过容量的日志
        for i in 0..5 {
            log_manager.add_log(LogEntry::info(format!("日志 {}", i))).await;
        }
        
        let logs = log_manager.get_all_logs().await;
        assert_eq!(logs.len(), 3); // 应该只保留最新的3条
        
        // 检查是否保留了最新的日志
        assert!(logs[2].message.contains("日志 4"));
    }
}