use moka::future::Cache;
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct CacheManager {
    cache: Cache<String, String>,
}

impl CacheManager {
    pub fn new(expiry_seconds: u64) -> Self {
        let cache = Cache::builder()
            .time_to_live(Duration::from_secs(expiry_seconds))
            .max_capacity(10_000)
            .build();

        Self { cache }
    }

    pub async fn get(&self, key: &str) -> Option<String> {
        self.cache.get(key).await
    }

    pub async fn set(&self, key: String, value: String) {
        self.cache.insert(key, value).await;
    }

    pub async fn remove(&self, key: &str) {
        self.cache.invalidate(key).await;
    }

    pub async fn clear(&self) {
        self.cache.invalidate_all();
    }

    pub fn entry_count(&self) -> u64 {
        self.cache.entry_count()
    }
}