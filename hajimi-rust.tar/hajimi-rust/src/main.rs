use axum::{
    extract::{Query, State},
    http::{HeaderMap, StatusCode},
    response::{Html, Json, Response, IntoResponse},
    routing::{get, post},
    Router,
};
use serde::{Deserialize, Serialize};
use std::sync::{Arc, RwLock};
use tokio::net::TcpListener;
use tower_http::{
    cors::{Any, CorsLayer},
    services::ServeDir,
};
use tracing::{info, warn, error};

mod config;
mod services;
mod utils;

use config::AppConfig;
use services::{gemini::GeminiService, openai::OpenAIService};
use utils::{
    api_key::ApiKeyManager,
    auth::{self, AuthQuery},
    cache::CacheManager,
    connection_pool::ConnectionPool,
    rate_limit::RateLimiter,
};

#[derive(Clone)]
pub struct AppState {
    pub config: Arc<RwLock<AppConfig>>,
    pub gemini_service: Arc<GeminiService>,
    pub openai_service: Arc<OpenAIService>,
    pub api_key_manager: Arc<ApiKeyManager>,
    pub cache_manager: Arc<CacheManager>,
    pub connection_pool: Arc<ConnectionPool>,
    pub rate_limiter: Arc<RateLimiter>,
}

#[derive(Deserialize)]
struct ChatRequest {
    model: String,
    messages: Vec<Message>,
    stream: Option<bool>,
    temperature: Option<f32>,
    max_tokens: Option<u32>,
}

#[derive(Deserialize, Serialize, Clone)]
pub struct Message {
    pub role: String,
    pub content: String,
}

#[derive(Serialize, Deserialize)]
struct ChatResponse {
    id: String,
    object: String,
    created: u64,
    model: String,
    choices: Vec<Choice>,
    usage: Usage,
}

#[derive(Serialize, Deserialize)]
struct Choice {
    index: u32,
    message: Message,
    finish_reason: String,
}

#[derive(Serialize, Deserialize)]
struct Usage {
    prompt_tokens: u32,
    completion_tokens: u32,
    total_tokens: u32,
}

#[derive(Serialize)]
struct ErrorResponse {
    error: ErrorDetail,
}

#[derive(Serialize)]
struct ErrorDetail {
    message: String,
    #[serde(rename = "type")]
    error_type: String,
    code: Option<String>,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // 初始化日志
    tracing_subscriber::fmt()
        .with_env_filter("hajimi_rust=info,tower_http=info")
        .init();

    // 加载配置
    let config = AppConfig::load()?;
    info!("🚀 Hajimi Rust 高性能反向代理启动");
    info!("📊 配置加载: 端口 {}, 密码已设置", config.port);
    
    // 添加启动日志到我们的日志系统
    info!("🚀 Hajimi Rust 高性能反向代理启动");
    info!("📊 配置加载完成: 端口 {}, 最大并发请求 {}", config.port, config.max_concurrent_requests);

    // 初始化服务组件
    let connection_pool = Arc::new(ConnectionPool::new(
        config.max_concurrent_requests,
        config.request_timeout_seconds
    ));
    let gemini_service = Arc::new(GeminiService::new_with_pool(connection_pool.clone()));
    let openai_service = Arc::new(OpenAIService::new_with_pool(connection_pool.clone()));
    let api_key_manager = Arc::new(ApiKeyManager::new_with_storage(
        config.gemini_api_keys.clone(),
        "storage/api_keys.json".to_string()
    ));
    
    // 尝试从持久化存储加载密钥
    if let Err(e) = api_key_manager.load_from_storage().await {
        warn!("加载持久化密钥失败: {}", e);
    }
    let cache_manager = Arc::new(CacheManager::new(config.cache_expiry_seconds));
    let rate_limiter = Arc::new(RateLimiter::new(
        config.max_requests_per_minute as u32,
        config.max_requests_per_day_per_ip as u32
    ));

    let state = AppState {
        config: Arc::new(RwLock::new(config.clone())),
        gemini_service,
        openai_service,
        api_key_manager,
        cache_manager,
        connection_pool,
        rate_limiter,
    };

    // 显示API密钥信息
    info!("🔑 API 密钥状态:");
    state.api_key_manager.show_key_info().await;

    // 构建路由 - 按照原始项目设计
    let app = Router::new()
        .route("/", get(dashboard))
        .route("/v1/chat/completions", post(chat_completions))
        .route("/v1/models", get(list_models))
        .route("/health", get(health_check))
        // 管理API
        .route("/api/set_keys", post(auth::set_api_keys))
        .route("/api/key_info", get(auth::get_api_key_info))
        .route("/api/stats", get(get_stats))
        .route("/api/dashboard-data", get(get_dashboard_data))
        .route("/api/update-config", post(update_config))
        // API密钥管理端点
        .route("/api/test-api-keys", post(test_api_keys))
        .route("/api/test-api-keys/progress", get(get_test_progress))
        .route("/api/clear-invalid-api-keys", post(clear_invalid_api_keys))
        .route("/api/export-valid-api-keys", post(export_valid_api_keys))
        // 新的API密钥检测端点
        .route("/api/detect-api-keys", post(detect_api_keys))
        .route("/api/get-invalid-keys", get(get_invalid_keys))
        .nest_service("/assets", ServeDir::new("templates/assets"))
        .layer(
            CorsLayer::new()
                .allow_origin(Any)
                .allow_methods(Any)
                .allow_headers(Any),
        )
        .with_state(state.clone());

    let config_read = state.config.read().unwrap();
    let addr = format!("0.0.0.0:{}", config_read.port);
    info!("🌐 服务器启动: {}", addr);
    info!("📈 高性能模式: 最大并发 {}, 超时 {}s, 缓存 {}s",
          config_read.max_concurrent_requests,
          config_read.request_timeout_seconds,
          config_read.cache_expiry_seconds);
    drop(config_read);
    
    let listener = TcpListener::bind(&addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}

async fn dashboard() -> Html<&'static str> {
    Html(include_str!("../templates/index.html"))
}

async fn health_check(State(state): State<AppState>) -> Json<serde_json::Value> {
    let pool_stats = state.connection_pool.get_stats();
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    
    Json(serde_json::json!({
        "status": "ok",
        "timestamp": chrono::Utc::now().timestamp(),
        "performance": {
            "connection_pool": {
                "max_concurrent": pool_stats.max_concurrent,
                "available": pool_stats.available,
                "in_use": pool_stats.in_use
            },
            "api_keys": {
                "gemini_count": key_count,
                "has_keys": key_count > 0
            },
            "cache_entries": state.cache_manager.entry_count()
        }
    }))
}

async fn list_models(State(state): State<AppState>) -> Result<Json<serde_json::Value>, StatusCode> {
    let has_keys = state.api_key_manager.has_keys().await;
    
    let models = if has_keys {
        // 尝试从Google API动态获取模型列表
        match get_available_models_from_api(&state).await {
            Ok(api_models) => api_models,
            Err(_) => {
                // 如果API调用失败，使用默认模型列表
                warn!("无法从API获取模型列表，使用默认列表");
                vec![
                    "gemini-2.5-pro".to_string(), "gemini-1.5-pro".to_string(), "gemini-1.5-flash".to_string(),
                    "gemini-1.0-pro".to_string(), "gemini-pro".to_string(), "gemini-pro-vision".to_string()
                ]
            }
        }
    } else {
        vec![]
    };

    let response = serde_json::json!({
        "object": "list",
        "data": models.iter().map(|model| {
            serde_json::json!({
                "id": model.as_str(),
                "object": "model",
                "created": chrono::Utc::now().timestamp(),
                "owned_by": "hajimi-rust"
            })
        }).collect::<Vec<_>>()
    });

    Ok(Json(response))
}

// 从Google API动态获取可用模型
async fn get_available_models_from_api(state: &AppState) -> anyhow::Result<Vec<String>> {
    if let Some(api_key) = state.api_key_manager.get_available_gemini_key().await {
        let client = reqwest::Client::new();
        let url = format!("https://generativelanguage.googleapis.com/v1beta/models?key={}", api_key);
        
        let response = client
            .get(&url)
            .send()
            .await?;
            
        if response.status().is_success() {
            let json: serde_json::Value = response.json().await?;
            
            let mut models = Vec::new();
            if let Some(model_list) = json.get("models").and_then(|m| m.as_array()) {
                for model in model_list {
                    if let Some(name) = model.get("name").and_then(|n| n.as_str()) {
                        // 提取模型名称，去掉 "models/" 前缀
                        if let Some(model_id) = name.strip_prefix("models/") {
                            // 只包含生成模型，过滤掉嵌入模型等
                            if model_id.contains("gemini") && !model_id.contains("embedding") && !model_id.contains("aqa") {
                                models.push(model_id.to_string());
                                info!("发现可用模型: {}", model_id);
                            }
                        }
                    }
                }
            }
            
            if !models.is_empty() {
                info!("从Google API获取到 {} 个可用模型: {:?}", models.len(), models);
                return Ok(models);
            } else {
                warn!("API响应中未找到可用的Gemini模型");
            }
        } else {
            warn!("API请求失败，状态码: {}", response.status());
        }
    } else {
        warn!("没有可用的API密钥");
    }
    
    Err(anyhow::anyhow!("无法从API获取模型列表"))
}

async fn chat_completions(
    State(state): State<AppState>,
    headers: HeaderMap,
    query: Option<Query<AuthQuery>>,
    Json(request): Json<ChatRequest>,
) -> Result<Response, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    if let Err((status, Json(auth_error))) = auth::verify_password(&headers, query, &state).await {
        return Err((status, Json(ErrorResponse {
            error: ErrorDetail {
                message: auth_error.message,
                error_type: auth_error.error,
                code: None,
            },
        })));
    }

    // 限流检查 - 使用客户端IP作为限流键
    let client_ip = headers
        .get("x-forwarded-for")
        .and_then(|h| h.to_str().ok())
        .or_else(|| headers.get("x-real-ip").and_then(|h| h.to_str().ok()))
        .unwrap_or("unknown")
        .split(',')
        .next()
        .unwrap_or("unknown")
        .trim();

    if !state.rate_limiter.check_rate_limit(client_ip).await {
        return Err((
            StatusCode::TOO_MANY_REQUESTS,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Rate limit exceeded. Please try again later.".to_string(),
                    error_type: "rate_limit_exceeded".to_string(),
                    code: Some("too_many_requests".to_string()),
                },
            }),
        ));
    }

    // 获取连接池许可
    let _permit = match state.connection_pool.acquire_permit().await {
        Ok(permit) => permit,
        Err(e) => {
            error!("连接池获取许可失败: {}", e);
            return Err((
                StatusCode::SERVICE_UNAVAILABLE,
                Json(ErrorResponse {
                    error: ErrorDetail {
                        message: "Service temporarily unavailable".to_string(),
                        error_type: "service_unavailable".to_string(),
                        code: Some("connection_pool_full".to_string()),
                    },
                }),
            ));
        }
    };

    // 检查是否有可用的API密钥
    if !state.api_key_manager.has_keys().await {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "No Gemini API keys configured. Please set API keys in the dashboard.".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("no_api_keys".to_string()),
                },
            }),
        ));
    }

    // 检查模型支持
    if !request.model.starts_with("gemini") {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Only Gemini models are supported".to_string(),
                    error_type: "invalid_request_error".to_string(),
                    code: Some("unsupported_model".to_string()),
                },
            }),
        ));
    }

    // 获取可用的API密钥
    let api_key = match state.api_key_manager.get_available_gemini_key().await {
        Some(key) => {
            // 记录API请求开始日志
            info!("API请求开始 - 密钥: {}..., 模型: {}", &key[..8], &request.model);
            key
        },
        None => {
            error!("没有可用的Gemini API密钥");
            return Err((
                StatusCode::SERVICE_UNAVAILABLE,
                Json(ErrorResponse {
                    error: ErrorDetail {
                        message: "No available Gemini API keys".to_string(),
                        error_type: "service_unavailable".to_string(),
                        code: Some("no_available_keys".to_string()),
                    },
                }),
            ));
        }
    };

    // 生成缓存键
    let cache_key = format!("{}:{}", 
        request.model, 
        xxhash_rust::xxh3::xxh3_64(
            serde_json::to_string(&request.messages).unwrap().as_bytes()
        )
    );

    // 检查缓存
    if let Some(cached_response) = state.cache_manager.get(&cache_key).await {
        info!("🎯 缓存命中: {}", cache_key);
        let cached_chat_response: ChatResponse = serde_json::from_str(&cached_response).unwrap();
        return Ok(Json(cached_chat_response).into_response());
    }

    // 处理搜索模式 - 按照原始项目的方式
    let mut model_to_use = request.model.clone();
    let mut messages_to_use = request.messages.clone();
    
    // 检查是否是搜索模式
    let (search_mode, search_prompt) = {
        let config = state.config.read().unwrap();
        (config.search_mode, config.search_prompt.clone())
    };
    
    if search_mode && request.model.ends_with("-search") {
        info!("🔍 开启联网搜索模式: {}", request.model);
        
        // 移除模型名称中的 -search 后缀
        model_to_use = request.model.trim_end_matches("-search").to_string();
        
        // 在倒数第二个位置插入搜索提示
        if messages_to_use.len() >= 2 {
            messages_to_use.insert(messages_to_use.len() - 1, Message {
                role: "user".to_string(),
                content: search_prompt,
            });
        }
    }

    // 检查是否为流式请求 - 暂时使用假流式模式
    if request.stream.unwrap_or(false) {
        let fake_streaming = {
            let config = state.config.read().unwrap();
            config.fake_streaming
        };
        info!("🌊 处理流式请求 - 模型: {}, 假流式: {}", model_to_use, fake_streaming);
        
        // 假流式模式：执行普通请求，然后模拟流式返回
        if fake_streaming {
            match state
                .gemini_service
                .chat_completion_with_search(&model_to_use, &messages_to_use, &api_key, search_mode && request.model.ends_with("-search"))
                .await
            {
                Ok(content) => {
                    info!("假流式API请求成功 - 密钥: {}..., 模型: {}", &api_key[..8], &model_to_use);
                    
                    // 创建流式格式响应
                    let response = StreamResponse {
                        id: format!("chatcmpl-{}", uuid::Uuid::new_v4()),
                        object: "chat.completion.chunk".to_string(),
                        created: chrono::Utc::now().timestamp() as u64,
                        model: request.model.clone(),
                        choices: vec![StreamChoice {
                            index: 0,
                            delta: StreamDelta {
                                content: Some(content.clone()),
                                role: Some("assistant".to_string()),
                            },
                            finish_reason: Some("stop".to_string()),
                        }],
                    };
                    
                    // 缓存响应
                    let cache_response = ChatResponse {
                        id: response.id.clone(),
                        object: "chat.completion".to_string(),
                        created: response.created,
                        model: request.model.clone(),
                        choices: vec![Choice {
                            index: 0,
                            message: Message {
                                role: "assistant".to_string(),
                                content,
                            },
                            finish_reason: "stop".to_string(),
                        }],
                        usage: Usage {
                            prompt_tokens: 100,
                            completion_tokens: 50,
                            total_tokens: 150,
                        },
                    };
                    
                    let response_json = serde_json::to_string(&cache_response).unwrap();
                    state.cache_manager.set(cache_key, response_json).await;
                    
                    return Ok(Json(response).into_response());
                }
                Err(e) => {
                    error!("假流式API请求失败 - 密钥: {}..., 模型: {}, 错误: {}", &api_key[..8], &model_to_use, e);
                    return Err((
                        StatusCode::INTERNAL_SERVER_ERROR,
                        Json(ErrorResponse {
                            error: ErrorDetail {
                                message: format!("Stream API error: {}", e),
                                error_type: "api_error".to_string(),
                                code: Some("stream_error".to_string()),
                            },
                        }),
                    ));
                }
            }
        } else {
            // 真流式模式 - 暂时回退到非流式
            info!("真流式模式暂未完全实现，回退到非流式处理");
        }
    }

    // 非流式请求处理（原有逻辑）
    let response_content = match state
        .gemini_service
        .chat_completion_with_search(&model_to_use, &messages_to_use, &api_key, search_mode && request.model.ends_with("-search"))
        .await
    {
        Ok(content) => {
            // 记录API请求成功日志
            info!("API请求成功 - 密钥: {}..., 模型: {}", &api_key[..8], &model_to_use);
            content
        },
        Err(e) => {
            error!("Gemini API 错误: {}", e);
            // 记录API请求失败日志
            error!("API请求失败 - 密钥: {}..., 模型: {}, 错误: {}", &api_key[..8], &model_to_use, e);
            return Err((
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(ErrorResponse {
                    error: ErrorDetail {
                        message: format!("Gemini API error: {}", e),
                        error_type: "api_error".to_string(),
                        code: Some("gemini_error".to_string()),
                    },
                }),
            ));
        }
    };

    let response = ChatResponse {
        id: format!("chatcmpl-{}", uuid::Uuid::new_v4()),
        object: "chat.completion".to_string(),
        created: chrono::Utc::now().timestamp() as u64,
        model: request.model,
        choices: vec![Choice {
            index: 0,
            message: Message {
                role: "assistant".to_string(),
                content: response_content,
            },
            finish_reason: "stop".to_string(),
        }],
        usage: Usage {
            prompt_tokens: 100, // 简化处理
            completion_tokens: 50,
            total_tokens: 150,
        },
    };

    // 缓存响应
    let response_json = serde_json::to_string(&response).unwrap();
    state.cache_manager.set(cache_key, response_json).await;

    Ok(Json(response).into_response())
}

async fn get_stats(State(state): State<AppState>) -> Json<serde_json::Value> {
    let pool_stats = state.connection_pool.get_stats();
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    let cache_expiry_seconds = {
        let config = state.config.read().unwrap();
        config.cache_expiry_seconds
    };
    
    let utilization = if pool_stats.max_concurrent > 0 {
        (pool_stats.in_use as f64 / pool_stats.max_concurrent as f64 * 100.0).round()
    } else {
        0.0
    };
    
    Json(serde_json::json!({
        "performance": {
            "connection_pool": {
                "max_concurrent": pool_stats.max_concurrent,
                "available": pool_stats.available,
                "in_use": pool_stats.in_use,
                "utilization_percent": utilization
            },
            "api_keys": {
                "gemini_count": key_count,
                "has_keys": key_count > 0
            },
            "cache": {
                "entries": state.cache_manager.entry_count(),
                "expiry_seconds": cache_expiry_seconds
            }
        },
        "timestamp": chrono::Utc::now().timestamp()
    }))
}
// 获取仪表盘数据 - 前端期望的格式
async fn get_dashboard_data(State(state): State<AppState>) -> Json<serde_json::Value> {
    let pool_stats = state.connection_pool.get_stats();
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    let all_keys = state.api_key_manager.get_all_gemini_keys().await;
    let rate_limit_stats = state.rate_limiter.get_system_stats().await;
    
    let config = state.config.read().unwrap();
    
    Json(serde_json::json!({
        "key_count": key_count,
        "model_count": 6, // 默认支持的模型数量
        "retry_count": 0, // TODO: 实现重试统计
        "last_24h_calls": 0, // TODO: 实现24小时调用统计
        "hourly_calls": 0, // TODO: 实现小时调用统计
        "minute_calls": 0, // TODO: 实现分钟调用统计
        "current_time": chrono::Utc::now().format("%Y-%m-%d %H:%M:%S UTC").to_string(),
        
        // 基本配置
        "max_requests_per_minute": config.max_requests_per_minute,
        "max_requests_per_day_per_ip": config.max_requests_per_day_per_ip,
        "fake_streaming": config.fake_streaming,
        "fake_streaming_interval": config.fake_streaming_interval,
        "search_mode": config.search_mode,
        "search_prompt": config.search_prompt,
        "random_string": config.random_string,
        "random_string_length": config.random_string_length,
        
        // 高级配置
        "max_retry_num": config.max_retry_num,
        "increase_concurrent_on_failure": config.increase_concurrent_on_failure,
        "max_concurrent_requests": config.max_concurrent_requests,
        "max_empty_responses": config.max_empty_responses,
        "cache_expiry_seconds": config.cache_expiry_seconds,
        "request_timeout_seconds": config.request_timeout_seconds,
        
        // 性能统计
        "performance": {
            "connection_pool": {
                "max_concurrent": pool_stats.max_concurrent,
                "available": pool_stats.available,
                "in_use": pool_stats.in_use,
                "utilization_percent": if pool_stats.max_concurrent > 0 {
                    (pool_stats.in_use as f64 / pool_stats.max_concurrent as f64 * 100.0).round()
                } else { 0.0 }
            },
            "rate_limiter": rate_limit_stats,
            "cache": {
                "entries": state.cache_manager.entry_count(),
                "expiry_seconds": config.cache_expiry_seconds
            }
        },
        
        // API密钥统计 - 简化版本
        "api_key_stats": all_keys.iter().enumerate().map(|(i, key)| {
            serde_json::json!({
                "key_preview": format!("{}...{}",
                    &key[..8.min(key.len())],
                    if key.len() > 8 { &key[key.len()-4..] } else { "" }
                ),
                "index": i,
                "status": "active", // TODO: 实现密钥状态检查
                "calls_today": 0, // TODO: 实现调用统计
                "model_stats": {} // TODO: 实现模型统计
            })
        }).collect::<Vec<_>>(),
        
        // 日志 - 从全局日志管理器获取
        "logs": [], // TODO: 实现日志获取
        
        // 版本信息
        "local_version": "0.1.0-rust",
        "remote_version": "0.1.0-rust",
        "has_update": false
    }))
}

// 更新配置
#[derive(Deserialize)]
struct UpdateConfigRequest {
    key: String,
    value: serde_json::Value,
    password: String,
}

async fn update_config(
    State(state): State<AppState>,
    Json(request): Json<UpdateConfigRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    info!("📝 收到配置更新请求:");
    info!("  - 配置键: {}", request.key);
    info!("  - 配置值长度: {} 字符", request.value.to_string().len());
    info!("  - 密码长度: {} 字符", request.password.len());
    
    // 验证密码
    let web_password = {
        let config = state.config.read().unwrap();
        config.web_password.clone()
    };
    if request.password != web_password {
        warn!("❌ 密码验证失败");
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }
    
    // 处理特定的配置更新 - 实际更新运行时配置
    match request.key.as_str() {
        "gemini_api_keys" => {
            // 解析API密钥字符串
            let keys_str = request.value.as_str().unwrap_or("");
            info!("🔑 收到API密钥更新请求: {} 字符", keys_str.len());
            
            let keys: Vec<String> = keys_str
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect();
            
            info!("🔑 解析出 {} 个API密钥", keys.len());
            
            // 更新运行时配置和API密钥管理器
            {
                let mut config = state.config.write().unwrap();
                config.gemini_api_keys = keys.clone();
            }
            state.api_key_manager.set_gemini_keys(keys).await;
            
            let updated_count = state.api_key_manager.get_gemini_key_count().await;
            info!("🔑 更新后密钥数量: {}", updated_count);
        }
        "fake_streaming" => {
            let value = request.value.as_bool().unwrap_or(false);
            info!("⚙️ 更新假流式响应配置: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.fake_streaming = value;
            }
        }
        "fake_streaming_interval" => {
            let value = request.value.as_f64().unwrap_or(1.0);
            info!("⚙️ 更新假流式响应间隔: {}s", value);
            {
                let mut config = state.config.write().unwrap();
                config.fake_streaming_interval = value;
            }
        }
        "search_mode" => {
            let value = request.value.as_bool().unwrap_or(false);
            info!("🔍 更新联网搜索模式: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.search_mode = value;
            }
        }
        "search_prompt" => {
            let value = request.value.as_str().unwrap_or("").to_string();
            info!("🔍 更新联网搜索提示: {} 字符", value.len());
            {
                let mut config = state.config.write().unwrap();
                config.search_prompt = value.clone();
            }
        }
        "max_retry_num" => {
            let value = request.value.as_u64().unwrap_or(15) as usize;
            info!("🔄 更新最大重试次数: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.max_retry_num = value;
            }
        }
        "increase_concurrent_on_failure" => {
            let value = request.value.as_u64().unwrap_or(0) as usize;
            info!("📈 更新失败时增加并发数: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.increase_concurrent_on_failure = value;
            }
        }
        "max_empty_responses" => {
            let value = request.value.as_u64().unwrap_or(5) as usize;
            info!("🚫 更新空响应重试限制: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.max_empty_responses = value;
            }
        }
        "random_string" => {
            let value = request.value.as_bool().unwrap_or(false);
            info!("🎲 更新随机字符串配置: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.random_string = value;
            }
        }
        "random_string_length" => {
            let value = request.value.as_u64().unwrap_or(5) as usize;
            info!("📏 更新随机字符串长度: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.random_string_length = value;
            }
        }
        "max_requests_per_minute" => {
            let value = request.value.as_u64().unwrap_or(30) as usize;
            info!("⏱️ 更新每分钟请求限制: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.max_requests_per_minute = value;
            }
            // 同步更新限流器配置 - 重置现有限流器让其使用新配置重建
            state.rate_limiter.update_rate_limits(value as u32, 0).await;
        }
        "max_requests_per_day_per_ip" => {
            let value = request.value.as_u64().unwrap_or(600) as usize;
            info!("📅 更新每IP每日请求限制: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.max_requests_per_day_per_ip = value;
            }
            // 同步更新限流器配置 - 重置现有限流器让其使用新配置重建
            state.rate_limiter.update_rate_limits(0, value as u32).await;
        }
        "max_concurrent_requests" => {
            let value = request.value.as_u64().unwrap_or(100) as usize;
            info!("🔄 更新最大并发请求数: {}", value);
            {
                let mut config = state.config.write().unwrap();
                config.max_concurrent_requests = value;
            }
            // 动态更新连接池配置
            state.connection_pool.update_max_concurrent(value);
            
        }
        _ => {
            warn!("❓ 未知的配置项: {}", request.key);
            return Ok(Json(serde_json::json!({
                "success": false,
                "message": format!("Unknown configuration key: {}", request.key)
            })));
        }
    }
    
    // 统一保存配置到.env
    if let Err(e) = state.config.read().unwrap().save_to_env() {
        warn!("保存配置到.env文件失败: {}", e);
    }
    
    Ok(Json(serde_json::json!({
        "success": true,
        "message": "Configuration updated successfully"
    })))
}

// API密钥测试相关的全局状态
use std::sync::atomic::{AtomicUsize, AtomicBool, Ordering};

static TEST_PROGRESS: AtomicUsize = AtomicUsize::new(0);
static TEST_TOTAL: AtomicUsize = AtomicUsize::new(0);
static TEST_VALID: AtomicUsize = AtomicUsize::new(0);
static TEST_INVALID: AtomicUsize = AtomicUsize::new(0);
static TEST_COMPLETED: AtomicBool = AtomicBool::new(false);

#[derive(Deserialize)]
struct TestApiKeysRequest {
    password: String,
}

#[derive(Deserialize)]
struct ClearInvalidKeysRequest {
    password: String,
}

#[derive(Deserialize)]
struct ExportValidKeysRequest {
    password: String,
}

// 测试API密钥
async fn test_api_keys(
    State(state): State<AppState>,
    Json(request): Json<TestApiKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    let web_password = {
        let config = state.config.read().unwrap();
        config.web_password.clone()
    };
    if request.password != web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 重置测试状态
    TEST_PROGRESS.store(0, Ordering::SeqCst);
    TEST_VALID.store(0, Ordering::SeqCst);
    TEST_INVALID.store(0, Ordering::SeqCst);
    TEST_COMPLETED.store(false, Ordering::SeqCst);

    let key_count = state.api_key_manager.get_gemini_key_count().await;
    TEST_TOTAL.store(key_count, Ordering::SeqCst);

    if key_count == 0 {
        TEST_COMPLETED.store(true, Ordering::SeqCst);
        return Ok(Json(serde_json::json!({
            "success": true,
            "message": "No API keys to test"
        })));
    }

    // 在后台异步执行测试
    let api_key_manager = state.api_key_manager.clone();
    tokio::spawn(async move {
        let valid_count = api_key_manager.validate_all_keys().await;
        TEST_VALID.store(valid_count, Ordering::SeqCst);
        TEST_INVALID.store(key_count - valid_count, Ordering::SeqCst);
        TEST_PROGRESS.store(key_count, Ordering::SeqCst);
        TEST_COMPLETED.store(true, Ordering::SeqCst);
    });

    Ok(Json(serde_json::json!({
        "success": true,
        "message": "API key testing started"
    })))
}

// 获取测试进度
async fn get_test_progress() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "completed": TEST_PROGRESS.load(Ordering::SeqCst),
        "total": TEST_TOTAL.load(Ordering::SeqCst),
        "valid": TEST_VALID.load(Ordering::SeqCst),
        "invalid": TEST_INVALID.load(Ordering::SeqCst),
        "is_completed": TEST_COMPLETED.load(Ordering::SeqCst)
    }))
}

// 清除失效API密钥
async fn clear_invalid_api_keys(
    State(state): State<AppState>,
    Json(request): Json<ClearInvalidKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    let web_password = {
        let config = state.config.read().unwrap();
        config.web_password.clone()
    };
    if request.password != web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 清除失效密钥
    let removed_count = state.api_key_manager.remove_invalid_keys().await;
    
    Ok(Json(serde_json::json!({
        "success": true,
        "message": format!("Successfully removed {} invalid API keys", removed_count)
    })))
}

// 导出有效API密钥
async fn export_valid_api_keys(
    State(state): State<AppState>,
    Json(request): Json<ExportValidKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    let web_password = {
        let config = state.config.read().unwrap();
        config.web_password.clone()
    };
    if request.password != web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 获取有效密钥
    let valid_keys = state.api_key_manager.get_valid_keys().await;
    
    Ok(Json(serde_json::json!({
        "success": true,
        "message": format!("Found {} valid API keys", valid_keys.len()),
        "keys": valid_keys
    })))
}

#[derive(Deserialize)]
struct DetectApiKeysRequest {
    password: String,
}

// 检测API密钥状态
async fn detect_api_keys(
    State(state): State<AppState>,
    Json(request): Json<DetectApiKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    let web_password = {
        let config = state.config.read().unwrap();
        config.web_password.clone()
    };
    if request.password != web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 重置测试状态
    TEST_PROGRESS.store(0, Ordering::SeqCst);
    TEST_VALID.store(0, Ordering::SeqCst);
    TEST_INVALID.store(0, Ordering::SeqCst);
    TEST_COMPLETED.store(false, Ordering::SeqCst);

    let key_count = state.api_key_manager.get_gemini_key_count().await;
    TEST_TOTAL.store(key_count, Ordering::SeqCst);

    if key_count == 0 {
        TEST_COMPLETED.store(true, Ordering::SeqCst);
        return Ok(Json(serde_json::json!({
            "success": true,
            "message": "No API keys to detect"
        })));
    }

    // 在后台异步执行检测
    let api_key_manager = state.api_key_manager.clone();
    tokio::spawn(async move {
        let (valid_count, invalid_count) = api_key_manager.detect_api_keys_sync().await;
        TEST_VALID.store(valid_count, Ordering::SeqCst);
        TEST_INVALID.store(invalid_count, Ordering::SeqCst);
        TEST_PROGRESS.store(key_count, Ordering::SeqCst);
        TEST_COMPLETED.store(true, Ordering::SeqCst);
    });

    Ok(Json(serde_json::json!({
        "success": true,
        "message": "API key detection started"
    })))
}

// 获取无效密钥列表
async fn get_invalid_keys(State(state): State<AppState>) -> Json<serde_json::Value> {
    let invalid_keys = state.api_key_manager.get_all_invalid_keys().await;
    let invalid_count = invalid_keys.len();
    
    // 对密钥进行脱敏处理
    let masked_keys: Vec<String> = invalid_keys.iter().map(|key| {
        format!("{}...{}",
            &key[..8.min(key.len())],
            if key.len() > 8 { &key[key.len()-4..] } else { "" }
        )
    }).collect();
    
    Json(serde_json::json!({
        "success": true,
        "count": invalid_count,
        "keys": masked_keys,
        "message": format!("Found {} invalid API keys", invalid_count)
    }))
}

// 流式响应结构体
#[derive(Serialize)]
struct StreamChoice {
    index: u32,
    delta: StreamDelta,
    finish_reason: Option<String>,
}

#[derive(Serialize)]
struct StreamDelta {
    content: Option<String>,
    role: Option<String>,
}

#[derive(Serialize)]
struct StreamResponse {
    id: String,
    object: String,
    created: u64,
    model: String,
    choices: Vec<StreamChoice>,
}

