//! Hajimi Rust 主入口点
//! 
//! 负责初始化和启动应用服务

use hajimi_rust::{App, Config, Result};
use tracing::{info, error};

#[tokio::main]
async fn main() -> Result<()> {
    // 初始化日志
    tracing_subscriber::fmt()
        .with_env_filter("hajimi_rust=info,tower_http=info")
        .init();

    info!("🚀 Hajimi Rust 启动中...");

    // 加载配置
    let config = Config::load().await?;
    info!("📊 配置加载完成: 端口 {}", config.port);

    // 创建并启动应用
    let app = App::new(config).await?;
    
    match app.serve().await {
        Ok(_) => {
            info!("✅ 应用正常关闭");
            Ok(())
        }
        Err(e) => {
            error!("❌ 应用启动失败: {}", e);
            Err(e)
        }
    }
}