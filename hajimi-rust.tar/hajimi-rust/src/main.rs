use axum::{
    extract::{Query, State},
    http::{HeaderMap, StatusCode},
    response::{Html, Json},
    routing::{get, post},
    Router,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::net::TcpListener;
use tower_http::{
    cors::{Any, CorsLayer},
    services::ServeDir,
};
use tracing::{info, warn, error};

mod config;
mod services;
mod utils;

use config::AppConfig;
use services::{gemini::GeminiService, openai::OpenAIService};
use utils::{
    api_key::ApiKeyManager,
    auth::{self, AuthQuery},
    cache::CacheManager,
    connection_pool::ConnectionPool,
    logging::{GLOBAL_LOG_MANAGER, LogLevel},
};

#[derive(Clone)]
pub struct AppState {
    pub config: AppConfig,
    pub gemini_service: Arc<GeminiService>,
    pub openai_service: Arc<OpenAIService>,
    pub api_key_manager: Arc<ApiKeyManager>,
    pub cache_manager: Arc<CacheManager>,
    pub connection_pool: Arc<ConnectionPool>,
}

#[derive(Deserialize)]
struct ChatRequest {
    model: String,
    messages: Vec<Message>,
    stream: Option<bool>,
    temperature: Option<f32>,
    max_tokens: Option<u32>,
}

#[derive(Deserialize, Serialize, Clone)]
pub struct Message {
    pub role: String,
    pub content: String,
}

#[derive(Serialize, Deserialize)]
struct ChatResponse {
    id: String,
    object: String,
    created: u64,
    model: String,
    choices: Vec<Choice>,
    usage: Usage,
}

#[derive(Serialize, Deserialize)]
struct Choice {
    index: u32,
    message: Message,
    finish_reason: String,
}

#[derive(Serialize, Deserialize)]
struct Usage {
    prompt_tokens: u32,
    completion_tokens: u32,
    total_tokens: u32,
}

#[derive(Serialize)]
struct ErrorResponse {
    error: ErrorDetail,
}

#[derive(Serialize)]
struct ErrorDetail {
    message: String,
    #[serde(rename = "type")]
    error_type: String,
    code: Option<String>,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // 初始化日志
    tracing_subscriber::fmt()
        .with_env_filter("hajimi_rust=info,tower_http=info")
        .init();

    // 加载配置
    let config = AppConfig::load()?;
    info!("🚀 Hajimi Rust 高性能反向代理启动");
    info!("📊 配置加载: 端口 {}, 密码已设置", config.port);
    
    // 添加启动日志到我们的日志系统
    log_info!("🚀 Hajimi Rust 高性能反向代理启动");
    log_info!("📊 配置加载完成: 端口 {}, 最大并发请求 {}", config.port, config.max_concurrent_requests);

    // 初始化服务组件
    let connection_pool = Arc::new(ConnectionPool::new(
        config.max_concurrent_requests,
        config.request_timeout_seconds
    ));
    let gemini_service = Arc::new(GeminiService::new_with_pool(connection_pool.clone()));
    let openai_service = Arc::new(OpenAIService::new_with_pool(connection_pool.clone()));
    let api_key_manager = Arc::new(ApiKeyManager::new_with_storage(
        config.gemini_api_keys.clone(),
        "storage/api_keys.json".to_string()
    ));
    
    // 尝试从持久化存储加载密钥
    if let Err(e) = api_key_manager.load_from_storage().await {
        warn!("加载持久化密钥失败: {}", e);
    }
    let cache_manager = Arc::new(CacheManager::new(config.cache_expiry_seconds));

    let state = AppState {
        config: config.clone(),
        gemini_service,
        openai_service,
        api_key_manager,
        cache_manager,
        connection_pool,
    };

    // 显示API密钥信息
    info!("🔑 API 密钥状态:");
    state.api_key_manager.show_key_info().await;

    // 构建路由 - 按照原始项目设计
    let app = Router::new()
        .route("/", get(dashboard))
        .route("/v1/chat/completions", post(chat_completions))
        .route("/v1/models", get(list_models))
        .route("/health", get(health_check))
        // 管理API
        .route("/api/set_keys", post(auth::set_api_keys))
        .route("/api/key_info", get(auth::get_api_key_info))
        .route("/api/stats", get(get_stats))
        .route("/api/dashboard-data", get(get_dashboard_data))
        .route("/api/update-config", post(update_config))
        // API密钥管理端点
        .route("/api/test-api-keys", post(test_api_keys))
        .route("/api/test-api-keys/progress", get(get_test_progress))
        .route("/api/clear-invalid-api-keys", post(clear_invalid_api_keys))
        .route("/api/export-valid-api-keys", post(export_valid_api_keys))
        // 新的API密钥检测端点
        .route("/api/detect-api-keys", post(detect_api_keys))
        .route("/api/get-invalid-keys", get(get_invalid_keys))
        .nest_service("/assets", ServeDir::new("templates/assets"))
        .layer(
            CorsLayer::new()
                .allow_origin(Any)
                .allow_methods(Any)
                .allow_headers(Any),
        )
        .with_state(state);

    let addr = format!("0.0.0.0:{}", config.port);
    info!("🌐 服务器启动: {}", addr);
    info!("📈 高性能模式: 最大并发 {}, 超时 {}s, 缓存 {}s", 
          config.max_concurrent_requests, 
          config.request_timeout_seconds,
          config.cache_expiry_seconds);
    
    let listener = TcpListener::bind(&addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}

async fn dashboard() -> Html<&'static str> {
    Html(include_str!("../templates/index.html"))
}

async fn health_check(State(state): State<AppState>) -> Json<serde_json::Value> {
    let pool_stats = state.connection_pool.get_stats();
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    
    Json(serde_json::json!({
        "status": "ok",
        "timestamp": chrono::Utc::now().timestamp(),
        "performance": {
            "connection_pool": {
                "max_concurrent": pool_stats.max_concurrent,
                "available": pool_stats.available,
                "in_use": pool_stats.in_use
            },
            "api_keys": {
                "gemini_count": key_count,
                "has_keys": key_count > 0
            },
            "cache_entries": state.cache_manager.entry_count()
        }
    }))
}

async fn list_models(State(state): State<AppState>) -> Result<Json<serde_json::Value>, StatusCode> {
    let has_keys = state.api_key_manager.has_keys().await;
    
    let models = if has_keys {
        vec![
            "gemini-1.5-pro", "gemini-1.5-flash", "gemini-1.0-pro",
            "gemini-pro", "gemini-pro-vision"
        ]
    } else {
        vec![]
    };

    let response = serde_json::json!({
        "object": "list",
        "data": models.iter().map(|model| {
            serde_json::json!({
                "id": model,
                "object": "model",
                "created": chrono::Utc::now().timestamp(),
                "owned_by": "hajimi-rust"
            })
        }).collect::<Vec<_>>()
    });

    Ok(Json(response))
}

async fn chat_completions(
    State(state): State<AppState>,
    headers: HeaderMap,
    query: Option<Query<AuthQuery>>,
    Json(request): Json<ChatRequest>,
) -> Result<Json<ChatResponse>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    if let Err((status, Json(auth_error))) = auth::verify_password(&headers, query, &state).await {
        return Err((status, Json(ErrorResponse {
            error: ErrorDetail {
                message: auth_error.message,
                error_type: auth_error.error,
                code: None,
            },
        })));
    }

    // 获取连接池许可
    let _permit = match state.connection_pool.acquire_permit().await {
        Ok(permit) => permit,
        Err(e) => {
            error!("连接池获取许可失败: {}", e);
            return Err((
                StatusCode::SERVICE_UNAVAILABLE,
                Json(ErrorResponse {
                    error: ErrorDetail {
                        message: "Service temporarily unavailable".to_string(),
                        error_type: "service_unavailable".to_string(),
                        code: Some("connection_pool_full".to_string()),
                    },
                }),
            ));
        }
    };

    // 检查是否有可用的API密钥
    if !state.api_key_manager.has_keys().await {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "No Gemini API keys configured. Please set API keys in the dashboard.".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("no_api_keys".to_string()),
                },
            }),
        ));
    }

    // 检查模型支持
    if !request.model.starts_with("gemini") {
        return Err((
            StatusCode::BAD_REQUEST,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Only Gemini models are supported".to_string(),
                    error_type: "invalid_request_error".to_string(),
                    code: Some("unsupported_model".to_string()),
                },
            }),
        ));
    }

    // 获取可用的API密钥
    let api_key = match state.api_key_manager.get_available_gemini_key().await {
        Some(key) => {
            // 记录API请求开始日志
            log_api_request!(
                LogLevel::Info,
                "API请求开始",
                &key[..8], // 只显示密钥前8位
                "chat_completion",
                &request.model,
                200
            );
            key
        },
        None => {
            log_error!("没有可用的Gemini API密钥");
            return Err((
                StatusCode::SERVICE_UNAVAILABLE,
                Json(ErrorResponse {
                    error: ErrorDetail {
                        message: "No available Gemini API keys".to_string(),
                        error_type: "service_unavailable".to_string(),
                        code: Some("no_available_keys".to_string()),
                    },
                }),
            ));
        }
    };

    // 生成缓存键
    let cache_key = format!("{}:{}", 
        request.model, 
        xxhash_rust::xxh3::xxh3_64(
            serde_json::to_string(&request.messages).unwrap().as_bytes()
        )
    );

    // 检查缓存
    if let Some(cached_response) = state.cache_manager.get(&cache_key).await {
        info!("🎯 缓存命中: {}", cache_key);
        return Ok(Json(serde_json::from_str(&cached_response).unwrap()));
    }

    // 处理搜索模式 - 按照原始项目的方式
    let mut model_to_use = request.model.clone();
    let mut messages_to_use = request.messages.clone();
    
    // 检查是否是搜索模式
    if state.config.search_mode && request.model.ends_with("-search") {
        info!("🔍 开启联网搜索模式: {}", request.model);
        
        // 移除模型名称中的 -search 后缀
        model_to_use = request.model.trim_end_matches("-search").to_string();
        
        // 在倒数第二个位置插入搜索提示
        if messages_to_use.len() >= 2 {
            messages_to_use.insert(messages_to_use.len() - 1, Message {
                role: "user".to_string(),
                content: state.config.search_prompt.clone(),
            });
        }
    }

    // 调用Gemini服务
    let response_content = match state
        .gemini_service
        .chat_completion_with_search(&model_to_use, &messages_to_use, &api_key, state.config.search_mode && request.model.ends_with("-search"))
        .await
    {
        Ok(content) => {
            // 记录API请求成功日志
            log_api_request!(
                LogLevel::Info,
                "API请求成功",
                &api_key[..8],
                "chat_completion",
                &model_to_use,
                200
            );
            content
        },
        Err(e) => {
            error!("Gemini API 错误: {}", e);
            // 记录API请求失败日志
            log_api_request!(
                LogLevel::Error,
                "API请求失败",
                &api_key[..8],
                "chat_completion",
                &model_to_use,
                500,
                format!("Gemini API error: {}", e)
            );
            return Err((
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(ErrorResponse {
                    error: ErrorDetail {
                        message: format!("Gemini API error: {}", e),
                        error_type: "api_error".to_string(),
                        code: Some("gemini_error".to_string()),
                    },
                }),
            ));
        }
    };

    let response = ChatResponse {
        id: format!("chatcmpl-{}", uuid::Uuid::new_v4()),
        object: "chat.completion".to_string(),
        created: chrono::Utc::now().timestamp() as u64,
        model: request.model,
        choices: vec![Choice {
            index: 0,
            message: Message {
                role: "assistant".to_string(),
                content: response_content,
            },
            finish_reason: "stop".to_string(),
        }],
        usage: Usage {
            prompt_tokens: 100, // 简化处理
            completion_tokens: 50,
            total_tokens: 150,
        },
    };

    // 缓存响应
    let response_json = serde_json::to_string(&response).unwrap();
    state.cache_manager.set(cache_key, response_json).await;

    Ok(Json(response))
}

async fn get_stats(State(state): State<AppState>) -> Json<serde_json::Value> {
    let pool_stats = state.connection_pool.get_stats();
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    
    let utilization = if pool_stats.max_concurrent > 0 {
        (pool_stats.in_use as f64 / pool_stats.max_concurrent as f64 * 100.0).round()
    } else {
        0.0
    };
    
    Json(serde_json::json!({
        "performance": {
            "connection_pool": {
                "max_concurrent": pool_stats.max_concurrent,
                "available": pool_stats.available,
                "in_use": pool_stats.in_use,
                "utilization_percent": utilization
            },
            "api_keys": {
                "gemini_count": key_count,
                "has_keys": key_count > 0
            },
            "cache": {
                "entries": state.cache_manager.entry_count(),
                "expiry_seconds": state.config.cache_expiry_seconds
            }
        },
        "timestamp": chrono::Utc::now().timestamp()
    }))
}

// 获取仪表盘数据 - 前端期望的格式
async fn get_dashboard_data(State(state): State<AppState>) -> Json<serde_json::Value> {
    let pool_stats = state.connection_pool.get_stats();
    let key_count = state.api_key_manager.get_gemini_key_count().await;
    let all_keys = state.api_key_manager.get_all_gemini_keys().await;
    
    
    let utilization = if pool_stats.max_concurrent > 0 {
        (pool_stats.in_use as f64 / pool_stats.max_concurrent as f64 * 100.0).round()
    } else {
        0.0
    };
    
    // 构建API密钥统计数据
    let mut api_key_stats = Vec::new();
    for (index, key) in all_keys.iter().enumerate() {
        let masked_key = format!("{}...{}",
            &key[..8.min(key.len())],
            if key.len() > 8 { &key[key.len()-4..] } else { "" }
        );
        
        api_key_stats.push(serde_json::json!({
            "id": index + 1,
            "key": masked_key,
            "calls_24h": 0,
            "total_tokens": 0,
            "status": "unknown", // 可以是 "valid", "invalid", "unknown"
            "last_used": null,
            "model_stats": {}
        }));
    }
    
    Json(serde_json::json!({
        // 前端期望的顶级字段
        "key_count": key_count,
        "model_count": if key_count > 0 { 5 } else { 0 },
        "retry_count": 0,
        "last_24h_calls": 0,
        "hourly_calls": 0,
        "minute_calls": 0,
        "enable_vertex": false,
        "max_requests_per_minute": 60,
        "max_requests_per_day_per_ip": 1000,
        "current_time": chrono::Utc::now().format("%Y-%m-%d %H:%M:%S UTC").to_string(),
        "fake_streaming": state.config.fake_streaming,
        "fake_streaming_interval": 50,
        "random_string": false,
        "search_mode": state.config.search_mode,
        "search_prompt": state.config.search_prompt,
        "local_version": "1.0.0-rust",
        "remote_version": "1.0.0-rust",
        "has_update": false,
        "concurrent_requests": pool_stats.in_use,
        "max_concurrent_requests": pool_stats.max_concurrent,
        "max_retry_num": 3,
        "max_empty_responses": 5,
        "api_key_stats": api_key_stats,
        "logs": GLOBAL_LOG_MANAGER.get_recent_logs(500).await,
        "calls_time_series": [],
        "tokens_time_series": []
    }))
}

// 更新配置
#[derive(Deserialize)]
struct UpdateConfigRequest {
    key: String,
    value: serde_json::Value,
    password: String,
}

async fn update_config(
    State(state): State<AppState>,
    Json(request): Json<UpdateConfigRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    info!("📝 收到配置更新请求:");
    info!("  - 配置键: {}", request.key);
    info!("  - 配置值长度: {} 字符", request.value.to_string().len());
    info!("  - 密码长度: {} 字符", request.password.len());
    
    // 验证密码
    if request.password != state.config.web_password {
        warn!("❌ 密码验证失败");
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }
    
    // 处理特定的配置更新
    match request.key.as_str() {
        "gemini_api_keys" => {
            // 解析API密钥字符串
            let keys_str = request.value.as_str().unwrap_or("");
            info!("🔑 收到API密钥更新请求: {} 字符", keys_str.len());
            
            let keys: Vec<String> = keys_str
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect();
            
            info!("🔑 解析出 {} 个API密钥", keys.len());
            if !keys.is_empty() {
                info!("🔑 前3个密钥预览: {:?}",
                    keys.iter().take(3).map(|k| format!("{}...", &k[..8.min(k.len())])).collect::<Vec<_>>()
                );
            }
            
            // 更新API密钥管理器
            state.api_key_manager.set_gemini_keys(keys).await;
            
            // 验证更新后的状态
            let updated_count = state.api_key_manager.get_gemini_key_count().await;
            info!("🔑 更新后密钥数量: {}", updated_count);
            
            Ok(Json(serde_json::json!({
                "success": true,
                "message": "API keys updated successfully"
            })))
        }
        _ => {
            // 其他配置项的处理
            Ok(Json(serde_json::json!({
                "success": true,
                "message": "Configuration updated successfully"
            })))
        }
    }
}

// API密钥测试相关的全局状态
use std::sync::atomic::{AtomicUsize, AtomicBool, Ordering};

static TEST_PROGRESS: AtomicUsize = AtomicUsize::new(0);
static TEST_TOTAL: AtomicUsize = AtomicUsize::new(0);
static TEST_VALID: AtomicUsize = AtomicUsize::new(0);
static TEST_INVALID: AtomicUsize = AtomicUsize::new(0);
static TEST_COMPLETED: AtomicBool = AtomicBool::new(false);

#[derive(Deserialize)]
struct TestApiKeysRequest {
    password: String,
}

#[derive(Deserialize)]
struct ClearInvalidKeysRequest {
    password: String,
}

#[derive(Deserialize)]
struct ExportValidKeysRequest {
    password: String,
}

// 测试API密钥
async fn test_api_keys(
    State(state): State<AppState>,
    Json(request): Json<TestApiKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    if request.password != state.config.web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 重置测试状态
    TEST_PROGRESS.store(0, Ordering::SeqCst);
    TEST_VALID.store(0, Ordering::SeqCst);
    TEST_INVALID.store(0, Ordering::SeqCst);
    TEST_COMPLETED.store(false, Ordering::SeqCst);

    let key_count = state.api_key_manager.get_gemini_key_count().await;
    TEST_TOTAL.store(key_count, Ordering::SeqCst);

    if key_count == 0 {
        TEST_COMPLETED.store(true, Ordering::SeqCst);
        return Ok(Json(serde_json::json!({
            "success": true,
            "message": "No API keys to test"
        })));
    }

    // 在后台异步执行测试
    let api_key_manager = state.api_key_manager.clone();
    tokio::spawn(async move {
        let valid_count = api_key_manager.validate_all_keys().await;
        TEST_VALID.store(valid_count, Ordering::SeqCst);
        TEST_INVALID.store(key_count - valid_count, Ordering::SeqCst);
        TEST_PROGRESS.store(key_count, Ordering::SeqCst);
        TEST_COMPLETED.store(true, Ordering::SeqCst);
    });

    Ok(Json(serde_json::json!({
        "success": true,
        "message": "API key testing started"
    })))
}

// 获取测试进度
async fn get_test_progress() -> Json<serde_json::Value> {
    Json(serde_json::json!({
        "completed": TEST_PROGRESS.load(Ordering::SeqCst),
        "total": TEST_TOTAL.load(Ordering::SeqCst),
        "valid": TEST_VALID.load(Ordering::SeqCst),
        "invalid": TEST_INVALID.load(Ordering::SeqCst),
        "is_completed": TEST_COMPLETED.load(Ordering::SeqCst)
    }))
}

// 清除失效API密钥
async fn clear_invalid_api_keys(
    State(state): State<AppState>,
    Json(request): Json<ClearInvalidKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    if request.password != state.config.web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 清除失效密钥
    let removed_count = state.api_key_manager.remove_invalid_keys().await;
    
    Ok(Json(serde_json::json!({
        "success": true,
        "message": format!("Successfully removed {} invalid API keys", removed_count)
    })))
}

// 导出有效API密钥
async fn export_valid_api_keys(
    State(state): State<AppState>,
    Json(request): Json<ExportValidKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    if request.password != state.config.web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 获取有效密钥
    let valid_keys = state.api_key_manager.get_valid_keys().await;
    
    Ok(Json(serde_json::json!({
        "success": true,
        "message": format!("Found {} valid API keys", valid_keys.len()),
        "keys": valid_keys
    })))
}

#[derive(Deserialize)]
struct DetectApiKeysRequest {
    password: String,
}

// 检测API密钥状态
async fn detect_api_keys(
    State(state): State<AppState>,
    Json(request): Json<DetectApiKeysRequest>,
) -> Result<Json<serde_json::Value>, (StatusCode, Json<ErrorResponse>)> {
    // 验证密码
    if request.password != state.config.web_password {
        return Err((
            StatusCode::UNAUTHORIZED,
            Json(ErrorResponse {
                error: ErrorDetail {
                    message: "Invalid password".to_string(),
                    error_type: "authentication_error".to_string(),
                    code: Some("invalid_password".to_string()),
                },
            }),
        ));
    }

    // 重置测试状态
    TEST_PROGRESS.store(0, Ordering::SeqCst);
    TEST_VALID.store(0, Ordering::SeqCst);
    TEST_INVALID.store(0, Ordering::SeqCst);
    TEST_COMPLETED.store(false, Ordering::SeqCst);

    let key_count = state.api_key_manager.get_gemini_key_count().await;
    TEST_TOTAL.store(key_count, Ordering::SeqCst);

    if key_count == 0 {
        TEST_COMPLETED.store(true, Ordering::SeqCst);
        return Ok(Json(serde_json::json!({
            "success": true,
            "message": "No API keys to detect"
        })));
    }

    // 在后台异步执行检测
    let api_key_manager = state.api_key_manager.clone();
    tokio::spawn(async move {
        let (valid_count, invalid_count) = api_key_manager.detect_api_keys_sync().await;
        TEST_VALID.store(valid_count, Ordering::SeqCst);
        TEST_INVALID.store(invalid_count, Ordering::SeqCst);
        TEST_PROGRESS.store(key_count, Ordering::SeqCst);
        TEST_COMPLETED.store(true, Ordering::SeqCst);
    });

    Ok(Json(serde_json::json!({
        "success": true,
        "message": "API key detection started"
    })))
}

// 获取无效密钥列表
async fn get_invalid_keys(State(state): State<AppState>) -> Json<serde_json::Value> {
    let invalid_keys = state.api_key_manager.get_all_invalid_keys().await;
    let invalid_count = invalid_keys.len();
    
    // 对密钥进行脱敏处理
    let masked_keys: Vec<String> = invalid_keys.iter().map(|key| {
        format!("{}...{}",
            &key[..8.min(key.len())],
            if key.len() > 8 { &key[key.len()-4..] } else { "" }
        )
    }).collect();
    
    Json(serde_json::json!({
        "success": true,
        "count": invalid_count,
        "keys": masked_keys,
        "message": format!("Found {} invalid API keys", invalid_count)
    }))
}
