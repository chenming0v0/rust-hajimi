//! 错误处理模块
//! 
//! 统一的错误类型定义和处理

use axum::{
    http::StatusCode,
    response::{IntoResponse, Json, Response},
};
use serde_json::json;
use thiserror::Error;

pub type Result<T> = std::result::Result<T, Error>;

/// 应用错误类型
#[derive(Error, Debug)]
pub enum Error {
    #[error("配置错误: {0}")]
    Config(String),
    
    #[error("网络错误: {0}")]
    Network(#[from] reqwest::Error),
    
    #[error("序列化错误: {0}")]
    Json(#[from] serde_json::Error),
    
    #[error("IO错误: {0}")]
    Io(#[from] std::io::Error),
    
    #[error("环境变量错误: {0}")]
    EnvVar(#[from] std::env::VarError),
    
    #[error("API错误: {0}")]
    Api(String),
    
    #[error("验证失败: {0}")]
    Auth(String),
    
    #[error("限流: {0}")]
    RateLimit(String),
    
    #[error("服务不可用: {0}")]
    ServiceUnavailable(String),
    
    #[error("内部错误: {0}")]
    Internal(String),
    
    #[error("解析错误: {0}")]
    Parse(String),
    
    #[error("验证错误: {0}")]
    Validation(String),
}

impl Error {
    /// 获取HTTP状态码
    pub fn status_code(&self) -> StatusCode {
        match self {
            Error::Config(_) => StatusCode::INTERNAL_SERVER_ERROR,
            Error::Network(_) => StatusCode::BAD_GATEWAY,
            Error::Json(_) => StatusCode::BAD_REQUEST,
            Error::Io(_) => StatusCode::INTERNAL_SERVER_ERROR,
            Error::EnvVar(_) => StatusCode::INTERNAL_SERVER_ERROR,
            Error::Api(_) => StatusCode::BAD_GATEWAY,
            Error::Auth(_) => StatusCode::UNAUTHORIZED,
            Error::RateLimit(_) => StatusCode::TOO_MANY_REQUESTS,
            Error::ServiceUnavailable(_) => StatusCode::SERVICE_UNAVAILABLE,
            Error::Internal(_) => StatusCode::INTERNAL_SERVER_ERROR,
            Error::Parse(_) => StatusCode::BAD_REQUEST,
            Error::Validation(_) => StatusCode::BAD_REQUEST,
        }
    }

    /// 获取错误类型字符串
    pub fn error_type(&self) -> &'static str {
        match self {
            Error::Config(_) => "configuration_error",
            Error::Network(_) => "network_error",
            Error::Json(_) => "json_error",
            Error::Io(_) => "io_error",
            Error::EnvVar(_) => "environment_error",
            Error::Api(_) => "api_error",
            Error::Auth(_) => "authentication_error",
            Error::RateLimit(_) => "rate_limit_exceeded",
            Error::ServiceUnavailable(_) => "service_unavailable",
            Error::Internal(_) => "internal_error",
            Error::Parse(_) => "parse_error",
            Error::Validation(_) => "validation_error",
        }
    }
}

/// 实现 IntoResponse trait 以便直接返回错误响应
impl IntoResponse for Error {
    fn into_response(self) -> Response {
        let status_code = self.status_code();
        
        let error_response = json!({
            "error": {
                "message": self.to_string(),
                "type": self.error_type(),
                "code": status_code.as_u16()
            }
        });

        (status_code, Json(error_response)).into_response()
    }
}

/// 从anyhow::Error转换
impl From<anyhow::Error> for Error {
    fn from(err: anyhow::Error) -> Self {
        Error::Internal(err.to_string())
    }
}