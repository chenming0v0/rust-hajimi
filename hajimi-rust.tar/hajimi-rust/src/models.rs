//! 数据模型定义
//! 
//! 定义所有的请求和响应结构体

use serde::{Deserialize, Serialize};

/// Chat Completion 请求
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ChatRequest {
    /// 模型名称
    pub model: String,
    
    /// 消息列表
    pub messages: Vec<Message>,
    
    /// 是否流式响应
    #[serde(default)]
    pub stream: bool,
    
    /// 温度参数 (0.0-1.0)
    #[serde(default)]
    pub temperature: Option<f32>,
    
    /// 最大输出token数
    #[serde(default)]
    pub max_tokens: Option<u32>,
}

/// 消息结构
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Message {
    /// 角色 (system, user, assistant)
    pub role: String,
    
    /// 消息内容
    pub content: MessageContent,
}

/// 消息内容 - 支持文本或多模态内容
#[derive(Debug, Clone, Deserialize, Serialize)]
#[serde(untagged)]
pub enum MessageContent {
    /// 纯文本内容
    Text(String),
    
    /// 多模态内容数组
    Array(Vec<ContentPart>),
}

/// 内容部分 - 支持文本、图像等
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ContentPart {
    /// 内容类型 (text, image_url, etc.)
    #[serde(rename = "type")]
    pub content_type: String,
    
    /// 文本内容
    pub text: Option<String>,
    
    /// 图像URL
    pub image_url: Option<ImageUrl>,
}

/// 图像URL结构
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ImageUrl {
    pub url: String,
    #[serde(default)]
    pub detail: Option<String>,
}

/// Chat Completion 响应
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ChatResponse {
    /// 响应ID
    pub id: String,
    
    /// 对象类型
    pub object: String,
    
    /// 创建时间戳
    pub created: u64,
    
    /// 使用的模型
    pub model: String,
    
    /// 选择列表
    pub choices: Vec<Choice>,
    
    /// 使用统计
    pub usage: Usage,
}

/// 选择项
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Choice {
    /// 索引
    pub index: u32,
    
    /// 消息内容
    pub message: Message,
    
    /// 完成原因
    pub finish_reason: String,
}

/// 流式响应
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct StreamResponse {
    /// 响应ID
    pub id: String,
    
    /// 对象类型
    pub object: String,
    
    /// 创建时间戳
    pub created: u64,
    
    /// 使用的模型
    pub model: String,
    
    /// 流式选择列表
    pub choices: Vec<StreamChoice>,
}

/// 流式选择项
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct StreamChoice {
    /// 索引
    pub index: u32,
    
    /// 增量内容
    pub delta: StreamDelta,
    
    /// 完成原因
    pub finish_reason: Option<String>,
}

/// 流式增量内容
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct StreamDelta {
    /// 角色
    pub role: Option<String>,
    
    /// 内容增量
    pub content: Option<String>,
}

/// 使用统计
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Usage {
    /// 提示词token数
    pub prompt_tokens: u32,
    
    /// 完成token数
    pub completion_tokens: u32,
    
    /// 总token数
    pub total_tokens: u32,
}

/// 模型列表响应
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ModelsResponse {
    /// 对象类型
    pub object: String,
    
    /// 模型数据
    pub data: Vec<Model>,
}

/// 模型信息
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Model {
    /// 模型ID
    pub id: String,
    
    /// 对象类型
    pub object: String,
    
    /// 创建时间
    pub created: u64,
    
    /// 拥有者
    pub owned_by: String,
}

/// 错误响应
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ErrorResponse {
    /// 错误详情
    pub error: ErrorDetail,
}

/// 错误详情
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ErrorDetail {
    /// 错误消息
    pub message: String,
    
    /// 错误类型
    #[serde(rename = "type")]
    pub error_type: String,
    
    /// 错误代码
    pub code: Option<String>,
}

/// 健康检查响应
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct HealthResponse {
    /// 状态
    pub status: String,
    
    /// 时间戳
    pub timestamp: i64,
    
    /// 性能指标
    pub performance: PerformanceMetrics,
}

/// 性能指标
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct PerformanceMetrics {
    /// 连接池状态
    pub connection_pool: ConnectionPoolStats,
    
    /// API密钥状态
    pub api_keys: ApiKeyStats,
    
    /// 缓存统计
    pub cache_entries: usize,
}

/// 连接池统计
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ConnectionPoolStats {
    /// 最大并发数
    pub max_concurrent: usize,
    
    /// 可用连接数
    pub available: usize,
    
    /// 使用中连接数
    pub in_use: usize,
}

/// API密钥统计
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct ApiKeyStats {
    /// Gemini密钥数量
    pub gemini_count: usize,
    
    /// 是否有可用密钥
    pub has_keys: bool,
}

impl MessageContent {
    /// 转换为字符串
    pub fn as_string(&self) -> String {
        match self {
            MessageContent::Text(text) => text.clone(),
            MessageContent::Array(parts) => {
                parts
                    .iter()
                    .filter(|part| part.content_type == "text")
                    .filter_map(|part| part.text.as_ref())
                    .cloned()
                    .collect::<Vec<String>>()
                    .join(" ")
            }
        }
    }
    
    /// 检查是否包含图像
    pub fn has_images(&self) -> bool {
        match self {
            MessageContent::Text(_) => false,
            MessageContent::Array(parts) => {
                parts.iter().any(|part| part.content_type == "image_url")
            }
        }
    }
}

impl Default for ChatRequest {
    fn default() -> Self {
        Self {
            model: "gemini-1.5-pro".to_string(),
            messages: vec![],
            stream: false,
            temperature: Some(0.7),
            max_tokens: Some(2048),
        }
    }
}

impl Default for Usage {
    fn default() -> Self {
        Self {
            prompt_tokens: 0,
            completion_tokens: 0,
            total_tokens: 0,
        }
    }
}