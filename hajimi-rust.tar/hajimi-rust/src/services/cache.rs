//! 缓存服务模块
//! 
//! 提供内存缓存功能以提高响应性能

use std::{
    collections::HashMap,
    sync::{Arc, RwLock},
    time::{Duration, Instant},
};
use tracing::{debug, info};

/// 缓存项
#[derive(Debug, Clone)]
struct CacheItem {
    value: String,
    expires_at: Instant,
}

/// 缓存服务
pub struct CacheService {
    store: Arc<RwLock<HashMap<String, CacheItem>>>,
    default_ttl: Duration,
}

impl CacheService {
    /// 创建新的缓存服务
    pub fn new(ttl_seconds: u64) -> Self {
        Self {
            store: Arc::new(RwLock::new(HashMap::new())),
            default_ttl: Duration::from_secs(ttl_seconds),
        }
    }

    /// 设置缓存项
    pub async fn set(&self, key: String, value: String) {
        self.set_with_ttl(key, value, self.default_ttl).await;
    }

    /// 设置带自定义TTL的缓存项
    pub async fn set_with_ttl(&self, key: String, value: String, ttl: Duration) {
        let expires_at = Instant::now() + ttl;
        let item = CacheItem { value, expires_at };

        if let Ok(mut store) = self.store.write() {
            store.insert(key.clone(), item);
            debug!("📦 缓存项已设置: {}", key);
        }

        // 异步清理过期项
        tokio::spawn({
            let store = Arc::clone(&self.store);
            async move {
                tokio::time::sleep(ttl + Duration::from_secs(10)).await;
                if let Ok(mut store) = store.write() {
                    store.retain(|_, item| item.expires_at > Instant::now());
                }
            }
        });
    }

    /// 获取缓存项
    pub async fn get(&self, key: &str) -> Option<String> {
        if let Ok(mut store) = self.store.write() {
            if let Some(item) = store.get(key) {
                if item.expires_at > Instant::now() {
                    debug!("🎯 缓存命中: {}", key);
                    return Some(item.value.clone());
                } else {
                    // 移除过期项
                    store.remove(key);
                    debug!("⏰ 缓存过期并移除: {}", key);
                }
            }
        }
        
        debug!("❌ 缓存未命中: {}", key);
        None
    }

    /// 删除缓存项
    pub async fn delete(&self, key: &str) -> bool {
        if let Ok(mut store) = self.store.write() {
            if store.remove(key).is_some() {
                debug!("🗑️ 缓存项已删除: {}", key);
                true
            } else {
                false
            }
        } else {
            false
        }
    }

    /// 检查缓存项是否存在且未过期
    pub async fn exists(&self, key: &str) -> bool {
        self.get(key).await.is_some()
    }

    /// 清空所有缓存
    pub async fn clear(&self) {
        if let Ok(mut store) = self.store.write() {
            let count = store.len();
            store.clear();
            info!("🧹 已清空 {} 个缓存项", count);
        }
    }

    /// 清理过期的缓存项
    pub async fn cleanup_expired(&self) {
        if let Ok(mut store) = self.store.write() {
            let before_count = store.len();
            let now = Instant::now();
            store.retain(|_, item| item.expires_at > now);
            let after_count = store.len();
            let cleaned = before_count - after_count;
            
            if cleaned > 0 {
                info!("🧹 清理了 {} 个过期缓存项", cleaned);
            }
        }
    }

    /// 获取缓存统计信息
    pub fn get_stats(&self) -> CacheStats {
        if let Ok(store) = self.store.read() {
            let total_items = store.len();
            let now = Instant::now();
            let valid_items = store.values().filter(|item| item.expires_at > now).count();
            let expired_items = total_items - valid_items;

            CacheStats {
                total_items,
                valid_items,
                expired_items,
            }
        } else {
            CacheStats::default()
        }
    }

    /// 获取所有缓存键
    pub async fn keys(&self) -> Vec<String> {
        if let Ok(store) = self.store.read() {
            let now = Instant::now();
            store
                .iter()
                .filter(|(_, item)| item.expires_at > now)
                .map(|(key, _)| key.clone())
                .collect()
        } else {
            vec![]
        }
    }

    /// 获取缓存项数量
    pub fn entry_count(&self) -> usize {
        if let Ok(store) = self.store.read() {
            let now = Instant::now();
            store.values().filter(|item| item.expires_at > now).count()
        } else {
            0
        }
    }

    /// 设置缓存项的过期时间
    pub async fn expire(&self, key: &str, ttl: Duration) -> bool {
        if let Ok(mut store) = self.store.write() {
            if let Some(item) = store.get_mut(key) {
                item.expires_at = Instant::now() + ttl;
                debug!("⏰ 更新缓存过期时间: {}", key);
                return true;
            }
        }
        false
    }

    /// 获取缓存项的剩余生存时间
    pub async fn ttl(&self, key: &str) -> Option<Duration> {
        if let Ok(store) = self.store.read() {
            if let Some(item) = store.get(key) {
                let now = Instant::now();
                if item.expires_at > now {
                    return Some(item.expires_at - now);
                }
            }
        }
        None
    }
}

/// 缓存统计信息
#[derive(Debug, Clone, Default)]
pub struct CacheStats {
    pub total_items: usize,
    pub valid_items: usize,
    pub expired_items: usize,
}

/// 缓存键生成器
pub struct CacheKeyGenerator;

impl CacheKeyGenerator {
    /// 生成聊天请求的缓存键
    pub fn chat_key(model: &str, messages_hash: u64) -> String {
        format!("chat:{}:{}", model, messages_hash)
    }

    /// 生成模型列表的缓存键
    pub fn models_key(api_key_hash: u64) -> String {
        format!("models:{}", api_key_hash)
    }

    /// 生成API密钥验证的缓存键
    pub fn api_key_validation_key(api_key_hash: u64) -> String {
        format!("api_key_valid:{}", api_key_hash)
    }

    /// 计算消息的哈希值
    pub fn hash_messages(messages: &[crate::models::Message]) -> u64 {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        let mut hasher = DefaultHasher::new();
        
        for message in messages {
            message.role.hash(&mut hasher);
            message.content.as_string().hash(&mut hasher);
        }

        hasher.finish()
    }

    /// 计算字符串的哈希值
    pub fn hash_string(input: &str) -> u64 {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        let mut hasher = DefaultHasher::new();
        input.hash(&mut hasher);
        hasher.finish()
    }
}

/// 定期清理过期缓存的后台任务
pub async fn start_cleanup_task(cache: Arc<CacheService>, interval: Duration) {
    let mut cleanup_timer = tokio::time::interval(interval);
    
    loop {
        cleanup_timer.tick().await;
        cache.cleanup_expired().await;
    }
}

/// 创建预配置的缓存实例
pub fn create_default_cache() -> CacheService {
    CacheService::new(3600) // 默认1小时TTL
}

/// 创建短期缓存实例
pub fn create_short_term_cache() -> CacheService {
    CacheService::new(300) // 5分钟TTL
}

/// 创建长期缓存实例
pub fn create_long_term_cache() -> CacheService {
    CacheService::new(86400) // 24小时TTL
}

#[cfg(test)]
mod tests {
    use super::*;
    use tokio::time::sleep;

    #[tokio::test]
    async fn test_cache_basic_operations() {
        let cache = CacheService::new(1);
        
        // 测试设置和获取
        cache.set("test_key".to_string(), "test_value".to_string()).await;
        assert_eq!(cache.get("test_key").await, Some("test_value".to_string()));
        
        // 测试过期
        sleep(Duration::from_secs(2)).await;
        assert_eq!(cache.get("test_key").await, None);
    }

    #[tokio::test]
    async fn test_cache_stats() {
        let cache = CacheService::new(60);
        
        cache.set("key1".to_string(), "value1".to_string()).await;
        cache.set("key2".to_string(), "value2".to_string()).await;
        
        let stats = cache.get_stats();
        assert_eq!(stats.valid_items, 2);
    }
}