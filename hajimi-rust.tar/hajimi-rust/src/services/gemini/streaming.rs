//! Gemini真实流式响应处理模块
//! 
//! 基于原Python代码逻辑重新实现，包含SSE协议处理和JSON缓冲机制

use crate::error::{Error, Result};
use super::types::{GeminiResponse, StreamChunk};
use futures_util::{Stream, StreamExt};
use reqwest::Response;
use std::pin::Pin;
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio_util::io::StreamReader;
use tracing::{debug, error, warn};

/// 基于原Python逻辑的真实流式处理器
pub struct GeminiStreaming;

impl GeminiStreaming {
    /// 创建流式响应 - 完全基于原Python代码的逻辑
    /// 
    /// 原Python核心逻辑：
    /// ```python
    /// buffer = b""
    /// async for line in response.aiter_lines():
    ///     if not line.strip(): continue
    ///     if line.startswith("data: "):
    ///         line = line[len("data: "):].strip()
    ///     if line == "[DONE]": break
    ///     buffer += line.encode('utf-8')
    ///     try:
    ///         data = json.loads(buffer.decode('utf-8'))
    ///         buffer = b""
    ///         yield GeminiResponseWrapper(data)
    ///     except json.JSONDecodeError:
    ///         continue
    /// ```
    pub fn create_stream_from_response(
        response: Response,
    ) -> Pin<Box<dyn Stream<Item = Result<StreamChunk>> + Send>> {
        debug!("🌊 开始真实流式处理 (基于原Python逻辑)");
        
        let stream = async_stream::stream! {
            // 转换响应流为按行读取
            let stream_reader = StreamReader::new(
                response.bytes_stream().map(|result| {
                    result.map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))
                })
            );
            let mut lines = BufReader::new(stream_reader).lines();
            
            // 字节缓冲区，模拟原Python的 buffer = b""
            let mut buffer = Vec::<u8>::new();
            
            // 按行处理流式数据
            while let Ok(Some(line)) = lines.next_line().await {
                let line = line.trim();
                
                // 跳过空行 (SSE 消息分隔符) - 原Python: if not line.strip(): continue
                if line.is_empty() {
                    continue;
                }
                
                let mut processed_line = line;
                
                // 处理SSE格式的 "data: " 前缀 - 原Python: if line.startswith("data: ")
                if line.starts_with("data: ") {
                    processed_line = &line[6..]; // 去除 "data: " 前缀
                }
                
                // 检查是否是结束标志 - 原Python: if line == "[DONE]": break
                if processed_line == "[DONE]" {
                    debug!("📋 收到流式结束标志 [DONE]");
                    break;
                }
                
                // 累积数据到缓冲区 - 原Python: buffer += line.encode('utf-8')
                buffer.extend(processed_line.as_bytes());
                
                // 尝试解析JSON - 原Python: try: json.loads(buffer.decode('utf-8'))
                match String::from_utf8(buffer.clone()) {
                    Ok(buffer_str) => {
                        match serde_json::from_str::<GeminiResponse>(&buffer_str) {
                            Ok(gemini_response) => {
                                // 解析成功，清空缓冲区 - 原Python: buffer = b""
                                buffer.clear();
                                
                                // 提取内容并生成流块
                                if let Some(chunk) = Self::extract_content_from_response(&gemini_response) {
                                    debug!("📦 成功解析流式数据块");
                                    yield Ok(chunk);
                                }
                            }
                            Err(json_err) => {
                                // JSON解析失败，继续累积 - 原Python: except json.JSONDecodeError: continue
                                debug!("📝 JSON不完整，继续累积: {}", json_err);
                                continue;
                            }
                        }
                    }
                    Err(utf8_err) => {
                        error!("❌ UTF-8解码错误: {}", utf8_err);
                        yield Err(Error::Parse(format!("UTF-8解码失败: {}", utf8_err)));
                        break;
                    }
                }
            }
            
            // 处理缓冲区中剩余的数据
            if !buffer.is_empty() {
                debug!("🔄 处理缓冲区剩余数据");
                match String::from_utf8(buffer) {
                    Ok(buffer_str) => {
                        if let Ok(gemini_response) = serde_json::from_str::<GeminiResponse>(&buffer_str) {
                            if let Some(chunk) = Self::extract_content_from_response(&gemini_response) {
                                yield Ok(chunk);
                            }
                        }
                    }
                    Err(e) => {
                        warn!("⚠️ 缓冲区剩余数据解码失败: {}", e);
                    }
                }
            }
            
            debug!("🏁 流式处理完成");
        };

        Box::pin(stream)
    }

    /// 从Gemini响应中提取内容
    fn extract_content_from_response(response: &GeminiResponse) -> Option<StreamChunk> {
        let candidates = response.candidates.as_ref()?;
        let candidate = candidates.first()?;
        let content = candidate.content.as_ref()?;
        let parts = &content.parts;
        
        if let Some(part) = parts.first() {
            if let Some(text) = &part.text {
                return Some(StreamChunk {
                    content: text.clone(),
                    finish_reason: candidate.finish_reason.clone(),
                    total_tokens: response.usage_metadata.as_ref()
                        .and_then(|usage| usage.total_token_count),
                });
            }
        }
        
        None
    }

    /// 验证流式URL格式 - 确保包含关键的alt=sse参数
    pub fn build_streaming_url(model: &str, api_key: &str) -> String {
        // 原Python: f"https://generativelanguage.googleapis.com/{api_version}/models/{model}:streamGenerateContent?key={self.api_key}&alt=sse"
        format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:streamGenerateContent?key={}&alt=sse",
            model, api_key
        )
    }

    /// 构建请求头
    pub fn build_headers() -> reqwest::header::HeaderMap {
        let mut headers = reqwest::header::HeaderMap::new();
        headers.insert(
            reqwest::header::CONTENT_TYPE,
            reqwest::header::HeaderValue::from_static("application/json"),
        );
        headers
    }
}

/// 流式处理状态枚举
#[derive(Debug, Clone)]
pub enum StreamState {
    /// 等待数据
    Waiting,
    /// 处理中
    Processing,
    /// 已完成
    Done,
    /// 发生错误
    Error(String),
}

/// 流式处理统计
#[derive(Debug, Default)]
pub struct StreamStats {
    /// 处理的行数
    pub lines_processed: usize,
    /// 成功解析的JSON数量
    pub json_parsed: usize,
    /// JSON解析失败次数
    pub json_errors: usize,
    /// 累积的总字节数
    pub total_bytes: usize,
}