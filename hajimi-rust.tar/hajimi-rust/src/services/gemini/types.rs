//! Gemini API 数据结构定义
//! 
//! 包含所有与Gemini API交互相关的数据结构

use serde::{Deserialize, Serialize};

/// Gemini API请求结构
#[derive(Debug, Serialize)]
pub struct GeminiRequest {
    pub contents: Vec<GeminiContent>,
    #[serde(rename = "generationConfig")]
    pub generation_config: GenerationConfig,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tools: Option<Vec<GeminiTool>>,
}

/// Gemini内容结构
#[derive(Debug, Serialize)]
pub struct GeminiContent {
    pub parts: Vec<GeminiPart>,
    pub role: String,
}

/// Gemini内容部分
#[derive(Debug, Serialize)]
pub struct GeminiPart {
    pub text: String,
}

/// 生成配置
#[derive(Debug, Serialize)]
pub struct GenerationConfig {
    pub temperature: f32,
    #[serde(rename = "maxOutputTokens")]
    pub max_output_tokens: Option<u32>,
    #[serde(rename = "topP")]
    pub top_p: Option<f32>,
    #[serde(rename = "topK")]
    pub top_k: Option<u32>,
}

/// Gemini工具定义
#[derive(Debug, Serialize)]
pub struct GeminiTool {
    #[serde(rename = "functionDeclarations", skip_serializing_if = "Vec::is_empty")]
    pub function_declarations: Vec<GeminiFunctionDeclaration>,
    #[serde(rename = "googleSearch", skip_serializing_if = "Option::is_none")]
    pub google_search: Option<serde_json::Value>,
}

/// Gemini函数声明
#[derive(Debug, Serialize)]
pub struct GeminiFunctionDeclaration {
    pub name: String,
    pub description: String,
    pub parameters: GeminiFunctionParameters,
}

/// Gemini函数参数
#[derive(Debug, Serialize)]
pub struct GeminiFunctionParameters {
    #[serde(rename = "type")]
    pub param_type: String,
    pub properties: std::collections::HashMap<String, serde_json::Value>,
    pub required: Vec<String>,
}

/// Gemini API响应结构
#[derive(Debug, Deserialize)]
pub struct GeminiResponse {
    pub candidates: Option<Vec<GeminiCandidate>>,
    #[serde(rename = "usageMetadata")]
    pub usage_metadata: Option<GeminiUsage>,
}

/// Gemini候选响应
#[derive(Debug, Deserialize)]
pub struct GeminiCandidate {
    pub content: Option<GeminiResponseContent>,
    #[serde(rename = "finishReason")]
    pub finish_reason: Option<String>,
    #[serde(rename = "safetyRatings")]
    pub safety_ratings: Option<Vec<GeminiSafetyRating>>,
}

/// Gemini响应内容
#[derive(Debug, Deserialize)]
pub struct GeminiResponseContent {
    pub parts: Vec<GeminiResponsePart>,
    pub role: Option<String>,
}

/// Gemini响应部分
#[derive(Debug, Deserialize)]
pub struct GeminiResponsePart {
    pub text: Option<String>,
    #[serde(rename = "functionCall")]
    pub function_call: Option<GeminiFunctionCall>,
}

/// Gemini函数调用
#[derive(Debug, Deserialize)]
pub struct GeminiFunctionCall {
    pub name: String,
    pub args: serde_json::Value,
}

/// Gemini安全评级
#[derive(Debug, Deserialize)]
pub struct GeminiSafetyRating {
    pub category: String,
    pub probability: String,
}

/// Gemini使用元数据
#[derive(Debug, Deserialize)]
pub struct GeminiUsage {
    #[serde(rename = "promptTokenCount")]
    pub prompt_token_count: Option<u32>,
    #[serde(rename = "candidatesTokenCount")]
    pub candidates_token_count: Option<u32>,
    #[serde(rename = "totalTokenCount")]
    pub total_token_count: Option<u32>,
}

/// 流式响应包装器
#[derive(Debug)]
pub struct StreamChunk {
    pub content: String,
    pub finish_reason: Option<String>,
    pub total_tokens: Option<u32>,
}

impl Default for GenerationConfig {
    fn default() -> Self {
        Self {
            temperature: 0.7,
            max_output_tokens: Some(8192),
            top_p: Some(0.95),
            top_k: Some(40),
        }
    }
}