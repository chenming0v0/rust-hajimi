//! Gemini服务模块
//! 
//! 基于原Python代码逻辑重新实现的模块化Gemini API集成
//! 
//! ## 模块结构
//! 
//! - `types` - 数据结构定义
//! - `client` - 核心客户端逻辑
//! - `streaming` - 真实流式处理（基于原Python逻辑）
//! - `utils` - 工具函数
//! 
//! ## 使用示例
//! 
//! ```rust
//! use crate::services::gemini::{GeminiService, StreamChunk};
//! 
//! let service = GeminiService::new();
//! let stream = service.chat_stream(&messages, &api_key, "gemini-pro", None, None, false).await?;
//! ```

pub mod types;
pub mod client;
pub mod streaming;
pub mod utils;

// 重新导出主要的公共接口
pub use client::GeminiService;
pub use streaming::{GeminiStreaming, StreamState, StreamStats};
pub use types::{
    GeminiRequest, GeminiContent, GeminiResponse, 
    GenerationConfig, StreamChunk
};
pub use utils::{
    model_supports_search,
    preprocess_search_messages,
    preprocess_disguise_messages,
    generate_secure_random_string,
    validate_api_key_format,
    extract_model_version,
    build_model_url
};

/// Gemini服务的便捷创建函数
pub fn create_gemini_service() -> GeminiService {
    GeminiService::new()
}

/// 验证Gemini模型名称
pub fn is_valid_gemini_model(model: &str) -> bool {
    model.starts_with("gemini") && !model.is_empty()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_create_gemini_service() {
        let _service = create_gemini_service();
        // 如果能创建就说明基本功能正常
    }

    #[test]
    fn test_is_valid_gemini_model() {
        assert!(is_valid_gemini_model("gemini-pro"));
        assert!(is_valid_gemini_model("gemini-1.5-pro"));
        assert!(!is_valid_gemini_model("gpt-4"));
        assert!(!is_valid_gemini_model(""));
    }
}