//! Gemini服务工具函数
//! 
//! 包含模型检查、消息预处理等辅助功能

use crate::models::{Message, MessageContent};
use rand::{distributions::Alphanumeric, Rng};

/// 检查模型是否支持搜索功能
pub fn model_supports_search(model: &str) -> bool {
    // 大多数Gemini模型都支持工具调用，但排除视觉模型
    model.starts_with("gemini") && !model.contains("vision")
}

/// 预处理搜索模式的消息
/// 
/// 在倒数第二个位置插入搜索提示（保持原版逻辑）
pub fn preprocess_search_messages(
    messages: &[Message],
    search_prompt: &str,
    enable_search: bool,
) -> Vec<Message> {
    if !enable_search {
        return messages.to_vec();
    }

    let mut processed_messages = messages.to_vec();
    
    // 在倒数第二个位置插入搜索提示（原版逻辑）
    if processed_messages.len() >= 2 {
        let search_message = Message {
            role: "user".to_string(),
            content: MessageContent::Text(search_prompt.to_string()),
        };
        
        processed_messages.insert(processed_messages.len() - 1, search_message);
    }

    processed_messages
}

/// 生成安全随机字符串
pub fn generate_secure_random_string(length: usize) -> String {
    rand::thread_rng()
        .sample_iter(&Alphanumeric)
        .take(length)
        .map(char::from)
        .collect()
}

/// 预处理伪装消息（注入随机字符串）
///
/// 在第1个位置和倒数第1个位置插入随机字符串（保持原版逻辑）
pub fn preprocess_disguise_messages(
    messages: &[Message],
    enable_disguise: bool,
    random_length: usize,
) -> Vec<Message> {
    if !enable_disguise || messages.is_empty() {
        return messages.to_vec();
    }

    let mut processed_messages = messages.to_vec();
    
    // 生成随机字符串
    let random_str1 = generate_secure_random_string(random_length);
    let random_str2 = generate_secure_random_string(random_length);
    
    // 在第1个位置插入随机字符串（Python: insert(1, ...))
    if processed_messages.len() >= 1 {
        let random_message1 = Message {
            role: "user".to_string(),
            content: MessageContent::Text(random_str1),
        };
        processed_messages.insert(1, random_message1);
    }
    
    // 在倒数第1个位置插入随机字符串（Python: insert(len(data)-1, ...))
    if processed_messages.len() >= 2 {
        let random_message2 = Message {
            role: "user".to_string(),
            content: MessageContent::Text(random_str2),
        };
        processed_messages.insert(processed_messages.len() - 1, random_message2);
    }

    tracing::info!("✨ 伪装消息成功，已注入{}位随机字符串", random_length);
    processed_messages
}

/// 检查API密钥格式
pub fn validate_api_key_format(api_key: &str) -> bool {
    // 基本的API密钥格式检查
    !api_key.is_empty() && api_key.len() > 10 && api_key.chars().all(|c| c.is_ascii())
}

/// 从模型名称中提取版本信息
pub fn extract_model_version(model_name: &str) -> Option<&str> {
    if model_name.contains("gemini-1.5") {
        Some("v1beta")
    } else if model_name.contains("gemini-1.0") {
        Some("v1")
    } else if model_name.contains("gemini-2") {
        Some("v1beta")
    } else {
        Some("v1beta") // 默认使用beta版本
    }
}

/// 构建模型的完整URL路径
pub fn build_model_url(model: &str, api_key: &str, streaming: bool) -> String {
    let version = extract_model_version(model).unwrap_or("v1beta");
    let endpoint = if streaming {
        "streamGenerateContent"
    } else {
        "generateContent"
    };
    
    let mut url = format!(
        "https://generativelanguage.googleapis.com/{}/models/{}:{}?key={}",
        version, model, endpoint, api_key
    );
    
    // 流式请求需要添加alt=sse参数
    if streaming {
        url.push_str("&alt=sse");
    }
    
    url
}

/// 检查响应是否表示成功
pub fn is_successful_response(status: u16) -> bool {
    (200..300).contains(&status)
}

/// 从错误响应中提取错误信息
pub fn extract_error_message(error_body: &str) -> String {
    // 尝试解析JSON错误响应
    if let Ok(error_json) = serde_json::from_str::<serde_json::Value>(error_body) {
        if let Some(error) = error_json.get("error") {
            if let Some(message) = error.get("message").and_then(|m| m.as_str()) {
                return message.to_string();
            }
            if let Some(status) = error.get("status").and_then(|s| s.as_str()) {
                return format!("API错误: {}", status);
            }
        }
    }
    
    // 如果不是标准JSON错误格式，返回原始错误
    if error_body.len() > 200 {
        format!("{}...", &error_body[..200])
    } else {
        error_body.to_string()
    }
}

/// 计算请求的大致token数量（简单估算）
pub fn estimate_token_count(text: &str) -> usize {
    // 简单的token估算：平均4个字符约等于1个token
    (text.len() as f64 / 4.0).ceil() as usize
}

/// 验证温度参数范围
pub fn validate_temperature(temperature: f32) -> f32 {
    temperature.clamp(0.0, 2.0)
}

/// 验证top_p参数范围
pub fn validate_top_p(top_p: f32) -> f32 {
    top_p.clamp(0.0, 1.0)
}

/// 验证top_k参数范围
pub fn validate_top_k(top_k: u32) -> u32 {
    top_k.clamp(1, 100)
}

/// 构建安全的模型名称（移除潜在的特殊字符）
pub fn sanitize_model_name(model: &str) -> String {
    model
        .chars()
        .filter(|c| c.is_alphanumeric() || *c == '-' || *c == '.' || *c == '_')
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_model_supports_search() {
        assert!(model_supports_search("gemini-pro"));
        assert!(model_supports_search("gemini-1.5-pro"));
        assert!(!model_supports_search("gemini-vision"));
        assert!(!model_supports_search("gpt-4"));
    }

    #[test]
    fn test_validate_api_key_format() {
        assert!(validate_api_key_format("valid_api_key_12345"));
        assert!(!validate_api_key_format(""));
        assert!(!validate_api_key_format("short"));
    }

    #[test]
    fn test_extract_model_version() {
        assert_eq!(extract_model_version("gemini-1.5-pro"), Some("v1beta"));
        assert_eq!(extract_model_version("gemini-1.0-pro"), Some("v1"));
        assert_eq!(extract_model_version("gemini-2-pro"), Some("v1beta"));
    }

    #[test]
    fn test_validate_parameters() {
        assert_eq!(validate_temperature(-1.0), 0.0);
        assert_eq!(validate_temperature(3.0), 2.0);
        assert_eq!(validate_temperature(1.0), 1.0);
        
        assert_eq!(validate_top_p(-0.1), 0.0);
        assert_eq!(validate_top_p(1.5), 1.0);
        
        assert_eq!(validate_top_k(0), 1);
        assert_eq!(validate_top_k(150), 100);
    }
}