//! Gemini API核心客户端
//! 
//! 提供完整的Gemini API集成，包括流式和非流式请求

use crate::{
    error::{Error, Result},
    models::{Message, MessageContent},
};
use super::{
    types::*,
    streaming::GeminiStreaming,
    utils::*,
};
use futures_util::Stream;
use reqwest::Client;
use std::{pin::Pin, time::Duration};
use tracing::{debug, info, warn};

/// Gemini服务客户端
pub struct GeminiService {
    client: Client,
    timeout: Duration,
    max_retries: usize,
}

impl GeminiService {
    /// 创建新的Gemini服务实例
    pub fn new() -> Self {
        Self {
            client: Client::builder()
                .timeout(Duration::from_secs(600))
                .build()
                .expect("Failed to create HTTP client"),
            timeout: Duration::from_secs(300),
            max_retries: 3,
        }
    }

    /// 自定义配置的构造函数
    pub fn with_config(timeout: Duration, max_retries: usize) -> Self {
        Self {
            client: Client::builder()
                .timeout(timeout)
                .build()
                .expect("Failed to create HTTP client"),
            timeout,
            max_retries,
        }
    }

    /// 发送流式聊天请求 - 基于原Python逻辑的核心实现
    pub async fn chat_stream(
        &self,
        messages: &[Message],
        api_key: &str,
        model: &str,
        temperature: Option<f32>,
        max_tokens: Option<u32>,
        search_enabled: bool,
    ) -> Result<Pin<Box<dyn Stream<Item = Result<StreamChunk>> + Send>>> {
        info!("🚀 发送流式聊天请求, 模型: {}", model);

        // 转换消息格式
        let gemini_contents = self.convert_messages_to_gemini_format(messages)?;
        
        // 构建请求数据
        let request_data = GeminiRequest {
            contents: gemini_contents,
            generation_config: GenerationConfig {
                temperature: temperature.unwrap_or(0.7),
                max_output_tokens: max_tokens,
                top_p: Some(0.95),
                top_k: Some(40),
            },
            tools: if search_enabled {
                Some(vec![GeminiTool {
                    function_declarations: vec![],
                    google_search: Some(serde_json::json!({}))
                }])
            } else {
                None
            },
        };

        // 构建流式URL（关键：包含alt=sse参数）
        let url = build_model_url(model, api_key, true);
        debug!("📡 流式请求URL: {}", url);

        // 构建请求头
        let headers = GeminiStreaming::build_headers();

        // 发送流式请求
        let response = self
            .client
            .post(&url)
            .headers(headers)
            .json(&request_data)
            .send()
            .await?;

        if !response.status().is_success() {
            let error_text = response.text().await?;
            let error_msg = extract_error_message(&error_text);
            return Err(Error::Api(format!("流式请求失败: {}", error_msg)));
        }

        debug!("✅ 流式响应已建立");
        
        // 使用基于原Python逻辑的流式处理器
        Ok(GeminiStreaming::create_stream_from_response(response))
    }

    /// 发送非流式聊天请求
    pub async fn chat(
        &self,
        messages: &[Message],
        api_key: &str,
        model: &str,
        temperature: Option<f32>,
        max_tokens: Option<u32>,
        search_enabled: bool,
    ) -> Result<String> {
        info!("💬 发送非流式聊天请求, 模型: {}", model);

        // 转换消息格式
        let gemini_contents = self.convert_messages_to_gemini_format(messages)?;
        
        // 构建请求数据
        let request_data = GeminiRequest {
            contents: gemini_contents,
            generation_config: GenerationConfig {
                temperature: temperature.unwrap_or(0.7),
                max_output_tokens: max_tokens,
                top_p: Some(0.95),
                top_k: Some(40),
            },
            tools: if search_enabled {
                Some(vec![GeminiTool {
                    function_declarations: vec![],
                    google_search: Some(serde_json::json!({}))
                }])
            } else {
                None
            },
        };

        // 构建非流式URL
        let url = build_model_url(model, api_key, false);
        debug!("📡 非流式请求URL: {}", url);

        // 发送请求
        let response = self
            .client
            .post(&url)
            .json(&request_data)
            .send()
            .await?;

        if !response.status().is_success() {
            let error_text = response.text().await?;
            let error_msg = extract_error_message(&error_text);
            return Err(Error::Api(format!("请求失败: {}", error_msg)));
        }

        let gemini_response: GeminiResponse = response.json().await?;
        
        // 提取响应文本
        self.extract_text_from_response(&gemini_response)
    }

    /// 获取可用的模型列表
    pub async fn list_models(&self, api_key: &str) -> Result<Vec<String>> {
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models?key={}",
            api_key
        );

        let response = self.client.get(&url).send().await?;

        if !response.status().is_success() {
            let error_text = response.text().await?;
            return Err(Error::Api(format!("获取模型列表失败: {}", error_text)));
        }

        // 先获取响应文本，然后尝试解析 JSON
        let response_text = response.text().await?;
        
        // 检查响应是否为空
        if response_text.trim().is_empty() {
            return Err(Error::Api("API 返回空响应".to_string()));
        }

        // 尝试解析 JSON，提供更详细的错误信息
        let models_response: serde_json::Value = match serde_json::from_str(&response_text) {
            Ok(json) => json,
            Err(e) => {
                debug!("JSON 解析失败，响应内容: {}", response_text);
                return Err(Error::Api(format!("JSON 解析失败: {}，响应内容: {}", e, response_text)));
            }
        };

        let models = models_response["models"]
            .as_array()
            .unwrap_or(&vec![])
            .iter()
            .filter_map(|model| {
                model["name"]
                    .as_str()
                    .and_then(|name| name.strip_prefix("models/"))
                    .filter(|name| name.contains("gemini") && !name.contains("embedding"))
            })
            .map(|name| name.to_string())
            .collect();

        Ok(models)
    }

    /// 验证API密钥
    pub async fn validate_api_key(&self, api_key: &str) -> bool {
        // 先检查格式
        if !validate_api_key_format(api_key) {
            debug!("❌ API密钥格式无效");
            return false;
        }

        // 尝试获取模型列表来验证密钥
        match self.list_models(api_key).await {
            Ok(models) => {
                debug!("✅ API密钥验证成功，发现 {} 个模型", models.len());
                !models.is_empty()
            }
            Err(e) => {
                debug!("❌ API密钥验证失败: {}", e);
                false
            }
        }
    }

    /// 转换消息格式为Gemini格式
    fn convert_messages_to_gemini_format(&self, messages: &[Message]) -> Result<Vec<GeminiContent>> {
        let mut gemini_contents: Vec<GeminiContent> = Vec::new();

        // 转换消息格式为Gemini格式
        for message in messages {
            let text = match &message.content {
                MessageContent::Text(text) => text.clone(),
                MessageContent::Array(_) => {
                    warn!("⚠️ 暂不支持多模态消息，跳过");
                    continue;
                }
            };

            let gemini_role = match message.role.as_str() {
                "user" => "user",
                "assistant" => "model",
                "system" => "user", // 系统消息转为用户消息
                _ => {
                    warn!("⚠️ 未知角色: {}, 转为用户角色", message.role);
                    "user"
                }
            };

            // 检查是否需要合并相同角色的连续消息
            if let Some(last_content) = gemini_contents.last_mut() {
                if last_content.role == gemini_role {
                    // 合并到现有内容
                    last_content.parts.push(GeminiPart { text });
                    continue;
                }
            }

            // 创建新的内容块
            gemini_contents.push(GeminiContent {
                parts: vec![GeminiPart { text }],
                role: gemini_role.to_string(),
            });
        }

        if gemini_contents.is_empty() {
            return Err(Error::Validation("消息列表不能为空".to_string()));
        }

        Ok(gemini_contents)
    }

    /// 从响应中提取文本内容
    fn extract_text_from_response(&self, response: &GeminiResponse) -> Result<String> {
        let candidates = response.candidates.as_ref()
            .ok_or_else(|| Error::Parse("响应中没有候选结果".to_string()))?;

        let candidate = candidates.first()
            .ok_or_else(|| Error::Parse("候选结果为空".to_string()))?;

        let content = candidate.content.as_ref()
            .ok_or_else(|| Error::Parse("候选结果中没有内容".to_string()))?;

        let parts = &content.parts;
        if parts.is_empty() {
            return Err(Error::Parse("内容部分为空".to_string()));
        }

        let mut full_text = String::new();
        for part in parts {
            if let Some(text) = &part.text {
                full_text.push_str(text);
            }
        }

        if full_text.is_empty() {
            return Err(Error::Parse("没有找到文本内容".to_string()));
        }

        Ok(full_text)
    }
}

impl Default for GeminiService {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_convert_messages_to_gemini_format() {
        let service = GeminiService::new();
        let messages = vec![
            Message {
                role: "user".to_string(),
                content: MessageContent::Text("Hello".to_string()),
            },
            Message {
                role: "assistant".to_string(),
                content: MessageContent::Text("Hi there!".to_string()),
            },
        ];

        let result = service.convert_messages_to_gemini_format(&messages);
        assert!(result.is_ok());
        
        let gemini_contents = result.unwrap();
        assert_eq!(gemini_contents.len(), 2);
        assert_eq!(gemini_contents[0].role, "user");
        assert_eq!(gemini_contents[1].role, "model");
    }
}