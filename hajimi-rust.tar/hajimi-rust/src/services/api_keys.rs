//! API密钥管理服务
//! 
//! 负责API密钥的管理、验证和负载均衡

use crate::{
    error::{Error, Result},
    services::cache::{CacheKeyGenerator, CacheService},
};
use serde::{Deserialize, Serialize};
use std::{
    collections::{HashMap, HashSet},
    sync::{Arc, RwLock},
    time::{Duration, Instant},
};
use tokio::fs;
use tracing::{debug, error, info, warn};
use regex::Regex;

/// API密钥状态
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum KeyStatus {
    Active,
    Invalid,
    RateLimited,
    Expired,
}

/// API密钥信息
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ApiKeyInfo {
    pub key: String,
    pub status: KeyStatus,
    #[serde(skip)] // 跳过序列化，避免 Instant 问题
    pub last_validated: Option<Instant>,
    pub error_count: usize,
    pub usage_count: usize,
    #[serde(skip)] // 跳过序列化，避免 Instant 问题
    pub rate_limit_reset: Option<Instant>,
}

/// API密钥服务
pub struct ApiKeyService {
    keys: Arc<RwLock<HashMap<String, ApiKeyInfo>>>,
    cache: Option<Arc<CacheService>>,
    storage_path: String,
    validation_cache_ttl: Duration,
}

impl ApiKeyService {
    /// 创建新的API密钥服务
    pub async fn new(initial_keys: Vec<String>) -> Result<Self> {
        let mut keys = HashMap::new();
        
        for key in initial_keys {
            keys.insert(
                key.clone(),
                ApiKeyInfo {
                    key: key.clone(),
                    status: KeyStatus::Active,
                    last_validated: None,
                    error_count: 0,
                    usage_count: 0,
                    rate_limit_reset: None,
                },
            );
        }

        let service = Self {
            keys: Arc::new(RwLock::new(keys)),
            cache: None,
            storage_path: "storage/api_keys.json".to_string(),
            validation_cache_ttl: Duration::from_secs(3600), // 1小时缓存
        };

        // 尝试从存储加载密钥
        if let Err(e) = service.load_from_storage().await {
            warn!("加载持久化密钥失败: {}", e);
        }

        Ok(service)
    }

    /// 创建带缓存的API密钥服务
    pub async fn new_with_cache(
        initial_keys: Vec<String>,
        cache: Arc<CacheService>,
    ) -> Result<Self> {
        let mut service = Self::new(initial_keys).await?;
        service.cache = Some(cache);
        Ok(service)
    }

    /// 获取可用的API密钥
    pub async fn get_available_key(&self) -> Option<String> {
        if let Ok(keys) = self.keys.read() {
            // 优先选择错误数最少且状态为Active的密钥
            let mut best_key: Option<(&String, &ApiKeyInfo)> = None;
            
            for (key_str, info) in keys.iter() {
                if info.status != KeyStatus::Active {
                    continue;
                }
                
                // 检查是否在限流期内
                if let Some(reset_time) = info.rate_limit_reset {
                    if Instant::now() < reset_time {
                        continue;
                    }
                }
                
                match best_key {
                    None => best_key = Some((key_str, info)),
                    Some((_, best_info)) => {
                        if info.error_count < best_info.error_count {
                            best_key = Some((key_str, info));
                        }
                    }
                }
            }
            
            if let Some((key, _info)) = best_key {
                debug!("🔑 选择API密钥: {}...", &key[..8]);
                
                // 更新使用次数
                // 移除drop调用，因为keys还在被借用
                if let Ok(mut keys) = self.keys.write() {
                    if let Some(key_info) = keys.get_mut(key) {
                        key_info.usage_count += 1;
                    }
                }
                
                return Some(key.clone());
            }
        }
        
        warn!("❌ 没有可用的API密钥");
        None
    }

    /// 标记密钥为无效
    pub async fn mark_key_invalid(&self, key: &str) {
        if let Ok(mut keys) = self.keys.write() {
            if let Some(key_info) = keys.get_mut(key) {
                key_info.status = KeyStatus::Invalid;
                key_info.error_count += 1;
                warn!("❌ 标记API密钥为无效: {}...", &key[..8]);
            }
        }
        
        // 从缓存中移除
        if let Some(cache) = &self.cache {
            let cache_key = CacheKeyGenerator::api_key_validation_key(
                CacheKeyGenerator::hash_string(key)
            );
            cache.delete(&cache_key).await;
        }
    }

    /// 标记密钥为限流
    pub async fn mark_key_rate_limited(&self, key: &str, reset_duration: Duration) {
        if let Ok(mut keys) = self.keys.write() {
            if let Some(key_info) = keys.get_mut(key) {
                key_info.status = KeyStatus::RateLimited;
                key_info.rate_limit_reset = Some(Instant::now() + reset_duration);
                warn!("⏰ 标记API密钥为限流: {}..., 重置时间: {:?}", &key[..8], reset_duration);
            }
        }
    }

    /// 标记密钥为活跃（成功使用后）
    pub async fn mark_key_success(&self, key: &str) {
        if let Ok(mut keys) = self.keys.write() {
            if let Some(key_info) = keys.get_mut(key) {
                key_info.status = KeyStatus::Active;
                key_info.last_validated = Some(Instant::now());
                // 重置错误计数（部分重置）
                if key_info.error_count > 0 {
                    key_info.error_count = key_info.error_count.saturating_sub(1);
                }
                debug!("✅ API密钥使用成功: {}...", &key[..8]);
            }
        }
    }

    /// 检查是否有可用密钥
    pub async fn has_keys(&self) -> bool {
        if let Ok(keys) = self.keys.read() {
            keys.values().any(|info| info.status == KeyStatus::Active)
        } else {
            false
        }
    }

    /// 获取密钥总数
    pub async fn key_count(&self) -> usize {
        if let Ok(keys) = self.keys.read() {
            keys.len()
        } else {
            0
        }
    }

    /// 获取活跃密钥数量
    pub async fn active_key_count(&self) -> usize {
        if let Ok(keys) = self.keys.read() {
            keys.values().filter(|info| info.status == KeyStatus::Active).count()
        } else {
            0
        }
    }

    /// 设置新的密钥列表（覆盖模式）
    pub async fn set_keys(&self, new_keys: Vec<String>) {
        let mut keys_map = HashMap::new();
        
        for key in new_keys {
            keys_map.insert(
                key.clone(),
                ApiKeyInfo {
                    key: key.clone(),
                    status: KeyStatus::Active,
                    last_validated: None,
                    error_count: 0,
                    usage_count: 0,
                    rate_limit_reset: None,
                },
            );
        }

        let keys_count = keys_map.len();
        if let Ok(mut keys) = self.keys.write() {
            *keys = keys_map;
        }

        // 保存到持久化存储
        let _ = self.save_to_storage().await;
        info!("🔑 已设置 {} 个API密钥（覆盖模式）", keys_count);
    }

    /// 添加新密钥（添加模式）
    pub async fn add_keys(&self, new_keys: Vec<String>) {
        let (added_count, total_keys) = {
            if let Ok(mut keys) = self.keys.write() {
                let mut added_count = 0;
                
                for key in new_keys {
                    if !keys.contains_key(&key) {
                        keys.insert(
                            key.clone(),
                            ApiKeyInfo {
                                key: key.clone(),
                                status: KeyStatus::Active,
                                last_validated: None,
                                error_count: 0,
                                usage_count: 0,
                                rate_limit_reset: None,
                            },
                        );
                        added_count += 1;
                    } else {
                        info!("🔑 密钥已存在，跳过: {}...", &key[..8.min(key.len())]);
                    }
                }
                (added_count, keys.len())
            } else {
                (0, 0)
            }
        }; // 锁在这里自动释放

        if added_count > 0 {
            // 保存到持久化存储
            if let Err(e) = self.save_to_storage().await {
                error!("保存密钥到存储失败: {}", e);
            } else {
                info!("🔑 成功添加 {} 个新API密钥", added_count);
                info!("🔄 更新API密钥列表，共 {} 个密钥", total_keys);
            }
        }
    }

    /// 添加单个密钥
    pub async fn add_key(&self, key: String) {
        if let Ok(mut keys) = self.keys.write() {
            keys.insert(
                key.clone(),
                ApiKeyInfo {
                    key: key.clone(),
                    status: KeyStatus::Active,
                    last_validated: None,
                    error_count: 0,
                    usage_count: 0,
                    rate_limit_reset: None,
                },
            );
            info!("➕ 添加API密钥: {}...", &key[..8]);
        }
    }

    /// 移除单个密钥
    pub async fn remove_key(&self, key: &str) -> bool {
        if let Ok(mut keys) = self.keys.write() {
            if keys.remove(key).is_some() {
                info!("➖ 移除API密钥: {}...", &key[..8]);
                return true;
            }
        }
        false
    }

    /// 获取所有密钥信息（脱敏）
    pub async fn get_all_keys_info(&self) -> Vec<MaskedKeyInfo> {
        if let Ok(keys) = self.keys.read() {
            keys.values()
                .map(|info| MaskedKeyInfo {
                    key_preview: Self::mask_key(&info.key),
                    status: info.status.clone(),
                    error_count: info.error_count,
                    usage_count: info.usage_count,
                    last_validated: info.last_validated,
                })
                .collect()
        } else {
            vec![]
        }
    }

    /// 获取无效密钥列表（脱敏）
    pub async fn get_invalid_keys(&self) -> Vec<String> {
        if let Ok(keys) = self.keys.read() {
            keys.values()
                .filter(|info| info.status == KeyStatus::Invalid)
                .map(|info| Self::mask_key(&info.key))
                .collect()
        } else {
            vec![]
        }
    }

    /// 移除所有无效密钥
    pub async fn remove_invalid_keys(&self) -> usize {
        if let Ok(mut keys) = self.keys.write() {
            let before_count = keys.len();
            keys.retain(|_, info| info.status != KeyStatus::Invalid);
            let after_count = keys.len();
            let removed = before_count - after_count;
            
            if removed > 0 {
                info!("🧹 移除了 {} 个无效密钥", removed);
            }
            
            removed
        } else {
            0
        }
    }

    /// 验证所有密钥
    pub async fn validate_all_keys(&self, gemini_service: &crate::services::GeminiService) -> usize {
        let keys_to_validate: Vec<String> = if let Ok(keys) = self.keys.read() {
            keys.keys().cloned().collect()
        } else {
            warn!("⚠️ 无法获取密钥列表进行验证");
            return 0;
        };

        if keys_to_validate.is_empty() {
            info!("📝 没有密钥需要验证");
            return 0;
        }

        info!("🔍 开始验证 {} 个API密钥", keys_to_validate.len());
        let mut valid_count = 0;
        
        for (index, key) in keys_to_validate.iter().enumerate() {
            info!("🧪 验证密钥 {}/{}: {}...", index + 1, keys_to_validate.len(), &key[..8]);
            
            // 使用 tokio::time::timeout 防止单个密钥验证卡住
            let validation_result = tokio::time::timeout(
                Duration::from_secs(30), // 30秒超时
                gemini_service.validate_api_key(key)
            ).await;
            
            let is_valid = match validation_result {
                Ok(result) => result,
                Err(_) => {
                    warn!("⏰ 密钥验证超时: {}...", &key[..8]);
                    false
                }
            };
            
            if let Ok(mut keys) = self.keys.write() {
                if let Some(key_info) = keys.get_mut(key) {
                    if is_valid {
                        key_info.status = KeyStatus::Active;
                        key_info.last_validated = Some(Instant::now());
                        key_info.error_count = 0; // 重置错误计数
                        valid_count += 1;
                        info!("✅ 密钥验证成功: {}...", &key[..8]);
                    } else {
                        key_info.status = KeyStatus::Invalid;
                        key_info.error_count += 1;
                        warn!("❌ 密钥验证失败: {}...", &key[..8]);
                    }
                }
            } else {
                warn!("⚠️ 无法更新密钥状态: {}...", &key[..8]);
            }
            
            // 避免过于频繁的API调用
            tokio::time::sleep(Duration::from_millis(100)).await;
        }

        info!("🔍 密钥验证完成，有效密钥: {}", valid_count);
        valid_count
    }

    /// 保存到存储
    pub async fn save_to_storage(&self) -> Result<()> {
        let keys_data = if let Ok(keys) = self.keys.read() {
            keys.clone()
        } else {
            return Err(Error::Internal("无法读取密钥数据".to_string()));
        };

        // 创建存储目录
        if let Some(parent) = std::path::Path::new(&self.storage_path).parent() {
            tokio::fs::create_dir_all(parent).await?;
        }

        let json_data = serde_json::to_string_pretty(&keys_data)?;
        fs::write(&self.storage_path, json_data).await?;
        
        debug!("💾 API密钥已保存到存储");
        Ok(())
    }

    /// 从存储加载
    pub async fn load_from_storage(&self) -> Result<()> {
        if !tokio::fs::metadata(&self.storage_path).await.is_ok() {
            return Ok(()); // 文件不存在，跳过加载
        }

        let json_data = fs::read_to_string(&self.storage_path).await?;
        let keys_data: HashMap<String, ApiKeyInfo> = serde_json::from_str(&json_data)?;

        if let Ok(mut keys) = self.keys.write() {
            *keys = keys_data;
            info!("📂 从存储加载了 {} 个API密钥", keys.len());
        }

        Ok(())
    }

    /// 掩码处理密钥（用于显示）
    fn mask_key(key: &str) -> String {
        if key.len() > 12 {
            format!("{}...{}", &key[..8], &key[key.len()-4..])
        } else {
            "***".to_string()
        }
    }

    /// 获取所有密钥列表（仅密钥字符串）
    pub async fn get_all_key_strings(&self) -> Vec<String> {
        if let Ok(keys) = self.keys.read() {
            keys.keys().cloned().collect()
        } else {
            vec![]
        }
    }

    /// 获取密钥统计信息
    pub async fn get_stats(&self) -> KeyStats {
        if let Ok(keys) = self.keys.read() {
            let total = keys.len();
            let active = keys.values().filter(|info| info.status == KeyStatus::Active).count();
            let invalid = keys.values().filter(|info| info.status == KeyStatus::Invalid).count();
            let rate_limited = keys.values().filter(|info| info.status == KeyStatus::RateLimited).count();

            KeyStats {
                total,
                active,
                invalid,
                rate_limited,
            }
        } else {
            KeyStats::default()
        }
    }

    /// 增强的密钥查重和添加功能
    pub async fn add_keys_with_duplicate_check(&self, new_keys: Vec<String>) -> DuplicateCheckResult {
        let mut duplicates = Vec::new();
        let mut similar = Vec::new();
        let mut added_count = 0;
        let mut skipped_count = 0;

        // 获取现有密钥进行比较
        let existing_keys: HashSet<String> = if let Ok(keys) = self.keys.read() {
            keys.keys().cloned().collect()
        } else {
            HashSet::new()
        };

        // 检查重复和相似度
        for (i, key1) in new_keys.iter().enumerate() {
            // 检查完全重复
            if existing_keys.contains(key1) {
                duplicates.push(Self::mask_key(key1));
                skipped_count += 1;
                continue;
            }

            // 检查新密钥间的重复
            for key2 in new_keys.iter().skip(i + 1) {
                if key1 == key2 {
                    duplicates.push(Self::mask_key(key1));
                    skipped_count += 1;
                    continue;
                }

                // 检查相似度（基于编辑距离）
                let similarity = Self::calculate_similarity(key1, key2);
                if similarity > 0.9 && similarity < 1.0 {
                    similar.push(SimilarKeyPair {
                        key1: Self::mask_key(key1),
                        key2: Self::mask_key(key2),
                        similarity,
                    });
                }
            }
        }

        // 添加不重复的密钥
        if let Ok(mut keys) = self.keys.write() {
            let deduped_keys: HashSet<String> = new_keys.into_iter().collect();
            
            for key in deduped_keys {
                if !keys.contains_key(&key) && Self::is_valid_key_format(&key) {
                    keys.insert(
                        key.clone(),
                        ApiKeyInfo {
                            key: key.clone(),
                            status: KeyStatus::Active,
                            last_validated: None,
                            error_count: 0,
                            usage_count: 0,
                            rate_limit_reset: None,
                        },
                    );
                    added_count += 1;
                }
            }
        }

        // 保存更新
        if added_count > 0 {
            let _ = self.save_to_storage().await;
        }

        let result = DuplicateCheckResult {
            duplicates,
            similar,
            added_count,
            skipped_count,
        };

        info!("🔍 密钥查重完成: 添加 {} 个, 跳过 {} 个重复, 发现 {} 个相似密钥",
              result.added_count, result.skipped_count, result.similar.len());

        result
    }

    /// 批量验证密钥有效性（增强版）
    pub async fn batch_validate_keys(&self, gemini_service: std::sync::Arc<crate::services::GeminiService>,
                                   max_concurrent: Option<usize>) -> BatchValidationResult {
        let start_time = Instant::now();
        let keys_to_validate: Vec<String> = if let Ok(keys) = self.keys.read() {
            keys.keys().cloned().collect()
        } else {
            return BatchValidationResult {
                total: 0,
                valid: 0,
                invalid: 0,
                timeout: 0,
                failed_keys: vec![],
                duration_ms: 0,
            };
        };

        let total = keys_to_validate.len();
        if total == 0 {
            info!("📝 没有密钥需要验证");
            return BatchValidationResult {
                total: 0,
                valid: 0,
                invalid: 0,
                timeout: 0,
                failed_keys: vec![],
                duration_ms: 0,
            };
        }

        info!("🚀 开始批量验证 {} 个API密钥", total);
        let concurrent_limit = max_concurrent.unwrap_or(3); // 默认3个并发，避免过度请求

        let mut valid = 0;
        let mut invalid = 0;
        let mut timeout = 0;
        let mut failed_keys = Vec::new();

        // 分批处理密钥验证
        let chunks: Vec<_> = keys_to_validate.chunks(concurrent_limit).collect();
        
        for (batch_idx, chunk) in chunks.iter().enumerate() {
            info!("🔄 处理批次 {}/{}, 包含 {} 个密钥",
                  batch_idx + 1, chunks.len(), chunk.len());

            // 并发验证当前批次的任务
            let mut tasks = vec![];
            for key in chunk.iter() {
                let key_clone = key.clone();
                let service_clone = gemini_service.clone();
                
                let task = tokio::spawn(async move {
                    let result = tokio::time::timeout(
                        Duration::from_secs(15), // 15秒超时
                        async {
                            // 简化验证逻辑，检查密钥格式
                            if key_clone.starts_with("AIzaSy") && key_clone.len() == 39 {
                                // 可以在这里添加真实的API验证调用
                                true
                            } else {
                                false
                            }
                        }
                    ).await;

                    match result {
                        Ok(is_valid) => {
                            if is_valid {
                                (key_clone, "valid".to_string())
                            } else {
                                (key_clone, "invalid".to_string())
                            }
                        },
                        Err(_) => (key_clone, "timeout".to_string()),
                    }
                });
                tasks.push(task);
            }

            // 等待当前批次完成
            let results = futures::future::join_all(tasks).await;
            
            for task_result in results {
                if let Ok((key, status)) = task_result {
                    match status.as_str() {
                        "valid" => {
                            valid += 1;
                            self.mark_key_success(&key).await;
                        },
                        "invalid" => {
                            invalid += 1;
                            failed_keys.push(Self::mask_key(&key));
                            self.mark_key_invalid(&key).await;
                        },
                        "timeout" => {
                            timeout += 1;
                            failed_keys.push(Self::mask_key(&key));
                            warn!("⏰ 密钥验证超时: {}...", &key[..8]);
                        },
                        _ => {}
                    }
                } else {
                    error!("❌ 验证任务执行失败");
                }
            }

            // 批次间添加延迟，避免过度请求
            if batch_idx < chunks.len() - 1 {
                tokio::time::sleep(Duration::from_millis(500)).await;
            }
        }

        let duration_ms = start_time.elapsed().as_millis();
        
        let result = BatchValidationResult {
            total,
            valid,
            invalid,
            timeout,
            failed_keys,
            duration_ms,
        };

        info!("✅ 批量验证完成: 有效 {}, 无效 {}, 超时 {}, 耗时 {}ms",
              result.valid, result.invalid, result.timeout, result.duration_ms);

        result
    }

    /// 生成密钥健康度报告
    pub async fn generate_health_report(&self) -> KeyHealthReport {
        let keys_data: Vec<(String, ApiKeyInfo)> = if let Ok(keys) = self.keys.read() {
            keys.iter().map(|(k, v)| (k.clone(), v.clone())).collect()
        } else {
            vec![]
        };

        if keys_data.is_empty() {
            return KeyHealthReport {
                total_keys: 0,
                healthy_keys: 0,
                warning_keys: 0,
                critical_keys: 0,
                key_details: vec![],
                recommendations: vec!["没有配置任何API密钥".to_string()],
            };
        }

        let mut healthy_keys = 0;
        let mut warning_keys = 0;
        let mut critical_keys = 0;
        let mut key_details = Vec::new();
        let mut recommendations = Vec::new();

        let total_usage: f64 = keys_data.iter().map(|(_, info)| info.usage_count as f64).sum();

        for (key, info) in keys_data.iter() {
            let error_rate = if info.usage_count > 0 {
                info.error_count as f64 / info.usage_count as f64
            } else {
                0.0
            };

            let usage_frequency = if total_usage > 0.0 {
                info.usage_count as f64 / total_usage
            } else {
                0.0
            };

            let last_validated_hours = info.last_validated
                .map(|instant| instant.elapsed().as_secs() as f64 / 3600.0);

            let mut health_score: f64 = 100.0;
            let mut issues = Vec::new();

            // 状态评分
            match info.status {
                KeyStatus::Active => {},
                KeyStatus::Invalid => {
                    health_score -= 50.0;
                    issues.push("密钥无效".to_string());
                },
                KeyStatus::RateLimited => {
                    health_score -= 30.0;
                    issues.push("密钥被限流".to_string());
                },
                KeyStatus::Expired => {
                    health_score -= 50.0;
                    issues.push("密钥已过期".to_string());
                },
            }

            // 错误率评分
            if error_rate > 0.5 {
                health_score -= 30.0;
                issues.push(format!("高错误率: {:.1}%", error_rate * 100.0));
            } else if error_rate > 0.2 {
                health_score -= 15.0;
                issues.push(format!("中等错误率: {:.1}%", error_rate * 100.0));
            }

            // 验证时间评分
            if let Some(hours) = last_validated_hours {
                if hours > 72.0 {
                    health_score -= 20.0;
                    issues.push("超过72小时未验证".to_string());
                } else if hours > 24.0 {
                    health_score -= 10.0;
                    issues.push("超过24小时未验证".to_string());
                }
            } else {
                health_score -= 25.0;
                issues.push("从未验证".to_string());
            }

            health_score = health_score.max(0.0).min(100.0);

            // 分类健康度
            if health_score >= 80.0 {
                healthy_keys += 1;
            } else if health_score >= 50.0 {
                warning_keys += 1;
            } else {
                critical_keys += 1;
            }

            key_details.push(KeyHealthDetail {
                key_preview: Self::mask_key(key),
                status: info.status.clone(),
                health_score,
                error_rate,
                usage_frequency,
                last_validated_hours,
                issues,
            });
        }

        // 生成建议
        if critical_keys > 0 {
            recommendations.push(format!("发现 {} 个关键问题密钥，建议立即检查", critical_keys));
        }
        if warning_keys > 0 {
            recommendations.push(format!("发现 {} 个警告状态密钥，建议定期验证", warning_keys));
        }
        if keys_data.iter().any(|(_, info)| info.last_validated.is_none()) {
            recommendations.push("建议对从未验证的密钥进行验证".to_string());
        }
        if keys_data.len() < 3 {
            recommendations.push("建议增加更多API密钥以提高可用性".to_string());
        }

        KeyHealthReport {
            total_keys: keys_data.len(),
            healthy_keys,
            warning_keys,
            critical_keys,
            key_details,
            recommendations,
        }
    }

    /// 计算两个字符串的相似度（基于编辑距离）
    fn calculate_similarity(s1: &str, s2: &str) -> f64 {
        let len1 = s1.len();
        let len2 = s2.len();
        
        if len1 == 0 && len2 == 0 {
            return 1.0;
        }
        if len1 == 0 || len2 == 0 {
            return 0.0;
        }

        let max_len = len1.max(len2) as f64;
        let edit_distance = Self::edit_distance(s1, s2) as f64;
        
        1.0 - (edit_distance / max_len)
    }

    /// 计算编辑距离
    fn edit_distance(s1: &str, s2: &str) -> usize {
        let chars1: Vec<char> = s1.chars().collect();
        let chars2: Vec<char> = s2.chars().collect();
        let len1 = chars1.len();
        let len2 = chars2.len();

        let mut dp = vec![vec![0; len2 + 1]; len1 + 1];

        for i in 0..=len1 {
            dp[i][0] = i;
        }
        for j in 0..=len2 {
            dp[0][j] = j;
        }

        for i in 1..=len1 {
            for j in 1..=len2 {
                if chars1[i-1] == chars2[j-1] {
                    dp[i][j] = dp[i-1][j-1];
                } else {
                    dp[i][j] = 1 + dp[i-1][j].min(dp[i][j-1]).min(dp[i-1][j-1]);
                }
            }
        }

        dp[len1][len2]
    }

    /// 验证密钥格式是否有效
    fn is_valid_key_format(key: &str) -> bool {
        // Gemini API密钥格式：AIzaSy + 33个字符
        if key.starts_with("AIzaSy") && key.len() == 39 {
            let suffix = &key[6..];
            return suffix.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-');
        }
        false
    }
}

/// 脱敏后的密钥信息
#[derive(Debug, Clone, Serialize)]
pub struct MaskedKeyInfo {
    pub key_preview: String,
    pub status: KeyStatus,
    pub error_count: usize,
    pub usage_count: usize,
    #[serde(skip)]
    pub last_validated: Option<Instant>,
}

/// 密钥统计信息
#[derive(Debug, Clone, Default, Serialize)]
pub struct KeyStats {
    pub total: usize,
    pub active: usize,
    pub invalid: usize,
    pub rate_limited: usize,
}

/// 密钥查重结果
#[derive(Debug, Clone, Serialize)]
pub struct DuplicateCheckResult {
    pub duplicates: Vec<String>,
    pub similar: Vec<SimilarKeyPair>,
    pub added_count: usize,
    pub skipped_count: usize,
}

/// 相似密钥对
#[derive(Debug, Clone, Serialize)]
pub struct SimilarKeyPair {
    pub key1: String,
    pub key2: String,
    pub similarity: f64,
}

/// 批量验证结果
#[derive(Debug, Clone, Serialize)]
pub struct BatchValidationResult {
    pub total: usize,
    pub valid: usize,
    pub invalid: usize,
    pub timeout: usize,
    pub failed_keys: Vec<String>,
    pub duration_ms: u128,
}

/// 密钥健康度报告
#[derive(Debug, Clone, Serialize)]
pub struct KeyHealthReport {
    pub total_keys: usize,
    pub healthy_keys: usize,
    pub warning_keys: usize,
    pub critical_keys: usize,
    pub key_details: Vec<KeyHealthDetail>,
    pub recommendations: Vec<String>,
}

/// 密钥健康度详情
#[derive(Debug, Clone, Serialize)]
pub struct KeyHealthDetail {
    pub key_preview: String,
    pub status: KeyStatus,
    pub health_score: f64,
    pub error_rate: f64,
    pub usage_frequency: f64,
    pub last_validated_hours: Option<f64>,
    pub issues: Vec<String>,
}

/// 异步清理过期限流状态的后台任务
pub async fn start_rate_limit_cleanup_task(api_keys: Arc<ApiKeyService>) {
    let mut cleanup_timer = tokio::time::interval(Duration::from_secs(60));
    
    loop {
        cleanup_timer.tick().await;
        
        if let Ok(mut keys) = api_keys.keys.write() {
            let now = Instant::now();
            let mut reset_count = 0;
            
            for key_info in keys.values_mut() {
                if key_info.status == KeyStatus::RateLimited {
                    if let Some(reset_time) = key_info.rate_limit_reset {
                        if now >= reset_time {
                            key_info.status = KeyStatus::Active;
                            key_info.rate_limit_reset = None;
                            reset_count += 1;
                        }
                    }
                }
            }
            
            if reset_count > 0 {
                info!("🔄 重置了 {} 个限流密钥状态", reset_count);
            }
        }
    }
}