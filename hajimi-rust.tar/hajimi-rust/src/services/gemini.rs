use anyhow::Result;
use reqwest::Client;
use serde::{Deserialize, Serialize};

use tracing::{debug, error, info};
use std::sync::Arc;
use futures_util::StreamExt;

use crate::Message;
use crate::utils::connection_pool::ConnectionPool;

#[derive(Debug, Clone)]
pub struct GeminiService {
    client: Client,
    connection_pool: Option<Arc<ConnectionPool>>,
}

#[derive(Serialize)]
struct GeminiRequest {
    contents: Vec<GeminiContent>,
    #[serde(rename = "generationConfig")]
    generation_config: GenerationConfig,
    #[serde(skip_serializing_if = "Option::is_none")]
    tools: Option<Vec<GeminiTool>>,
}

#[derive(Serialize)]
struct GeminiStreamRequest {
    contents: Vec<GeminiContent>,
    #[serde(rename = "generationConfig")]
    generation_config: GenerationConfig,
    #[serde(skip_serializing_if = "Option::is_none")]
    tools: Option<Vec<GeminiTool>>,
}

#[derive(Serialize)]
struct GeminiTool {
    google_search: GeminiGoogleSearch,
}

#[derive(Serialize)]
struct GeminiGoogleSearch {}

#[derive(Serialize)]
struct GeminiContent {
    parts: Vec<GeminiPart>,
    role: String,
}

#[derive(Serialize)]
struct GeminiPart {
    text: String,
}

#[derive(Serialize)]
struct GenerationConfig {
    temperature: f32,
    #[serde(rename = "maxOutputTokens")]
    max_output_tokens: u32,
}

#[derive(Deserialize)]
struct GeminiResponse {
    candidates: Vec<GeminiCandidate>,
}

#[derive(Deserialize)]
struct GeminiStreamResponse {
    candidates: Option<Vec<GeminiStreamCandidate>>,
}

#[derive(Deserialize)]
struct GeminiStreamCandidate {
    content: Option<GeminiResponseContent>,
    #[serde(rename = "finishReason")]
    finish_reason: Option<String>,
}

#[derive(Deserialize)]
struct GeminiCandidate {
    content: GeminiResponseContent,
}

#[derive(Deserialize)]
struct GeminiResponseContent {
    parts: Vec<GeminiResponsePart>,
}

#[derive(Deserialize)]
struct GeminiResponsePart {
    text: String,
}

impl GeminiService {
    pub fn new() -> Self {
        // 创建兼容性更好的HTTP客户端
        let client = Client::builder()
            .timeout(std::time::Duration::from_secs(30))
            .connect_timeout(std::time::Duration::from_secs(10))
            .tcp_keepalive(std::time::Duration::from_secs(60))
            .http1_title_case_headers()  // HTTP/1.1 兼容性
            .build()
            .unwrap_or_else(|_| Client::new());
            
        Self {
            client,
            connection_pool: None,
        }
    }

    pub fn new_with_pool(pool: Arc<ConnectionPool>) -> Self {
        Self {
            client: pool.client().clone(),
            connection_pool: Some(pool),
        }
    }

    pub async fn chat_completion_with_search(
        &self,
        model: &str,
        messages: &[Message],
        api_key: &str,
        enable_search: bool,
    ) -> Result<String> {
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}",
            model, api_key
        );

        // 转换消息格式
        let contents: Vec<GeminiContent> = messages
            .iter()
            .map(|msg| {
                let role = match msg.role.as_str() {
                    "system" => "user", // Gemini 不支持 system role，转换为 user
                    "assistant" => "model",
                    _ => "user",
                };
                
                GeminiContent {
                    parts: vec![GeminiPart {
                        text: msg.content.clone(),
                    }],
                    role: role.to_string(),
                }
            })
            .collect();

        let tools = if enable_search {
            Some(vec![GeminiTool {
                google_search: GeminiGoogleSearch {},
            }])
        } else {
            None
        };

        let request_body = GeminiRequest {
            contents,
            generation_config: GenerationConfig {
                temperature: 0.7,
                max_output_tokens: 2048,
            },
            tools,
        };

        debug!("发送 Gemini API 请求: {}", url);
        debug!("请求体: {}", serde_json::to_string_pretty(&request_body)?);

        // 添加重试机制处理HTTP2连接问题
        let mut last_error = None;
        for attempt in 1..=3 {
            match self
                .client
                .post(&url)
                .header("Content-Type", "application/json")
                .header("User-Agent", "hajimi-rust/1.0")
                .json(&request_body)
                .send()
                .await
            {
                Ok(response) => {
                    if !response.status().is_success() {
                        let error_text = response.text().await?;
                        error!("Gemini API 错误响应 (尝试 {}): {}", attempt, error_text);
                        return Err(anyhow::anyhow!("Gemini API 错误: {}", error_text));
                    }
                    
                    let gemini_response: GeminiResponse = response.json().await?;
                    
                    if let Some(candidate) = gemini_response.candidates.first() {
                        if let Some(part) = candidate.content.parts.first() {
                            return Ok(part.text.clone());
                        } else {
                            return Err(anyhow::anyhow!("Gemini 响应中没有文本内容"));
                        }
                    } else {
                        return Err(anyhow::anyhow!("Gemini 响应中没有候选结果"));
                    }
                }
                Err(e) => {
                    last_error = Some(e);
                    if attempt < 3 {
                        error!("HTTP请求失败 (尝试 {}): {}，正在重试...", attempt, last_error.as_ref().unwrap());
                        tokio::time::sleep(std::time::Duration::from_millis(1000 * attempt)).await;
                    }
                }
            }
        }
        
        Err(anyhow::anyhow!("HTTP请求失败，已重试3次: {}", last_error.unwrap()))
    }

    pub async fn chat_completion(
        &self,
        model: &str,
        messages: &[Message],
        api_key: &str,
    ) -> Result<String> {
        self.chat_completion_with_search(model, messages, api_key, false).await
    }

    pub async fn chat_completion_original(
        &self,
        model: &str,
        messages: &[Message],
        api_key: &str,
    ) -> Result<String> {
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:generateContent?key={}",
            model, api_key
        );

        // 转换消息格式
        let contents: Vec<GeminiContent> = messages
            .iter()
            .map(|msg| {
                let role = match msg.role.as_str() {
                    "system" => "user", // Gemini 不支持 system role，转换为 user
                    "assistant" => "model",
                    _ => "user",
                };
                
                GeminiContent {
                    parts: vec![GeminiPart {
                        text: msg.content.clone(),
                    }],
                    role: role.to_string(),
                }
            })
            .collect();

        let request_body = GeminiRequest {
            contents,
            generation_config: GenerationConfig {
                temperature: 0.7,
                max_output_tokens: 2048,
            },
            tools: None,
        };

        debug!("发送 Gemini API 请求: {}", url);
        debug!("请求体: {}", serde_json::to_string_pretty(&request_body)?);

        // 添加重试机制处理HTTP2连接问题
        let mut last_error = None;
        for attempt in 1..=3 {
            match self
                .client
                .post(&url)
                .header("Content-Type", "application/json")
                .header("User-Agent", "hajimi-rust/1.0")
                .json(&request_body)
                .send()
                .await
            {
                Ok(response) => {
                    if !response.status().is_success() {
                        let error_text = response.text().await?;
                        error!("Gemini API 错误响应 (尝试 {}): {}", attempt, error_text);
                        return Err(anyhow::anyhow!("Gemini API 错误: {}", error_text));
                    }
                    
                    let gemini_response: GeminiResponse = response.json().await?;
                    
                    if let Some(candidate) = gemini_response.candidates.first() {
                        if let Some(part) = candidate.content.parts.first() {
                            return Ok(part.text.clone());
                        } else {
                            return Err(anyhow::anyhow!("Gemini 响应中没有文本内容"));
                        }
                    } else {
                        return Err(anyhow::anyhow!("Gemini 响应中没有候选结果"));
                    }
                }
                Err(e) => {
                    last_error = Some(e);
                    if attempt < 3 {
                        error!("HTTP请求失败 (尝试 {}): {}，正在重试...", attempt, last_error.as_ref().unwrap());
                        tokio::time::sleep(std::time::Duration::from_millis(1000 * attempt)).await;
                    }
                }
            }
        }
        
        Err(anyhow::anyhow!("HTTP请求失败，已重试3次: {}", last_error.unwrap()))
    }

    pub async fn list_models(&self, api_key: &str) -> Result<Vec<String>> {
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models?key={}",
            api_key
        );

        let response = self.client.get(&url).send().await?;

        if !response.status().is_success() {
            let error_text = response.text().await?;
            return Err(anyhow::anyhow!("获取 Gemini 模型列表失败: {}", error_text));
        }

        let models_response: serde_json::Value = response.json().await?;
        
        let models = models_response["models"]
            .as_array()
            .unwrap_or(&vec![])
            .iter()
            .filter_map(|model| {
                model["name"]
                    .as_str()
                    .map(|name| name.replace("models/", ""))
            })
            .collect();

        Ok(models)
    }

    pub async fn stream_chat_completion(
        &self,
        model: &str,
        messages: &[Message],
        api_key: &str,
        enable_search: bool,
    ) -> Result<String> {
        let url = format!(
            "https://generativelanguage.googleapis.com/v1beta/models/{}:streamGenerateContent?key={}",
            model, api_key
        );

        // 转换消息格式
        let contents: Vec<GeminiContent> = messages
            .iter()
            .map(|msg| {
                let role = match msg.role.as_str() {
                    "system" => "user", // Gemini 不支持 system role，转换为 user
                    "assistant" => "model",
                    _ => "user",
                };
                
                GeminiContent {
                    parts: vec![GeminiPart {
                        text: msg.content.clone(),
                    }],
                    role: role.to_string(),
                }
            })
            .collect();

        let tools = if enable_search {
            Some(vec![GeminiTool {
                google_search: GeminiGoogleSearch {},
            }])
        } else {
            None
        };

        let request_body = GeminiStreamRequest {
            contents,
            generation_config: GenerationConfig {
                temperature: 0.7,
                max_output_tokens: 2048,
            },
            tools,
        };

        info!("发送 Gemini 流式API 请求: {}", url);
        debug!("流式请求体: {}", serde_json::to_string_pretty(&request_body)?);

        // 发送流式请求
        let response = self
            .client
            .post(&url)
            .header("Content-Type", "application/json")
            .header("User-Agent", "hajimi-rust/1.0")
            .header("Accept", "text/plain")
            .json(&request_body)
            .send()
            .await?;

        if !response.status().is_success() {
            let error_text = response.text().await?;
            error!("Gemini 流式API 错误响应: {}", error_text);
            return Err(anyhow::anyhow!("Gemini 流式API 错误: {}", error_text));
        }

        // 处理流式响应
        let mut full_content = String::new();
        let bytes_stream = response.bytes_stream();
        let mut bytes_stream = Box::pin(bytes_stream);

        while let Some(chunk_result) = bytes_stream.next().await {
            match chunk_result {
                Ok(chunk) => {
                    let chunk_text = String::from_utf8_lossy(&chunk);
                    debug!("收到流式数据块: {}", chunk_text);
                    
                    // 处理SSE格式的数据
                    for line in chunk_text.lines() {
                        if line.starts_with("data: ") {
                            let json_data = &line[6..]; // 移除"data: "前缀
                            if json_data.trim() == "[DONE]" {
                                break;
                            }
                            
                            // 解析JSON响应
                            match serde_json::from_str::<GeminiStreamResponse>(json_data) {
                                Ok(stream_response) => {
                                    if let Some(candidates) = &stream_response.candidates {
                                        for candidate in candidates {
                                            if let Some(content) = &candidate.content {
                                                if let Some(part) = content.parts.first() {
                                                    full_content.push_str(&part.text);
                                                }
                                            }
                                        }
                                    }
                                }
                                Err(e) => {
                                    debug!("解析流式响应JSON失败: {}, 数据: {}", e, json_data);
                                }
                            }
                        }
                    }
                }
                Err(e) => {
                    error!("读取流式响应失败: {}", e);
                    break;
                }
            }
        }

        if full_content.is_empty() {
            return Err(anyhow::anyhow!("流式响应内容为空"));
        }

        info!("流式响应处理完成，内容长度: {} 字符", full_content.len());
        Ok(full_content)
    }
}