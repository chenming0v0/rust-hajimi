//! 服务模块
//! 
//! 包含所有外部服务的集成

pub mod gemini;
pub mod cache;
pub mod api_keys;

pub use gemini::GeminiService;
pub use cache::CacheService;
pub use api_keys::ApiKeyService;

/// 服务管理器
use crate::{config::Config, error::Result};
use std::sync::Arc;

pub struct ServiceManager {
    pub gemini: Arc<GeminiService>,
    pub cache: Arc<CacheService>,
    pub api_keys: Arc<ApiKeyService>,
}

impl ServiceManager {
    /// 创建服务管理器
    pub async fn new(config: &Config) -> Result<Self> {
        let api_keys = Arc::new(ApiKeyService::new(config.gemini_api_keys.clone()).await?);
        let cache = Arc::new(CacheService::new(config.performance.cache_expiry_seconds));
        let gemini = Arc::new(GeminiService::with_config(
            std::time::Duration::from_secs(config.performance.request_timeout_seconds),
            config.performance.max_retry_attempts,
        ));

        Ok(Self {
            gemini,
            cache,
            api_keys,
        })
    }

    /// 获取可用的API密钥
    pub async fn get_available_api_key(&self) -> Option<String> {
        self.api_keys.get_available_key().await
    }

    /// 检查是否有可用的API密钥
    pub async fn has_api_keys(&self) -> bool {
        self.api_keys.has_keys().await
    }
}