use anyhow::Result;
use reqwest::Client;
use serde::{Deserialize, Serialize};
use tracing::{debug, error};
use std::sync::Arc;

use crate::Message;
use crate::utils::connection_pool::ConnectionPool;

#[derive(Debug, Clone)]
pub struct OpenAIService {
    client: Client,
    connection_pool: Option<Arc<ConnectionPool>>,
}

#[derive(Serialize)]
struct OpenAIRequest {
    model: String,
    messages: Vec<Message>,
    temperature: f32,
    max_tokens: u32,
}

#[derive(Deserialize)]
struct OpenAIResponse {
    choices: Vec<OpenAIChoice>,
}

#[derive(Deserialize)]
struct OpenAIChoice {
    message: Message,
}

impl OpenAIService {
    pub fn new() -> Self {
        Self {
            client: Client::new(),
            connection_pool: None,
        }
    }

    pub fn new_with_pool(pool: Arc<ConnectionPool>) -> Self {
        Self {
            client: pool.client().clone(),
            connection_pool: Some(pool),
        }
    }

    pub async fn chat_completion(
        &self,
        model: &str,
        messages: &[Message],
        api_key: &str,
    ) -> Result<String> {
        let url = "https://api.openai.com/v1/chat/completions";

        let request_body = OpenAIRequest {
            model: model.to_string(),
            messages: messages.to_vec(),
            temperature: 0.7,
            max_tokens: 2048,
        };

        debug!("发送 OpenAI API 请求: {}", url);
        debug!("请求体: {}", serde_json::to_string_pretty(&request_body)?);

        let response = self
            .client
            .post(url)
            .header("Content-Type", "application/json")
            .header("Authorization", format!("Bearer {}", api_key))
            .json(&request_body)
            .send()
            .await?;

        if !response.status().is_success() {
            let error_text = response.text().await?;
            error!("OpenAI API 错误响应: {}", error_text);
            return Err(anyhow::anyhow!("OpenAI API 错误: {}", error_text));
        }

        let openai_response: OpenAIResponse = response.json().await?;
        
        if let Some(choice) = openai_response.choices.first() {
            Ok(choice.message.content.clone())
        } else {
            Err(anyhow::anyhow!("OpenAI 响应中没有选择结果"))
        }
    }

    pub async fn list_models(&self, api_key: &str) -> Result<Vec<String>> {
        let url = "https://api.openai.com/v1/models";

        let response = self
            .client
            .get(url)
            .header("Authorization", format!("Bearer {}", api_key))
            .send()
            .await?;

        if !response.status().is_success() {
            let error_text = response.text().await?;
            return Err(anyhow::anyhow!("获取 OpenAI 模型列表失败: {}", error_text));
        }

        let models_response: serde_json::Value = response.json().await?;
        
        let models = models_response["data"]
            .as_array()
            .unwrap_or(&vec![])
            .iter()
            .filter_map(|model| model["id"].as_str().map(|s| s.to_string()))
            .collect();

        Ok(models)
    }
}