//! Hajimi Rust - 高性能 Gemini API 代理服务
//! 
//! 提供流式和非流式响应的完整实现

pub mod app;
pub mod config;
pub mod error;
pub mod models;
pub mod services;
pub mod streaming;
pub mod handlers;
pub mod middleware;
pub mod utils;

pub use app::App;
pub use config::Config;
pub use error::{Error, Result};