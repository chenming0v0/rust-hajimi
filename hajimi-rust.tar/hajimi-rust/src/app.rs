//! 应用核心模块
//! 
//! 负责应用的初始化、路由配置和服务启动

use crate::{
    config::Config,
    error::{Error, Result},
    handlers,
    middleware,
    services::ServiceManager,
};
use axum::{
    routing::{get, post},
    Router,
};
use std::{net::SocketAddr, sync::Arc};
use tokio::net::TcpListener;
use tower_http::{
    cors::{Any, CorsLayer},
    services::ServeDir,
};
use tracing::{info, warn};

/// 应用状态
#[derive(Clone)]
pub struct AppState {
    pub config: Arc<Config>,
    pub services: Arc<ServiceManager>,
}

/// 应用主体
pub struct App {
    config: Config,
    services: Arc<ServiceManager>,
}

impl App {
    /// 创建新的应用实例
    pub async fn new(config: Config) -> Result<Self> {
        // 验证配置
        config.validate()?;

        // 初始化服务
        let services = Arc::new(ServiceManager::new(&config).await?);

        info!("🔧 应用组件初始化完成");
        info!("🔑 API密钥数量: {}", services.api_keys.key_count().await);
        info!("⚡ 最大并发数: {}", config.performance.max_concurrent_requests);

        Ok(Self { config, services })
    }

    /// 构建路由
    fn build_router(&self) -> Router {
        let state = AppState {
            config: Arc::new(self.config.clone()),
            services: Arc::clone(&self.services),
        };

        // API路由
        let api_router = Router::new()
            // OpenAI兼容API
            .route("/v1/chat/completions", post(handlers::chat_completions))
            .route("/v1/models", get(handlers::list_models))
            // 健康检查
            .route("/health", get(handlers::health_check))
            // 管理API
            .route("/api/stats", get(handlers::get_stats))
            .route("/api/dashboard-data", get(handlers::get_dashboard_data))
            .route("/api/update-config", post(handlers::update_config))
            // API密钥管理
            .route("/api/set-keys", post(handlers::set_api_keys))
            .route("/api/key-info", get(handlers::get_key_info))
            .route("/api/test-keys", post(handlers::test_api_keys))
            .route("/api/test-keys/progress", get(handlers::get_test_progress))
            .route("/api/clear-invalid-keys", post(handlers::clear_invalid_keys))
            .route("/api/get-invalid-keys", get(handlers::get_invalid_keys))
            // 增强的API密钥管理功能
            .route("/api/set-keys-with-check", post(handlers::set_api_keys_with_duplicate_check))
            .route("/api/batch-validate-keys", post(handlers::batch_validate_keys))
            .route("/api/health-report", post(handlers::generate_health_report))
            .route("/api/enhanced-key-stats", get(handlers::get_enhanced_key_stats))
            // 测试日志相关
            .route("/api/test-logs", get(handlers::get_test_logs_api))
            .route("/api/clear-test-logs", post(handlers::clear_test_logs_api));

        // 主路由
        Router::new()
            // 首页仪表板
            .route("/", get(handlers::dashboard))
            // 合并API路由
            .merge(api_router)
            // 静态文件服务
            .nest_service("/assets", ServeDir::new("templates/assets"))
            // 中间件
            .layer(
                CorsLayer::new()
                    .allow_origin(Any)
                    .allow_methods(Any)
                    .allow_headers(Any),
            )
            .layer(middleware::get_trace_layer())
            // 应用状态
            .with_state(state)
    }

    /// 启动HTTP服务器
    pub async fn serve(self) -> Result<()> {
        let app_router = self.build_router();
        let addr = SocketAddr::from(([0, 0, 0, 0], self.config.port));

        info!("🌐 启动HTTP服务器: {}", addr);
        info!("📈 配置概览:");
        info!("  - 流式模式: {}", if self.config.streaming.fake_streaming { "假流式" } else { "真流式" });
        info!("  - 搜索功能: {}", if self.config.search.enabled { "启用" } else { "禁用" });
        info!("  - 缓存TTL: {}秒", self.config.performance.cache_expiry_seconds);
        info!("  - 请求超时: {}秒", self.config.performance.request_timeout_seconds);

        // 启动后台任务
        self.start_background_tasks().await;

        // 创建TCP监听器
        let listener = TcpListener::bind(addr).await.map_err(|e| {
            Error::Internal(format!("无法绑定到地址 {}: {}", addr, e))
        })?;

        info!("✅ 服务器启动成功，等待连接...");

        // 启动服务器
        if let Err(e) = axum::serve(listener, app_router).await {
            return Err(Error::Internal(format!("服务器运行错误: {}", e)));
        }

        Ok(())
    }

    /// 启动后台任务
    async fn start_background_tasks(&self) {
        let services = Arc::clone(&self.services);
        
        // 缓存清理任务
        tokio::spawn({
            let cache = Arc::clone(&services.cache);
            async move {
                let mut interval = tokio::time::interval(std::time::Duration::from_secs(300)); // 5分钟
                loop {
                    interval.tick().await;
                    cache.cleanup_expired().await;
                }
            }
        });

        // API密钥限流重置任务
        tokio::spawn({
            let api_keys = Arc::clone(&services.api_keys);
            crate::services::api_keys::start_rate_limit_cleanup_task(api_keys)
        });

        info!("🔄 后台任务启动完成");
    }

    /// 获取应用配置
    pub fn config(&self) -> &Config {
        &self.config
    }

    /// 获取服务管理器
    pub fn services(&self) -> &Arc<ServiceManager> {
        &self.services
    }

    /// 优雅关闭
    pub async fn shutdown(&self) {
        info!("🛑 开始优雅关闭...");
        
        // 保存API密钥状态
        if let Err(e) = self.services.api_keys.save_to_storage().await {
            warn!("保存API密钥状态失败: {}", e);
        }

        // 保存配置
        if let Err(e) = self.config.save_to_env() {
            warn!("保存配置失败: {}", e);
        }

        info!("✅ 优雅关闭完成");
    }
}

/// 应用构建器
pub struct AppBuilder {
    config: Option<Config>,
    custom_routes: Vec<Router<AppState>>,
}

impl AppBuilder {
    /// 创建新的构建器
    pub fn new() -> Self {
        Self {
            config: None,
            custom_routes: vec![],
        }
    }

    /// 设置配置
    pub fn with_config(mut self, config: Config) -> Self {
        self.config = Some(config);
        self
    }

    /// 添加自定义路由
    pub fn with_routes(mut self, routes: Router<AppState>) -> Self {
        self.custom_routes.push(routes);
        self
    }

    /// 构建应用
    pub async fn build(self) -> Result<App> {
        let config = self.config.ok_or_else(|| {
            Error::Config("未提供配置".to_string())
        })?;

        App::new(config).await
    }
}

impl Default for AppBuilder {
    fn default() -> Self {
        Self::new()
    }
}

/// 健康检查信息
#[derive(serde::Serialize)]
pub struct HealthInfo {
    pub status: String,
    pub timestamp: i64,
    pub version: String,
    pub uptime_seconds: u64,
    pub services: ServiceHealthInfo,
}

/// 服务健康信息
#[derive(serde::Serialize)]
pub struct ServiceHealthInfo {
    pub api_keys: bool,
    pub cache: bool,
    pub gemini: bool,
}

/// 获取健康检查信息
pub async fn get_health_info(services: &ServiceManager) -> HealthInfo {
    let timestamp = chrono::Utc::now().timestamp();
    
    HealthInfo {
        status: "ok".to_string(),
        timestamp,
        version: env!("CARGO_PKG_VERSION").to_string(),
        uptime_seconds: 0, // TODO: 实现运行时间统计
        services: ServiceHealthInfo {
            api_keys: services.api_keys.has_keys().await,
            cache: true, // 缓存服务总是可用的
            gemini: services.api_keys.has_keys().await,
        },
    }
}

/// 创建默认应用
pub async fn create_default_app() -> Result<App> {
    let config = Config::load().await?;
    App::new(config).await
}

/// 从环境变量创建应用
pub async fn create_app_from_env() -> Result<App> {
    let config = Config::load().await?;
    AppBuilder::new()
        .with_config(config)
        .build()
        .await
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[tokio::test]
    async fn test_app_creation() {
        let config = Config::default();
        let app = App::new(config).await;
        assert!(app.is_ok());
    }

    #[tokio::test]
    async fn test_app_builder() {
        let config = Config::default();
        let app = AppBuilder::new()
            .with_config(config)
            .build()
            .await;
        assert!(app.is_ok());
    }
}