//! 配置管理模块
//! 
//! 负责加载和管理应用配置

use crate::error::{Error, Result};
use serde::{Deserialize, Serialize};
use std::env;

/// 应用配置结构
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct Config {
    /// 服务端口
    pub port: u16,
    
    /// API密码
    pub password: String,
    
    /// Web管理密码
    pub web_password: String,
    
    /// Gemini API密钥列表
    pub gemini_api_keys: Vec<String>,
    
    /// 流式配置
    pub streaming: StreamingConfig,
    
    /// 搜索配置
    pub search: SearchConfig,
    
    /// 性能配置
    pub performance: PerformanceConfig,
    
    /// 安全配置
    pub security: SecurityConfig,
}

/// 流式响应配置
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct StreamingConfig {
    /// 是否启用假流式模式
    pub fake_streaming: bool,
    
    /// 假流式间隔（秒）
    pub fake_streaming_interval: f64,
}

/// 搜索配置
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct SearchConfig {
    /// 是否启用联网搜索
    pub enabled: bool,
    
    /// 搜索提示语
    pub prompt: String,
}

/// 性能配置
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct PerformanceConfig {
    /// 最大并发请求数
    pub max_concurrent_requests: usize,
    
    /// 请求超时时间（秒）
    pub request_timeout_seconds: u64,
    
    /// 缓存过期时间（秒）
    pub cache_expiry_seconds: u64,
    
    /// 最大重试次数
    pub max_retry_attempts: usize,
    /// 空响应重试次数限制
    pub max_empty_responses: usize,
    /// 是否启用随机字符串伪装
    pub random_string: bool,
    /// 随机字符串长度
    pub random_string_length: usize,
}

/// 安全配置
#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct SecurityConfig {
    /// 每分钟最大请求数
    pub max_requests_per_minute: u32,
    
    /// 每IP每日最大请求数
    pub max_requests_per_day_per_ip: u32,
    
    /// 允许的来源
    pub allowed_origins: Vec<String>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            port: 7860,
            password: "123".to_string(),
            web_password: "123".to_string(),
            gemini_api_keys: vec![],
            streaming: StreamingConfig::default(),
            search: SearchConfig::default(),
            performance: PerformanceConfig::default(),
            security: SecurityConfig::default(),
        }
    }
}

impl Default for StreamingConfig {
    fn default() -> Self {
        Self {
            fake_streaming: true,
            fake_streaming_interval: 1.0,
        }
    }
}

impl Default for SearchConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            prompt: "（使用搜索工具联网搜索，需要在content中结合搜索内容）".to_string(),
        }
    }
}

impl Default for PerformanceConfig {
    fn default() -> Self {
        Self {
            max_concurrent_requests: 100,
            request_timeout_seconds: 30,
            cache_expiry_seconds: 3600,
            max_retry_attempts: 3,
            max_empty_responses: 5,
            random_string: true,
            random_string_length: 5,
        }
    }
}

impl Default for SecurityConfig {
    fn default() -> Self {
        Self {
            max_requests_per_minute: 30,
            max_requests_per_day_per_ip: 600,
            allowed_origins: vec!["*".to_string()],
        }
    }
}

impl Config {
    /// 从持久化存储加载配置（优先级：storage > .env > 默认值）
    pub async fn load() -> Result<Self> {
        use tracing::info;
        
        // 首先尝试从storage加载
        match Self::load_from_storage().await {
            Ok(config) => {
                info!("✅ 成功从storage加载配置，fake_streaming: {}", config.streaming.fake_streaming);
                return Ok(config);
            }
            Err(e) => {
                info!("⚠️ 从storage加载配置失败: {}，尝试从.env加载", e);
            }
        }
        
        // 然后从环境变量加载
        let config = Self::load_from_env()?;
        info!("📄 从.env加载配置，fake_streaming: {}", config.streaming.fake_streaming);
        Ok(config)
    }
    
    /// 从环境变量加载配置
    pub fn load_from_env() -> Result<Self> {
        dotenv::dotenv().ok();
        
        let mut config = Self::default();
        
        // 基本配置
        if let Ok(port) = env::var("PORT") {
            config.port = port.parse()
                .map_err(|_| Error::Config("无效的端口号".to_string()))?;
        }
        
        if let Ok(password) = env::var("PASSWORD") {
            config.password = password.trim_matches('"').to_string();
        }
        
        if let Ok(web_password) = env::var("WEB_PASSWORD") {
            config.web_password = web_password.trim_matches('"').to_string();
        } else {
            config.web_password = config.password.clone();
        }
        
        // API密钥
        if let Ok(gemini_keys) = env::var("GEMINI_API_KEYS") {
            config.gemini_api_keys = Self::parse_comma_separated(&gemini_keys);
        }
        
        // 流式配置
        if let Ok(fake_streaming) = env::var("FAKE_STREAMING") {
            config.streaming.fake_streaming = fake_streaming.to_lowercase() == "true";
        }
        
        if let Ok(interval) = env::var("FAKE_STREAMING_INTERVAL") {
            config.streaming.fake_streaming_interval = interval.parse()
                .map_err(|_| Error::Config("无效的流式间隔".to_string()))?;
        }
        
        // 搜索配置
        if let Ok(search_enabled) = env::var("SEARCH_ENABLED") {
            config.search.enabled = search_enabled.to_lowercase() == "true";
        }
        
        if let Ok(search_prompt) = env::var("SEARCH_PROMPT") {
            config.search.prompt = search_prompt.trim_matches('"').to_string();
        }
        
        // 性能配置
        if let Ok(max_concurrent) = env::var("MAX_CONCURRENT_REQUESTS") {
            config.performance.max_concurrent_requests = max_concurrent.parse()
                .map_err(|_| Error::Config("无效的并发数".to_string()))?;
        }
        
        if let Ok(timeout) = env::var("REQUEST_TIMEOUT_SECONDS") {
            config.performance.request_timeout_seconds = timeout.parse()
                .map_err(|_| Error::Config("无效的超时时间".to_string()))?;
        }
        
        if let Ok(cache_expiry) = env::var("CACHE_EXPIRY_SECONDS") {
            config.performance.cache_expiry_seconds = cache_expiry.parse()
                .map_err(|_| Error::Config("无效的缓存时间".to_string()))?;
        }
        
        if let Ok(max_retry) = env::var("MAX_RETRY_ATTEMPTS") {
            config.performance.max_retry_attempts = max_retry.parse()
                .map_err(|_| Error::Config("无效的重试次数".to_string()))?;
        }
        
        if let Ok(max_empty) = env::var("MAX_EMPTY_RESPONSES") {
            config.performance.max_empty_responses = max_empty.parse()
                .map_err(|_| Error::Config("无效的空响应重试次数".to_string()))?;
        }
        
        if let Ok(random_string) = env::var("RANDOM_STRING") {
            config.performance.random_string = random_string.to_lowercase() == "true";
        }
        
        if let Ok(random_length) = env::var("RANDOM_STRING_LENGTH") {
            config.performance.random_string_length = random_length.parse()
                .map_err(|_| Error::Config("无效的随机字符串长度".to_string()))?;
        }
        
        // 安全配置
        if let Ok(max_per_minute) = env::var("MAX_REQUESTS_PER_MINUTE") {
            config.security.max_requests_per_minute = max_per_minute.parse()
                .map_err(|_| Error::Config("无效的每分钟请求数".to_string()))?;
        }
        
        if let Ok(max_per_day) = env::var("MAX_REQUESTS_PER_DAY_PER_IP") {
            config.security.max_requests_per_day_per_ip = max_per_day.parse()
                .map_err(|_| Error::Config("无效的每日请求数".to_string()))?;
        }
        
        if let Ok(origins) = env::var("ALLOWED_ORIGINS") {
            config.security.allowed_origins = Self::parse_comma_separated(&origins);
        }
        
        Ok(config)
    }
    
    /// 解析逗号分隔的字符串
    fn parse_comma_separated(input: &str) -> Vec<String> {
        input
            .split(',')
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .collect()
    }
    
    /// 保存配置到.env文件
    pub fn save_to_env(&self) -> Result<()> {
        let mut content = String::new();
        
        content.push_str(&format!("PORT={}\n", self.port));
        content.push_str(&format!("PASSWORD=\"{}\"\n", self.password));
        content.push_str(&format!("WEB_PASSWORD=\"{}\"\n", self.web_password));
        content.push_str(&format!("GEMINI_API_KEYS={}\n", self.gemini_api_keys.join(",")));
        
        content.push_str(&format!("FAKE_STREAMING={}\n", self.streaming.fake_streaming));
        content.push_str(&format!("FAKE_STREAMING_INTERVAL={}\n", self.streaming.fake_streaming_interval));
        
        content.push_str(&format!("SEARCH_ENABLED={}\n", self.search.enabled));
        content.push_str(&format!("SEARCH_PROMPT=\"{}\"\n", self.search.prompt));
        
        content.push_str(&format!("MAX_CONCURRENT_REQUESTS={}\n", self.performance.max_concurrent_requests));
        content.push_str(&format!("REQUEST_TIMEOUT_SECONDS={}\n", self.performance.request_timeout_seconds));
        content.push_str(&format!("CACHE_EXPIRY_SECONDS={}\n", self.performance.cache_expiry_seconds));
        content.push_str(&format!("MAX_RETRY_ATTEMPTS={}\n", self.performance.max_retry_attempts));
        content.push_str(&format!("MAX_EMPTY_RESPONSES={}\n", self.performance.max_empty_responses));
        content.push_str(&format!("RANDOM_STRING={}\n", self.performance.random_string));
        content.push_str(&format!("RANDOM_STRING_LENGTH={}\n", self.performance.random_string_length));
        
        content.push_str(&format!("MAX_REQUESTS_PER_MINUTE={}\n", self.security.max_requests_per_minute));
        content.push_str(&format!("MAX_REQUESTS_PER_DAY_PER_IP={}\n", self.security.max_requests_per_day_per_ip));
        content.push_str(&format!("ALLOWED_ORIGINS={}\n", self.security.allowed_origins.join(",")));
        
        std::fs::write(".env", content)?;
        
        Ok(())
    }
    
    /// 验证配置的有效性
    pub fn validate(&self) -> Result<()> {
        if self.port == 0 {
            return Err(Error::Config("端口不能为0".to_string()));
        }
        
        if self.password.is_empty() {
            return Err(Error::Config("密码不能为空".to_string()));
        }
        
        if self.performance.max_concurrent_requests == 0 {
            return Err(Error::Config("最大并发数不能为0".to_string()));
        }
        
        Ok(())
    }
    
    /// 保存配置到JSON存储
    pub async fn save_to_storage(&self) -> Result<()> {
        use tokio::fs;
        use std::path::Path;
        
        let storage_dir = "storage";
        if !Path::new(storage_dir).exists() {
            fs::create_dir_all(storage_dir).await
                .map_err(|e| Error::Config(format!("创建存储目录失败: {}", e)))?;
        }
        
        let config_path = "storage/config.json";
        let json_data = serde_json::to_string_pretty(self)
            .map_err(|e| Error::Config(format!("序列化配置失败: {}", e)))?;
            
        fs::write(config_path, json_data).await
            .map_err(|e| Error::Config(format!("保存配置文件失败: {}", e)))?;
        
        // 暂时禁用.env保存，避免覆盖问题
        // self.save_to_env()?;
        
        tracing::info!("💾 配置已保存到JSON文件，max_retry_attempts: {}", self.performance.max_retry_attempts);
        
        Ok(())
    }
    
    /// 从JSON存储加载配置
    pub async fn load_from_storage() -> Result<Self> {
        use tokio::fs;
        use std::path::Path;
        
        let config_path = "storage/config.json";
        if !Path::new(config_path).exists() {
            return Err(Error::Config("配置存储文件不存在".to_string()));
        }
        
        let json_data = fs::read_to_string(config_path).await
            .map_err(|e| Error::Config(format!("读取配置文件失败: {}", e)))?;
            
        let config: Self = serde_json::from_str(&json_data)
            .map_err(|e| Error::Config(format!("解析配置文件失败: {}", e)))?;
            
        config.validate()?;
        Ok(config)
    }
    
    /// 更新指定的配置项并保存
    pub async fn update_field(&mut self, key: &str, value: &serde_json::Value) -> Result<()> {
        match key {
            "fake_streaming" => {
                if let Some(val) = value.as_bool() {
                    self.streaming.fake_streaming = val;
                } else {
                    return Err(Error::Config("fake_streaming必须是布尔值".to_string()));
                }
            }
            "fake_streaming_interval" => {
                if let Some(val) = value.as_f64() {
                    self.streaming.fake_streaming_interval = val;
                } else {
                    return Err(Error::Config("fake_streaming_interval必须是数字".to_string()));
                }
            }
            "search_enabled" => {
                if let Some(val) = value.as_bool() {
                    self.search.enabled = val;
                } else {
                    return Err(Error::Config("search_enabled必须是布尔值".to_string()));
                }
            }
            "search_prompt" => {
                if let Some(val) = value.as_str() {
                    self.search.prompt = val.to_string();
                } else {
                    return Err(Error::Config("search_prompt必须是字符串".to_string()));
                }
            }
            "max_concurrent_requests" => {
                if let Some(val) = value.as_u64() {
                    self.performance.max_concurrent_requests = val as usize;
                } else {
                    return Err(Error::Config("max_concurrent_requests必须是正整数".to_string()));
                }
            }
            "request_timeout_seconds" => {
                if let Some(val) = value.as_u64() {
                    self.performance.request_timeout_seconds = val;
                } else {
                    return Err(Error::Config("request_timeout_seconds必须是正整数".to_string()));
                }
            }
            "max_requests_per_minute" => {
                if let Some(val) = value.as_u64() {
                    self.security.max_requests_per_minute = val as u32;
                } else {
                    return Err(Error::Config("max_requests_per_minute必须是正整数".to_string()));
                }
            }
            _ => {
                return Err(Error::Config(format!("未知配置项: {}", key)));
            }
        }
        
        // 保存更新后的配置
        self.save_to_storage().await?;
        Ok(())
    }
}