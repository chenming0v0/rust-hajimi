use serde::{Deserialize, Serialize};
use std::env;

#[derive(Debug, Clone, Deserialize, Serialize)]
pub struct AppConfig {
    pub port: u16,
    pub password: String,
    pub web_password: String,
    pub gemini_api_keys: Vec<String>,
    pub cache_expiry_seconds: u64,
    pub max_concurrent_requests: usize,
    pub request_timeout_seconds: u64,
    pub allowed_origins: Vec<String>,
    pub fake_streaming: bool,
    pub search_mode: bool,
    pub search_prompt: String,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            port: 7860,
            password: "123".to_string(),
            web_password: "123".to_string(),
            gemini_api_keys: vec![],
            cache_expiry_seconds: 3600,
            max_concurrent_requests: 100,
            request_timeout_seconds: 30,
            allowed_origins: vec!["*".to_string()],
            fake_streaming: true,
            search_mode: false,
            search_prompt: "（使用搜索工具联网搜索，需要在content中结合搜索内容）".to_string(),
        }
    }
}

impl AppConfig {
    pub fn load() -> anyhow::Result<Self> {
        dotenv::dotenv().ok();
        
        let mut config = Self::default();
        
        // 从环境变量加载配置
        if let Ok(port) = env::var("PORT") {
            config.port = port.parse().unwrap_or(7860);
        }
        
        if let Ok(password) = env::var("PASSWORD") {
            config.password = password.trim_matches('"').to_string();
        }
        
        if let Ok(web_password) = env::var("WEB_PASSWORD") {
            config.web_password = web_password.trim_matches('"').to_string();
        } else {
            config.web_password = config.password.clone();
        }
        
        if let Ok(gemini_keys) = env::var("GEMINI_API_KEYS") {
            config.gemini_api_keys = gemini_keys
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect();
        }
        
        if let Ok(cache_expiry) = env::var("CACHE_EXPIRY_SECONDS") {
            config.cache_expiry_seconds = cache_expiry.parse().unwrap_or(3600);
        }
        
        if let Ok(max_concurrent) = env::var("MAX_CONCURRENT_REQUESTS") {
            config.max_concurrent_requests = max_concurrent.parse().unwrap_or(100);
        }
        
        if let Ok(timeout) = env::var("REQUEST_TIMEOUT_SECONDS") {
            config.request_timeout_seconds = timeout.parse().unwrap_or(30);
        }
        
        if let Ok(origins) = env::var("ALLOWED_ORIGINS") {
            config.allowed_origins = origins
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect();
        }
        
        if let Ok(fake_streaming) = env::var("FAKE_STREAMING") {
            config.fake_streaming = fake_streaming.to_lowercase() == "true";
        }
        
        if let Ok(search_mode) = env::var("SEARCH_MODE") {
            config.search_mode = search_mode.to_lowercase() == "true";
        }
        
        if let Ok(search_prompt) = env::var("SEARCH_PROMPT") {
            config.search_prompt = search_prompt.trim_matches('"').to_string();
        }
        
        Ok(config)
    }
}